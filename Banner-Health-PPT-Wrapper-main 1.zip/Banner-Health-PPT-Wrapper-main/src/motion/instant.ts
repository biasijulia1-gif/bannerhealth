import { MotionGlobalConfig } from "motion/react";

// Instant jumps. Motion can't skip animations for one subtree only: <MotionConfig skipAnimations>
// is read once at mount, and layout animations only honor the global flag. So this module is the
// one place that touches MotionGlobalConfig.skipAnimations (lint-enforced). Holds are counted so
// overlapping settles never release each other early, and freeze() pins it for exports.

let holds = 0;
let frozen = false;
let lastSettleAt = -Infinity;

function apply() {
  MotionGlobalConfig.skipAnimations = frozen || holds > 0;
}

/**
 * Finish every animation that starts in the next `frames` frames instantly. Call it right before
 * an instant state change (← in the deck, deep links, replay set-up); resolves once released.
 */
export function settle(frames = 2): Promise<void> {
  holds++;
  lastSettleAt = performance.now();
  apply();
  return new Promise((resolve) => {
    let left = frames;
    const tick = () => {
      if (--left > 0) {
        requestAnimationFrame(tick);
        return;
      }
      holds = Math.max(0, holds - 1);
      apply();
      resolve();
    };
    requestAnimationFrame(tick);
  });
}

/** Skip every animation from now on (still exports). Can't be undone without a reload. */
export function freeze() {
  frozen = true;
  apply();
}

export const isFrozen = () => frozen;
export const isSettling = () => frozen || holds > 0;

/** True for components mounting as part of an instant jump, so typed text and chat start complete. */
export const justSettled = () => frozen || performance.now() - lastSettleAt < 120;
