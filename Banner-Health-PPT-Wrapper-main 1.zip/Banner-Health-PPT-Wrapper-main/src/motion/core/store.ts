import type { Bezier, GroupValues, MotionSpec, Preset, PresetValues, RawValue, SpringSpec, Token, TokenGroup, TweenSpec } from "./types";
import { registerGroups, getGroup } from "./registry";
import { resolveToken, timeScale, type DisplayState, type Env, type Resolved } from "./resolve";
import { curves, global } from "../tokens/global";
import { cursor, deck } from "../tokens/deck";

// The live motion state: raw token values (preset + unsaved edits), display flags and replay
// counters. Components read per-group resolved snapshots, cached until that group, the globals,
// the shared curves or the display flags change, so dragging one slider only re-renders the
// components that use that group.

registerGroups(global, curves, deck, cursor);

type State = {
  presetId: string;
  presetName: string;
  /** Values of the loaded preset, for dirty tracking and Revert. */
  baseline: PresetValues;
  /** Current values: the preset plus unsaved edits. Missing keys fall back to registry defaults. */
  values: PresetValues;
  display: DisplayState;
  replay: Record<string, number>;
};

const DEFAULT_DISPLAY: DisplayState = { reducedMotion: "never", teamsSafe: false, slowmo: 1 };

let state: State = {
  presetId: "banner",
  presetName: "Banner",
  baseline: {},
  values: {},
  display: DEFAULT_DISPLAY,
  replay: {},
};

const listeners = new Set<() => void>();
const groupVersions = new Map<string, number>();
let envVersion = 0;
let envCache: { v: number; env: Env } | null = null;
const resolvedCache = new Map<string, { key: string; value: unknown }>();

const ENV_GROUPS = new Set([global.id, curves.id]);

function emit() {
  listeners.forEach((l) => l());
}

function bump(groupId: string) {
  groupVersions.set(groupId, (groupVersions.get(groupId) ?? 0) + 1);
  if (ENV_GROUPS.has(groupId)) envVersion++;
}

function tokenOf(groupId: string, key: string): Token | undefined {
  return getGroup(groupId)?.tokens[key];
}

function rawFrom(values: PresetValues, groupId: string, key: string, fallback?: Token): RawValue | undefined {
  const v = values[groupId]?.[key];
  if (v !== undefined) return v;
  return (fallback ?? tokenOf(groupId, key))?.default;
}

function clone<T>(v: T): T {
  return JSON.parse(JSON.stringify(v)) as T;
}

function buildEnv(): Env {
  const g = (key: keyof typeof global.tokens) => rawFrom(state.values, global.id, key, global.tokens[key]);
  const springs: Record<string, SpringSpec> = {};
  const eases: Record<string, Bezier> = {};
  for (const [key, tok] of Object.entries(curves.tokens) as [string, Token][]) {
    const raw = rawFrom(state.values, curves.id, key, tok);
    if (tok.kind === "ease") eases[key] = raw as Bezier;
    else if (tok.kind === "motion") {
      const spec = raw as MotionSpec;
      if ("type" in spec && spec.type === "spring") springs[key] = spec;
    }
  }
  return {
    speed: g("speed") as number,
    elasticity: g("elasticity") as number,
    maxBounce: g("maxBounce") as number,
    stagger: g("stagger") as number,
    distance: g("distance") as number,
    blur: g("blur") as number,
    type: g("type") as Env["type"],
    overrideSpring: g("overrideSpring") as SpringSpec,
    overrideTween: g("overrideTween") as TweenSpec,
    springs,
    eases,
    teamsSafe: state.display.teamsSafe,
    slowmo: state.display.slowmo,
  };
}

export const motionStore = {
  subscribe(listener: () => void) {
    listeners.add(listener);
    return () => {
      listeners.delete(listener);
    };
  },

  getState: () => state,

  env(): Env {
    if (!envCache || envCache.v !== envVersion) envCache = { v: envVersion, env: buildEnv() };
    return envCache.env;
  },

  /** Seconds multiplier for anything timed outside a token (timers, VO-locked delays). */
  timeScale: () => timeScale(motionStore.env()),

  raw(groupId: string, key: string): RawValue | undefined {
    return rawFrom(state.values, groupId, key);
  },

  baselineRaw(groupId: string, key: string): RawValue | undefined {
    return rawFrom(state.baseline, groupId, key);
  },

  set(groupId: string, key: string, value: RawValue) {
    const group: GroupValues = { ...(state.values[groupId] ?? {}), [key]: value };
    state = { ...state, values: { ...state.values, [groupId]: group } };
    bump(groupId);
    emit();
  },

  /** Back to the loaded preset's value (or the default when the preset doesn't set it). */
  revertToken(groupId: string, key: string) {
    const base = state.baseline[groupId]?.[key];
    const group: GroupValues = { ...(state.values[groupId] ?? {}) };
    if (base === undefined) delete group[key];
    else group[key] = base;
    state = { ...state, values: { ...state.values, [groupId]: group } };
    bump(groupId);
    emit();
  },

  revertAll() {
    motionStore.replaceValues(clone(state.baseline));
  },

  /** Replace every value at once (loading a preset, undo, import). */
  replaceValues(values: PresetValues, baseline?: PresetValues, meta?: { id: string; name: string }) {
    const touched = new Set([...Object.keys(state.values), ...Object.keys(values)]);
    state = {
      ...state,
      values,
      baseline: baseline ?? state.baseline,
      presetId: meta?.id ?? state.presetId,
      presetName: meta?.name ?? state.presetName,
    };
    touched.forEach((g) => bump(g));
    envVersion++;
    emit();
  },

  loadPreset(preset: Pick<Preset, "id" | "name" | "values">) {
    motionStore.replaceValues(clone(preset.values), clone(preset.values), { id: preset.id, name: preset.name });
  },

  /** Number of tokens that differ from the loaded preset. */
  dirtyCount(): number {
    let n = 0;
    const groups = new Set([...Object.keys(state.values), ...Object.keys(state.baseline)]);
    for (const g of groups) {
      const keys = new Set([...Object.keys(state.values[g] ?? {}), ...Object.keys(state.baseline[g] ?? {})]);
      for (const k of keys) {
        if (JSON.stringify(rawFrom(state.values, g, k)) !== JSON.stringify(rawFrom(state.baseline, g, k))) n++;
      }
    }
    return n;
  },

  resolved<T extends Record<string, Token>>(group: TokenGroup<T>): Resolved<T> {
    const key = `${groupVersions.get(group.id) ?? 0}:${envVersion}`;
    const hit = resolvedCache.get(group.id);
    if (hit && hit.key === key) return hit.value as Resolved<T>;
    const env = motionStore.env();
    const out: Record<string, unknown> = {};
    for (const [k, tok] of Object.entries(group.tokens) as [string, Token][]) {
      out[k] = resolveToken(tok, rawFrom(state.values, group.id, k, tok) as RawValue, env);
    }
    resolvedCache.set(group.id, { key, value: out });
    return out as Resolved<T>;
  },

  setDisplay(patch: Partial<DisplayState>) {
    state = { ...state, display: { ...state.display, ...patch } };
    envVersion++;
    emit();
  },

  replay(momentId: string) {
    state = { ...state, replay: { ...state.replay, [momentId]: (state.replay[momentId] ?? 0) + 1 } };
    emit();
  },
};
