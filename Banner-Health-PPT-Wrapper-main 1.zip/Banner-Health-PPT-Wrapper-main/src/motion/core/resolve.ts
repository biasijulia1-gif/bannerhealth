import type { Transition } from "motion/react";
import type {
  Bezier,
  BoolToken,
  EaseToken,
  EnumToken,
  MotionSpec,
  MotionToken,
  NumberToken,
  RawValue,
  SpringSpec,
  StyleToken,
  Token,
  TweenSpec,
} from "./types";

// Turns raw token values into what components hand to Motion. Every global control (speed,
// elasticity, the bounce ceiling, spring/tween override, multipliers, Teams-safe) is applied here
// and nowhere else.

export type DisplayState = {
  /** The deck forces full motion by default, so an OS "reduce motion" setting can't empty the pitch. */
  reducedMotion: "never" | "user" | "always";
  teamsSafe: boolean;
  /** Admin slow-mo (1 = normal, 0.25 = four times slower). Not saved in presets. */
  slowmo: number;
};

export type Env = {
  speed: number;
  elasticity: number;
  maxBounce: number;
  stagger: number;
  distance: number;
  blur: number;
  type: "designed" | "spring" | "tween";
  overrideSpring: SpringSpec;
  overrideTween: TweenSpec;
  springs: Record<string, SpringSpec>;
  eases: Record<string, Bezier>;
  teamsSafe: boolean;
  slowmo: number;
};

export type ResolvedToken<T extends Token> = T extends MotionToken
  ? Transition
  : T extends EaseToken
    ? [number, number, number, number]
    : T extends NumberToken
      ? number
      : T extends EnumToken<infer O>
        ? O
        : T extends StyleToken
          ? string
          : T extends BoolToken
            ? boolean
            : never;

export type Resolved<T extends Record<string, Token>> = { readonly [K in keyof T]: ResolvedToken<T[K]> };

const FALLBACK_SPRING: SpringSpec = { type: "spring", visualDuration: 0.5, bounce: 0.1 };
const FALLBACK_EASE: Bezier = [0.16, 1, 0.3, 1];

/** Seconds multiplier from global speed and slow-mo. */
export const timeScale = (env: Env) => 1 / (Math.max(0.05, env.speed) * Math.max(0.05, env.slowmo));

export function derefSpec(raw: MotionSpec, env: Env): SpringSpec | TweenSpec {
  if ("ref" in raw) return env.springs[raw.ref] ?? FALLBACK_SPRING;
  return raw;
}

export function derefEase(ease: Bezier | string, env: Env): [number, number, number, number] {
  const b = typeof ease === "string" ? (env.eases[ease] ?? FALLBACK_EASE) : ease;
  return [b[0], b[1], b[2], b[3]];
}

export function resolveMotion(tok: MotionToken, raw: MotionSpec, env: Env): Transition {
  let s = derefSpec(raw, env);
  if (!tok.own && env.type !== "designed") s = env.type === "spring" ? env.overrideSpring : env.overrideTween;
  const k = tok.speed === false ? 1 : timeScale(env);
  if (s.type === "spring") {
    return {
      type: "spring",
      visualDuration: s.visualDuration * k,
      bounce: Math.max(0, Math.min(s.bounce * env.elasticity, env.maxBounce)),
    };
  }
  let duration = s.duration * k;
  // Decisive moves read better through a screen share's low frame rate.
  if (env.teamsSafe && tok.role !== "ambient" && tok.role !== "loop" && duration > 0.8) duration *= 0.8;
  return { type: "tween", duration, ease: derefEase(s.ease, env) };
}

export function resolveNumber(tok: NumberToken, v: number, env: Env): number {
  switch (tok.scale ?? "none") {
    case "speed":
      return v * timeScale(env);
    case "stagger":
      return v * env.stagger * timeScale(env);
    case "distance":
      return v * env.distance * (env.teamsSafe ? 1.15 : 1);
    case "blur":
      return v * env.blur * (env.teamsSafe ? 0.35 : 1);
    case "glass":
      return env.teamsSafe ? Math.min(v, 16) : v;
    default:
      return v;
  }
}

export function resolveToken(tok: Token, raw: RawValue, env: Env): unknown {
  switch (tok.kind) {
    case "motion":
      return resolveMotion(tok, raw as MotionSpec, env);
    case "ease":
      return derefEase(raw as Bezier, env);
    case "number":
      return resolveNumber(tok, raw as number, env);
    default:
      return raw;
  }
}
