import { describe, expect, it } from "vitest";
import { blurT, curve, delayT, distanceT, motionT, spring, staggerT, tween } from "./define";
import { resolveMotion, resolveNumber, type Env } from "./resolve";

const env = (patch: Partial<Env> = {}): Env => ({
  speed: 1,
  elasticity: 1,
  maxBounce: 0.35,
  stagger: 1,
  distance: 1,
  blur: 1,
  type: "designed",
  overrideSpring: spring(0.5, 0.1),
  overrideTween: tween(0.6, "outExpo"),
  springs: { soft: spring(0.6, 0.08), pop: spring(0.4, 0.35) },
  eases: { outExpo: [0.16, 1, 0.3, 1], out: [0.22, 1, 0.36, 1] },
  teamsSafe: false,
  slowmo: 1,
  ...patch,
});

describe("resolveMotion", () => {
  it("keeps v1 values at 1× speed", () => {
    expect(resolveMotion(motionT(tween(1.4, "outExpo"), { label: "" }), tween(1.4, "outExpo"), env())).toEqual({
      type: "tween",
      duration: 1.4,
      ease: [0.16, 1, 0.3, 1],
    });
  });

  it("halves durations at 2× speed and doubles them in ½× slow-mo", () => {
    const tok = motionT(tween(1.4, "outExpo"), { label: "" });
    expect(resolveMotion(tok, tween(1.4, "outExpo"), env({ speed: 2 })).duration).toBeCloseTo(0.7);
    expect(resolveMotion(tok, tween(1.4, "outExpo"), env({ slowmo: 0.5 })).duration).toBeCloseTo(2.8);
    const s = resolveMotion(motionT(spring(0.6, 0.1), { label: "" }), spring(0.6, 0.1), env({ speed: 2 }));
    expect(s.visualDuration).toBeCloseTo(0.3);
  });

  it("follows linked curves", () => {
    const r = resolveMotion(motionT(curve("soft"), { label: "" }), curve("soft"), env());
    expect(r).toMatchObject({ type: "spring", visualDuration: 0.6, bounce: 0.08 });
  });

  it("scales bounce with elasticity and caps it at the ceiling", () => {
    const tok = motionT(curve("pop"), { label: "" });
    expect(resolveMotion(tok, curve("pop"), env({ elasticity: 0.5 })).bounce).toBeCloseTo(0.175);
    expect(resolveMotion(tok, curve("pop"), env({ elasticity: 2 })).bounce).toBeCloseTo(0.35);
    expect(resolveMotion(tok, curve("pop"), env({ maxBounce: 0.15 })).bounce).toBeCloseTo(0.15);
  });

  it("applies the global spring/tween override except to own tokens", () => {
    const follows = motionT(tween(0.9, "outExpo"), { label: "" });
    const own = motionT(tween(6, "out"), { label: "", own: true });
    expect(resolveMotion(follows, tween(0.9, "outExpo"), env({ type: "spring" }))).toMatchObject({ type: "spring", visualDuration: 0.5 });
    expect(resolveMotion(own, tween(6, "out"), env({ type: "spring" }))).toMatchObject({ type: "tween", duration: 6 });
  });

  it("shortens long moves in Teams-safe mode, but not ambient drifts", () => {
    expect(resolveMotion(motionT(tween(1.4), { label: "" }), tween(1.4), env({ teamsSafe: true })).duration).toBeCloseTo(1.12);
    expect(resolveMotion(motionT(tween(6), { label: "", role: "ambient" }), tween(6), env({ teamsSafe: true })).duration).toBe(6);
  });
});

describe("resolveNumber", () => {
  it("scales each kind with its own multiplier", () => {
    expect(resolveNumber(delayT(0.55, { label: "" }), 0.55, env({ speed: 2 }))).toBeCloseTo(0.275);
    expect(resolveNumber(staggerT(0.08, { label: "" }), 0.08, env({ stagger: 2, speed: 2 }))).toBeCloseTo(0.08);
    expect(resolveNumber(distanceT(28, { label: "" }), 28, env({ distance: 0.5 }))).toBe(14);
    expect(resolveNumber(blurT(8, { label: "" }), 8, env({ teamsSafe: true }))).toBeCloseTo(2.8);
  });
});
