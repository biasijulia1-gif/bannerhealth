import type {
  Bezier,
  BoolToken,
  EaseToken,
  EnumToken,
  MotionSpec,
  MotionToken,
  NumberToken,
  RefSpec,
  SpringSpec,
  StyleToken,
  Token,
  TokenGroup,
  TweenSpec,
} from "./types";

// Token definition helpers. React-free, so the server can validate presets against the registry.

export const spring = (visualDuration: number, bounce = 0): SpringSpec => ({ type: "spring", visualDuration, bounce });
export const tween = (duration: number, ease: Bezier | string = "outExpo"): TweenSpec => ({ type: "tween", duration, ease });
export const curve = (ref: string): RefSpec => ({ ref });

type MetaOf<T extends Token> = Omit<T, "kind" | "default">;
type NumberMeta = Omit<NumberToken, "kind" | "default" | "min" | "max" | "step"> & Partial<Pick<NumberToken, "min" | "max" | "step">>;

export const motionT = (d: MotionSpec, m: MetaOf<MotionToken>): MotionToken => ({ kind: "motion", default: d, ...m });
export const easeT = (d: Bezier, m: MetaOf<EaseToken>): EaseToken => ({ kind: "ease", default: d, ...m });
export const numT = (d: number, m: MetaOf<NumberToken>): NumberToken => ({ kind: "number", default: d, ...m });

/** Seconds before something starts. Scales with global speed. */
export const delayT = (d: number, m: NumberMeta): NumberToken =>
  numT(d, { min: 0, max: 3, step: 0.01, unit: "s", scale: "speed", ...m });
/** Seconds between items in a sequence. Scales with speed and the stagger multiplier. */
export const staggerT = (d: number, m: NumberMeta): NumberToken =>
  numT(d, { min: 0, max: 0.4, step: 0.005, unit: "s", scale: "stagger", ...m });
/** Travel in px. Scales with the distance multiplier. */
export const distanceT = (d: number, m: NumberMeta): NumberToken =>
  numT(d, { min: 0, max: Math.max(120, d * 3), step: 1, unit: "px", scale: "distance", ...m });
/** Blur radius in px. Scales with the blur multiplier (and Teams-safe). */
export const blurT = (d: number, m: NumberMeta): NumberToken =>
  numT(d, { min: 0, max: Math.max(24, d * 2), step: 0.5, unit: "px", scale: "blur", ...m });
/** A scale factor (start scale, hover grow, tap press). */
export const scaleT = (d: number, m: NumberMeta): NumberToken =>
  numT(d, { min: d < 1 ? 0.3 : 1, max: d < 1 ? 1 : 1.6, step: 0.005, unit: "×", scale: "none", ...m });
/** A plain number that ignores the global multipliers. */
export const plainT = (d: number, m: NumberMeta & Pick<NumberToken, "min" | "max" | "step">): NumberToken =>
  numT(d, { scale: "none", ...m });

export const enumT = <const O extends readonly string[]>(
  options: O,
  d: O[number],
  m: Omit<EnumToken<O[number]>, "kind" | "default" | "options">,
): EnumToken<O[number]> & { options: O } => ({ kind: "enum", options, default: d, ...m });

export const styleT = (d: string, m: MetaOf<StyleToken>): StyleToken => ({ kind: "style", default: d, ...m });
export const boolT = (d: boolean, m: MetaOf<BoolToken>): BoolToken => ({ kind: "bool", default: d, ...m });

export function defineTokens<const T extends Record<string, Token>>(
  id: string,
  meta: { label: string; help?: string; order?: number; moments?: readonly string[] },
  tokens: T,
): TokenGroup<T> {
  return { id, label: meta.label, help: meta.help, order: meta.order ?? 100, moments: meta.moments ?? [], tokens };
}
