import type { GroupValues, Token, TokenGroup } from "./types";

// Every token group the running app knows about. Generic groups register from src/motion/tokens,
// prototype groups register when the prototype module loads, and useTokens() registers lazily.

const groups = new Map<string, TokenGroup>();
const listeners = new Set<() => void>();

export function registerGroups(...defs: TokenGroup[]) {
  let changed = false;
  for (const def of defs) {
    if (groups.get(def.id) === def) continue;
    groups.set(def.id, def as TokenGroup);
    changed = true;
  }
  if (changed) listeners.forEach((l) => l());
}

export function getGroup(id: string): TokenGroup | undefined {
  return groups.get(id);
}

export function allGroups(): TokenGroup[] {
  return [...groups.values()].sort((a, b) => a.order - b.order || a.label.localeCompare(b.label));
}

export function onRegistryChange(listener: () => void) {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

export function defaultsOf(group: TokenGroup): GroupValues {
  const out: GroupValues = {};
  for (const [key, tok] of Object.entries(group.tokens) as [string, Token][]) out[key] = tok.default;
  return out;
}
