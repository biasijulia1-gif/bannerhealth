import type { EnumToken, Token, TokenGroup } from "./types";

// The admin panel's languages. English is the source, written beside each token and group; other
// languages are tables registered next to the groups (Portuguese, for Julia). A table is typed
// against its group, so a token added or renamed without its translation fails the typecheck.

export const LANGS = ["en", "pt"] as const;
export type Lang = (typeof LANGS)[number];

export type OptionText = { label: string; hint?: string };
export type TokenText = { label: string; help?: string; options?: Record<string, OptionText> };

/** A group in one language: its name, what the section moves, and every token (label, or label and help). */
export type GroupTranslation<T extends Record<string, Token> = Record<string, Token>> = {
  label: string;
  help: string;
  tokens: { [K in keyof T]: string | TokenText };
};

type Entry = GroupTranslation & { group: string };

export const defineTranslation = <T extends Record<string, Token>>(group: TokenGroup<T>, text: GroupTranslation<T>): Entry => ({
  group: group.id,
  ...(text as unknown as GroupTranslation),
});

const groups = new Map<string, Entry>();
const moments = new Map<string, string>();

export function registerTranslations(lang: Exclude<Lang, "en">, tables: { groups?: Entry[]; moments?: Record<string, string> }) {
  for (const entry of tables.groups ?? []) groups.set(`${lang}:${entry.group}`, entry);
  for (const [id, label] of Object.entries(tables.moments ?? {})) moments.set(`${lang}:${id}`, label);
}

export function groupText(group: TokenGroup, lang: Lang): { label: string; help?: string } {
  const t = lang === "en" ? undefined : groups.get(`${lang}:${group.id}`);
  return { label: t?.label ?? group.label, help: t?.help ?? group.help };
}

export function tokenText(group: TokenGroup, key: string, lang: Lang): TokenText {
  const tok = group.tokens[key];
  const options = tok.kind === "enum" ? ((tok as EnumToken).optionLabels as Record<string, OptionText> | undefined) : undefined;
  const raw = lang === "en" ? undefined : groups.get(`${lang}:${group.id}`)?.tokens[key];
  if (!raw) return { label: tok.label, help: tok.help, options };
  const t = typeof raw === "string" ? { label: raw } : raw;
  return { label: t.label, help: t.help ?? tok.help, options: t.options ?? options };
}

export const momentText = (id: string, lang: Lang, fallback: string): string =>
  lang === "en" ? fallback : (moments.get(`${lang}:${id}`) ?? fallback);
