"use client";

import { useCallback, useSyncExternalStore } from "react";
import type { Token, TokenGroup } from "./types";
import type { DisplayState, Resolved } from "./resolve";
import { motionStore } from "./store";

/** Resolved values for one token group. Re-renders only when that group (or a global) changes. */
export function useTokens<T extends Record<string, Token>>(group: TokenGroup<T>): Resolved<T> {
  const get = () => motionStore.resolved(group);
  return useSyncExternalStore(motionStore.subscribe, get, get);
}

/** The same values outside React (timers, event handlers, the session). */
export function getTokens<T extends Record<string, Token>>(group: TokenGroup<T>): Resolved<T> {
  return motionStore.resolved(group);
}

/**
 * Speed-aware seconds for timings that aren't worth a token of their own (VO-locked delays).
 * `const s = useTime(); delay: s(0.9)`.
 */
export function useTime(): (seconds: number) => number {
  const k = useSyncExternalStore(motionStore.subscribe, motionStore.timeScale, motionStore.timeScale);
  return useCallback((seconds: number) => seconds * k, [k]);
}

/** Use as the `key` of a moment's root so the admin's Replay remounts (and replays) it. */
export function useReplayKey(momentId: string): string {
  const get = () => motionStore.getState().replay[momentId] ?? 0;
  const n = useSyncExternalStore(motionStore.subscribe, get, get);
  return `${momentId}:${n}`;
}

export function useMotionDisplay(): DisplayState {
  const get = () => motionStore.getState().display;
  return useSyncExternalStore(motionStore.subscribe, get, get);
}
