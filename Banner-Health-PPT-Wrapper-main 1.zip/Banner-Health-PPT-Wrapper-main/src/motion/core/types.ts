// Motion tokens: every duration, curve, distance and variant the deck and its prototypes animate
// with. Components read resolved tokens; the admin panel edits the raw values; presets store them.

export type Bezier = readonly [number, number, number, number];

export type SpringSpec = { type: "spring"; visualDuration: number; bounce: number };
/** `ease` is a bezier or the name of an ease token in the shared `curves` group. */
export type TweenSpec = { type: "tween"; duration: number; ease: Bezier | string };
/** Linked to a spring in the shared `curves` group, like an After Effects ease preset. */
export type RefSpec = { ref: string };
export type MotionSpec = SpringSpec | TweenSpec | RefSpec;

export type Role = "enter" | "exit" | "state" | "layout" | "hover" | "tap" | "ambient" | "loop" | "camera";
export type Unit = "px" | "%" | "s" | "×" | "°" | "em" | "";
/** How a number reacts to the global multipliers. */
export type NumberScale = "speed" | "stagger" | "distance" | "blur" | "glass" | "none";

type Meta = {
  label: string;
  /** Plain-language help, in motion-design terms. */
  help?: string;
  tier?: "basic" | "advanced";
  /** Admin moments that show this token (e.g. "island.open"). */
  moments?: readonly string[];
  /** Only relevant while another token in the group has one of these values. */
  when?: { key: string; is: string | readonly string[] };
  /** Changing it replays the moment automatically. */
  replayOnChange?: boolean;
};

export type MotionToken = Meta & {
  kind: "motion";
  default: MotionSpec;
  role?: Role;
  /** Exempt from the global spring/tween override (loops, ambient drifts, the camera). */
  own?: boolean;
  /** Scales with global speed (default true). */
  speed?: boolean;
};
export type EaseToken = Meta & { kind: "ease"; default: Bezier };
export type NumberToken = Meta & {
  kind: "number";
  default: number;
  min: number;
  max: number;
  step: number;
  unit?: Unit;
  scale?: NumberScale;
};
export type EnumToken<O extends string = string> = Meta & {
  kind: "enum";
  default: O;
  options: readonly O[];
  optionLabels?: Partial<Record<O, { label: string; hint?: string }>>;
};
export type StyleToken = Meta & { kind: "style"; default: string; slot: "enter" | "text" | "transition" };
export type BoolToken = Meta & { kind: "bool"; default: boolean };

export type Token = MotionToken | EaseToken | NumberToken | EnumToken | StyleToken | BoolToken;

export type TokenGroup<T extends Record<string, Token> = Record<string, Token>> = {
  id: string;
  label: string;
  /** What the section moves, in plain words: the admin's section tooltip. */
  help?: string;
  order: number;
  moments: readonly string[];
  tokens: T;
};

export type RawValue = MotionSpec | Bezier | number | string | boolean;
export type GroupValues = Record<string, RawValue>;
/** group id → token key → raw value. Presets are partial: missing keys fall back to defaults. */
export type PresetValues = Record<string, GroupValues>;

export type Preset = {
  schema: 1;
  id: string;
  name: string;
  author?: string;
  updatedAt?: string;
  rev?: number;
  basedOn?: string;
  values: PresetValues;
};
