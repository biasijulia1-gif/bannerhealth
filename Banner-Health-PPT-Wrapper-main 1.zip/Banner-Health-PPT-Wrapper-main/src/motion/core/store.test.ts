import { describe, expect, it } from "vitest";
import { defineTokens, delayT, motionT, tween } from "./define";
import { registerGroups } from "./registry";
import { motionStore } from "./store";

const demo = defineTokens(
  "demo",
  { label: "Demo" },
  {
    open: motionT(tween(1, "outExpo"), { label: "Open" }),
    delay: delayT(0.5, { label: "Delay" }),
  },
);
registerGroups(demo);

describe("motionStore", () => {
  it("resolves defaults and caches snapshots until something changes", () => {
    const a = motionStore.resolved(demo);
    expect(a.delay).toBe(0.5);
    expect(motionStore.resolved(demo)).toBe(a);
    motionStore.set("demo", "delay", 0.8);
    const b = motionStore.resolved(demo);
    expect(b).not.toBe(a);
    expect(b.delay).toBeCloseTo(0.8);
  });

  it("re-resolves every group when a global changes", () => {
    const before = motionStore.resolved(demo);
    motionStore.set("global", "speed", 2);
    const after = motionStore.resolved(demo);
    expect(after).not.toBe(before);
    expect(after.open.duration).toBeCloseTo(0.5);
    motionStore.set("global", "speed", 1);
  });

  it("tracks edits against the loaded preset and reverts them", () => {
    motionStore.loadPreset({ id: "t", name: "T", values: { demo: { delay: 0.3 } } });
    expect(motionStore.dirtyCount()).toBe(0);
    motionStore.set("demo", "delay", 0.9);
    expect(motionStore.dirtyCount()).toBe(1);
    motionStore.revertToken("demo", "delay");
    expect(motionStore.raw("demo", "delay")).toBe(0.3);
    expect(motionStore.dirtyCount()).toBe(0);
  });
});
