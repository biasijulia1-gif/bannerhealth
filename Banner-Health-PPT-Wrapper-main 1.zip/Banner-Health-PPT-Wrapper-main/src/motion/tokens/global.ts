import { defineTokens, easeT, enumT, motionT, plainT, spring, tween } from "../core/define";

// The two engine-wide groups. `global` holds the multipliers Julia reaches for first; `curves`
// holds the shared springs and eases (v1's springs.ts), which other tokens link to by name.

export const global = defineTokens(
  "global",
  {
    label: "Global",
    order: 0,
    help: "Multipliers that change every animation at once. Set the overall feel here, then fine-tune individual moments.",
  },
  {
    speed: plainT(1, {
      min: 0.25,
      max: 2,
      step: 0.05,
      unit: "×",
      label: "Speed",
      help: "Plays everything faster or slower. 2× halves every duration, delay and stagger.",
    }),
    elasticity: plainT(1, {
      min: 0,
      max: 2,
      step: 0.05,
      unit: "×",
      label: "Elasticity",
      help: "Multiplies the bounce of every spring. 0 settles with no overshoot.",
    }),
    maxBounce: plainT(0.35, {
      min: 0,
      max: 0.6,
      step: 0.01,
      label: "Bounce ceiling",
      help: "No spring may bounce more than this. Above ~0.36 a spring wobbles twice, which reads as too playful for healthcare.",
      tier: "advanced",
    }),
    stagger: plainT(1, {
      min: 0,
      max: 3,
      step: 0.05,
      unit: "×",
      label: "Stagger ×",
      help: "Spreads out or tightens the gap between items that arrive one after another, everywhere.",
    }),
    distance: plainT(1, { min: 0, max: 3, step: 0.05, unit: "×", label: "Distance ×", help: "Scales how far elements travel as they enter, everywhere." }),
    blur: plainT(1, { min: 0, max: 3, step: 0.05, unit: "×", label: "Blur ×", help: "Scales how soft elements are as they enter, everywhere." }),
    type: enumT(["designed", "spring", "tween"] as const, "designed", {
      label: "Animation type",
      help: "As designed keeps each moment's own spring or curve. The other two force one spring or one curve on everything, to compare a whole feel quickly.",
      optionLabels: {
        designed: { label: "As designed", hint: "Each moment uses its own spring or curve" },
        spring: { label: "Spring everything", hint: "Every move uses the spring below" },
        tween: { label: "Tween everything", hint: "Every move uses the curve below" },
      },
      tier: "advanced",
    }),
    overrideSpring: motionT(spring(0.55, 0.12), {
      label: "Spring for everything",
      help: "The spring every move uses while Animation type is Spring everything.",
      own: true,
      when: { key: "type", is: "spring" },
      tier: "advanced",
    }),
    overrideTween: motionT(tween(0.6, "outExpo"), {
      label: "Curve for everything",
      help: "The curve every move uses while Animation type is Tween everything.",
      own: true,
      when: { key: "type", is: "tween" },
      tier: "advanced",
    }),
  },
);

export const curves = defineTokens(
  "curves",
  {
    label: "Shared curves",
    order: 1,
    help: "Springs and eases that many animations link to, like ease presets in After Effects. Change one here and everything linked to it follows. An ease is a cubic bezier: its four numbers are the two handles (x1, y1, x2, y2), as in the graph editor.",
  },
  {
    panel: motionT(spring(0.55, 0.12), { label: "Panel", help: "Surfaces opening and morphing (assistant panel, sheets)." }),
    soft: motionT(spring(0.6, 0.08), { label: "Soft", help: "Most entrances and state changes." }),
    snappy: motionT(spring(0.32, 0.18), { label: "Snappy", help: "Pills and toggles that jump to a new spot." }),
    pop: motionT(spring(0.4, 0.35), { label: "Pop", help: "Badges, checks and small confirmations." }),
    layout: motionT(spring(0.5, 0.1), { label: "Layout", help: "Elements reflowing when the layout changes." }),
    glide: motionT(spring(0.75, 0), { label: "Glide", help: "Large surfaces drifting with no bounce (the chat column)." }),
    outExpo: easeT([0.16, 1, 0.3, 1], { label: "Out Expo", help: "Fast start, long gentle stop. Most entrances." }),
    out: easeT([0.22, 1, 0.36, 1], { label: "Out", help: "A softer ease out than Out Expo. Fades and crossfades." }),
    inOutQuart: easeT([0.76, 0, 0.24, 1], { label: "In-Out Quart", help: "Slow start and stop with a quick middle. Wipes and big moves." }),
    easeOut: easeT([0, 0, 0.58, 1], { label: "Ease Out", help: "The classic ease out. Small, quick changes." }),
    easeInOut: easeT([0.42, 0, 0.58, 1], { label: "Ease In-Out", help: "The classic ease in and out. Gentle loops." }),
    linear: easeT([0, 0, 1, 1], { label: "Linear", help: "Constant speed with no easing. Rarely right for interface motion.", tier: "advanced" }),
    camera: easeT([0.45, 0, 0.2, 1], { label: "Camera", help: "A slow, steady push, like a camera move. Used by the prototype zoom (Z).", tier: "advanced" }),
    cursor: easeT([0.65, 0, 0.25, 1], { label: "Cursor travel", help: "How the scripted cursor speeds up and lands.", tier: "advanced" }),
    scroll: easeT([0.65, 0, 0.35, 1], { label: "Scroll", help: "Scripted scrolling inside the site.", tier: "advanced" }),
  },
);
