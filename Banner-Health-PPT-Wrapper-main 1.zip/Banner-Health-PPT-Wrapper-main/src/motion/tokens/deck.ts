import { blurT, defineTokens, distanceT, enumT, motionT, plainT, staggerT, tween } from "../core/define";

// Motion owned by the deck shell: how slides change, how brand-slide builds arrive, the zoom
// between the framed and full-slide site, and the scripted cursor that shows the audience what got
// "clicked".

export const deck = defineTokens(
  "deck",
  {
    label: "Deck",
    order: 5,
    moments: ["deck.transition", "deck.build", "deck.zoom"],
    help: "How the presentation itself moves: slide transitions, brand-slide builds, the prototype zoom (Z) and the frame's fades.",
  },
  {
    transition: enumT(["crossfade", "fade-through", "push", "cut"] as const, "crossfade", {
      label: "Slide transition",
      help: "How one slide replaces the next when you press →. Going back is always instant.",
      moments: ["deck.transition"],
      optionLabels: {
        crossfade: { label: "Crossfade", hint: "Both slides overlap while one fades into the other" },
        "fade-through": { label: "Fade through", hint: "Out to the background, then in" },
        push: { label: "Push", hint: "The new slide slides in and pushes the old one out" },
        cut: { label: "Cut", hint: "No transition" },
      },
    }),
    slide: motionT(tween(0.7, "out"), {
      label: "Slide transition curve",
      help: "Duration and curve of the slide transition.",
      role: "enter",
      moments: ["deck.transition"],
    }),
    pushDistance: plainT(0.18, {
      min: 0,
      max: 1,
      step: 0.01,
      unit: "×",
      label: "Push distance (× slide width)",
      help: "How far a pushed slide travels, as a share of the slide's width.",
      moments: ["deck.transition"],
      when: { key: "transition", is: "push" },
    }),
    buildStyle: enumT(["fade-up", "fade", "blur-in", "mask-rise", "scale-settle"] as const, "fade-up", {
      label: "Build style",
      help: "How the pieces of a brand slide arrive on each → press.",
      moments: ["deck.build"],
      optionLabels: {
        "fade-up": { label: "Fade up", hint: "Rises a little while fading in" },
        fade: { label: "Fade", hint: "Just fades in" },
        "blur-in": { label: "Blur in", hint: "Fades in out of soft focus" },
        "mask-rise": { label: "Mask rise", hint: "Slides up from behind a mask, like a title reveal" },
        "scale-settle": { label: "Scale settle", hint: "Grows slightly into place" },
      },
    }),
    build: motionT(tween(0.9, "outExpo"), { label: "Build curve", help: "Duration and curve of each build.", role: "enter", moments: ["deck.build"] }),
    buildRise: distanceT(24, { label: "Build rise", help: "How far a piece rises as it arrives.", moments: ["deck.build"] }),
    buildBlur: blurT(6, { label: "Build blur", help: "How soft a piece is as it arrives.", moments: ["deck.build"] }),
    buildStagger: staggerT(0.08, { label: "Build stagger", help: "The gap between pieces that build in together.", moments: ["deck.build"] }),
    zoom: motionT(tween(0.8, "camera"), {
      label: "Prototype zoom (Z)",
      help: "The site growing to fill the slide, or shrinking back into the frame. A camera move.",
      role: "camera",
      own: true,
      moments: ["deck.zoom"],
    }),
    frame: motionT(tween(0.5, "out"), {
      label: "Frame and light/dark fades",
      help: "The Valtech frame fading in and out, and the switch between dark and light (T).",
      role: "state",
      tier: "advanced",
    }),
  },
);

export const cursor = defineTokens(
  "cursor",
  {
    label: "Scripted cursor",
    order: 6,
    help: "The pointer that will show the audience what got clicked when you press →. It isn't on screen yet; these settings take effect when it arrives.",
  },
  {
    lead: plainT(0.55, { min: 0.1, max: 2, step: 0.05, unit: "s", label: "Travel time", help: "How long the cursor travels before it clicks." }),
    travel: motionT(tween(0.55, "cursor"), { label: "Travel curve", help: "The curve of the cursor's path to its target.", own: true }),
    press: motionT(
      { type: "spring", visualDuration: 0.15, bounce: 0.4 },
      { label: "Press", help: "The small press when the cursor clicks.", own: true, tier: "advanced" },
    ),
    arc: plainT(0.12, { min: 0, max: 0.4, step: 0.01, label: "Arc", help: "How much the path curves, like a hand." }),
  },
);
