import { defineTranslation, registerTranslations } from "../core/i18n";
import { cursor, deck } from "./deck";
import { curves, global } from "./global";

// Brazilian Portuguese for the engine's own groups, for Julia. Motion terms stay in English where
// that's what After Effects users say (spring, ease, stagger, bounce, blur, overshoot).

registerTranslations("pt", {
  groups: [
    defineTranslation(global, {
      label: "Global",
      help: "Multiplicadores que mudam todas as animações de uma vez. Defina aqui a sensação geral, depois ajuste cada momento.",
      tokens: {
        speed: { label: "Velocidade", help: "Roda tudo mais rápido ou mais devagar. 2× corta pela metade toda duração, atraso e stagger." },
        elasticity: { label: "Elasticidade", help: "Multiplica o bounce de todos os springs. Com 0, tudo assenta sem overshoot." },
        maxBounce: {
          label: "Limite de bounce",
          help: "Nenhum spring passa deste bounce. Acima de ~0,36 o spring oscila duas vezes, o que fica brincalhão demais para saúde.",
        },
        stagger: { label: "Stagger ×", help: "Espaça ou aproxima os itens que entram um depois do outro, em todo lugar." },
        distance: { label: "Distância ×", help: "Multiplica o quanto os elementos se deslocam ao entrar, em todo lugar." },
        blur: { label: "Blur ×", help: "Multiplica o quanto os elementos chegam desfocados, em todo lugar." },
        type: {
          label: "Tipo de animação",
          help: "Como projetado mantém o spring ou a curva de cada momento. As outras duas opções aplicam um único spring ou uma única curva a tudo, para comparar uma sensação geral rapidamente.",
          options: {
            designed: { label: "Como projetado", hint: "Cada momento usa o próprio spring ou curva" },
            spring: { label: "Spring em tudo", hint: "Todo movimento usa o spring abaixo" },
            tween: { label: "Tween em tudo", hint: "Todo movimento usa a curva abaixo" },
          },
        },
        overrideSpring: { label: "Spring para tudo", help: "O spring que todo movimento usa quando o Tipo de animação está em Spring em tudo." },
        overrideTween: { label: "Curva para tudo", help: "A curva que todo movimento usa quando o Tipo de animação está em Tween em tudo." },
      },
    }),
    defineTranslation(curves, {
      label: "Curvas compartilhadas",
      help: "Springs e eases que muitas animações usam por vínculo, como presets de ease no After Effects. Mude um aqui e tudo o que está vinculado a ele acompanha. Um ease é uma bezier cúbica: os quatro números são as duas alças (x1, y1, x2, y2), como no editor de gráficos.",
      tokens: {
        panel: { label: "Painel", help: "Superfícies abrindo e se transformando (painel do assistente, janelas)." },
        soft: { label: "Suave", help: "A maioria das entradas e mudanças de estado." },
        snappy: { label: "Ágil", help: "Pills e toggles que pulam para um novo lugar." },
        pop: { label: "Pop", help: "Selos, checks e pequenas confirmações." },
        layout: { label: "Layout", help: "Elementos se reorganizando quando o layout muda." },
        glide: { label: "Deslize", help: "Superfícies grandes deslizando sem bounce (a coluna do chat)." },
        outExpo: { label: "Out Expo", help: "Começo rápido e parada longa e suave. A maioria das entradas." },
        out: { label: "Out", help: "Um ease out mais suave que o Out Expo. Fades e crossfades." },
        inOutQuart: { label: "In-Out Quart", help: "Começo e fim lentos, com o meio rápido. Cortinas e movimentos grandes." },
        easeOut: { label: "Ease Out", help: "O ease out clássico. Mudanças pequenas e rápidas." },
        easeInOut: { label: "Ease In-Out", help: "O ease in-out clássico. Loops suaves." },
        linear: { label: "Linear", help: "Velocidade constante, sem ease. Raramente fica bom em interface." },
        camera: { label: "Câmera", help: "Um avanço lento e constante, como um movimento de câmera. Usado pelo zoom do protótipo (Z)." },
        cursor: { label: "Trajeto do cursor", help: "Como o cursor roteirizado acelera e pousa." },
        scroll: { label: "Rolagem", help: "A rolagem roteirizada dentro do site." },
      },
    }),
    defineTranslation(deck, {
      label: "Deck",
      help: "Como a própria apresentação se move: transições de slide, builds dos slides de marca, o zoom do protótipo (Z) e os fades da moldura.",
      tokens: {
        transition: {
          label: "Transição de slide",
          help: "Como um slide substitui o outro quando você aperta →. Voltar é sempre instantâneo.",
          options: {
            crossfade: { label: "Crossfade", hint: "Os dois slides se sobrepõem enquanto um se funde no outro" },
            "fade-through": { label: "Fade pelo fundo", hint: "Sai para o fundo, depois entra" },
            push: { label: "Empurrar", hint: "O novo slide entra empurrando o antigo para fora" },
            cut: { label: "Corte", hint: "Sem transição" },
          },
        },
        slide: { label: "Curva da transição de slide", help: "Duração e curva da transição de slide." },
        pushDistance: { label: "Distância do empurrão (× largura do slide)", help: "O quanto um slide empurrado se desloca, em proporção à largura do slide." },
        buildStyle: {
          label: "Estilo de build",
          help: "Como as partes de um slide de marca chegam a cada →.",
          options: {
            "fade-up": { label: "Fade subindo", hint: "Sobe um pouco enquanto aparece" },
            fade: { label: "Fade", hint: "Só aparece" },
            "blur-in": { label: "Desfocado", hint: "Aparece saindo de um foco suave" },
            "mask-rise": { label: "Máscara", hint: "Sobe de trás de uma máscara, como a revelação de um título" },
            "scale-settle": { label: "Escala", hint: "Cresce um pouco até o lugar" },
          },
        },
        build: { label: "Curva do build", help: "Duração e curva de cada build." },
        buildRise: { label: "Subida do build", help: "O quanto uma parte sobe ao chegar." },
        buildBlur: { label: "Blur do build", help: "O quanto uma parte chega desfocada." },
        buildStagger: { label: "Stagger do build", help: "O intervalo entre partes que entram juntas." },
        zoom: { label: "Zoom do protótipo (Z)", help: "O site crescendo para preencher o slide, ou encolhendo de volta para a moldura. Um movimento de câmera." },
        frame: { label: "Fades da moldura e do claro/escuro", help: "A moldura da Valtech aparecendo e sumindo, e a troca entre escuro e claro (T)." },
      },
    }),
    defineTranslation(cursor, {
      label: "Cursor roteirizado",
      help: "O ponteiro que vai mostrar à plateia o que foi clicado quando você aperta →. Ele ainda não aparece na tela; estas configurações valem quando ele chegar.",
      tokens: {
        lead: { label: "Tempo de trajeto", help: "Quanto tempo o cursor viaja antes de clicar." },
        travel: { label: "Curva do trajeto", help: "A curva do caminho do cursor até o alvo." },
        press: { label: "Clique", help: "A pequena pressionada quando o cursor clica." },
        arc: { label: "Arco", help: "O quanto o caminho faz curva, como uma mão." },
      },
    }),
  ],
});
