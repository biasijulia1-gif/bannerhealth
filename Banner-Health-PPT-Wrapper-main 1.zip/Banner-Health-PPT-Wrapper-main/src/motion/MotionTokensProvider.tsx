"use client";

import { MotionConfig } from "motion/react";
import { useCallback, useEffect, useRef } from "react";
import { motionStore } from "./core/store";
import { useMotionDisplay } from "./core/hooks";

export type StageTransform = {
  /** Total scale between the screen and this subtree's layout pixels. */
  getScale(): number;
};

/**
 * Wraps the deck (or a standalone prototype) in the motion runtime:
 * - `reducedMotion` from the display settings. The deck forces full motion by default; the key
 *   remounts the subtree because Motion reads this once per element, at mount.
 * - `transformPagePoint`, which maps screen points into unscaled layout pixels. Without it, layout
 *   and shared-element morphs start from the wrong place whenever the stage isn't at 1×.
 * - CSS variables (`--m-speed`) so CSS transitions follow global speed too.
 */
export function MotionTokensProvider({ children, stage }: { children: React.ReactNode; stage?: StageTransform }) {
  const display = useMotionDisplay();
  const root = useRef<HTMLDivElement>(null);

  const transformPagePoint = useCallback(
    (p: { x: number; y: number }) => {
      const s = stage?.getScale() ?? 1;
      return s === 1 ? p : { x: p.x / s, y: p.y / s };
    },
    [stage],
  );

  useEffect(() => {
    const write = () => {
      const el = root.current;
      if (!el) return;
      el.style.setProperty("--m-speed", String(1 / motionStore.timeScale()));
    };
    write();
    return motionStore.subscribe(write);
  }, []);

  return (
    <MotionConfig key={display.reducedMotion} reducedMotion={display.reducedMotion} transformPagePoint={transformPagePoint}>
      <div
        ref={root}
        data-motion-root=""
        data-teams-safe={display.teamsSafe ? "" : undefined}
        data-reduced-motion={display.reducedMotion}
        className="contents"
      >
        {children}
      </div>
    </MotionConfig>
  );
}

/** A nested coordinate space, e.g. a prototype rendered at 0.75× inside the stage. */
export function ScaledSpace({ children, getScale }: { children: React.ReactNode; getScale: () => number }) {
  const transformPagePoint = useCallback(
    (p: { x: number; y: number }) => {
      const s = getScale();
      return s === 1 ? p : { x: p.x / s, y: p.y / s };
    },
    [getScale],
  );
  return <MotionConfig transformPagePoint={transformPagePoint}>{children}</MotionConfig>;
}
