// Public API of the motion runtime. Prototypes and slides import from "@/motion" only.
// The engine's own Portuguese (the admin's second language) registers with the engine.
import "./tokens/pt";

export * from "./core/types";
export * from "./core/define";
export { registerGroups, allGroups, getGroup, onRegistryChange, defaultsOf } from "./core/registry";
export { motionStore } from "./core/store";
export { useTokens, getTokens, useTime, useReplayKey, useMotionDisplay } from "./core/hooks";
export type { DisplayState, Env, Resolved, ResolvedToken } from "./core/resolve";
export { global, curves } from "./tokens/global";
export { deck, cursor } from "./tokens/deck";
export { settle, freeze, isFrozen, isSettling, justSettled } from "./instant";
export { MotionTokensProvider, ScaledSpace, type StageTransform } from "./MotionTokensProvider";
export {
  LANGS,
  defineTranslation,
  registerTranslations,
  groupText,
  tokenText,
  momentText,
  type Lang,
  type TokenText,
  type OptionText,
  type GroupTranslation,
} from "./core/i18n";
