import type { DeckTheme } from "@/shell/theme";
import { ValtechAnnotation, ValtechFrame } from "./Frame";

export const valtechTheme: DeckTheme = {
  Frame: ValtechFrame,
  Annotation: ValtechAnnotation,
  letterbox: "#000000",
};
