import type { AnnotationProps, FrameProps } from "@/shell/theme";

// The Valtech frame, per the brand folder: wordmark and deck label top-left, slide number
// top-right, asterisk bottom-right, optional spectrum band. Its own motion is a simple fade.
export function ValtechFrame({ tone, visible, number, showNumber, band, label, transition }: FrameProps) {
  const dark = tone === "dark";
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 z-[40] font-val-sans"
      style={{ opacity: visible ? 1 : 0, color: dark ? "#ffffff" : "#000000", transition }}
    >
      <div className="absolute top-[50px] left-[64px] flex items-center gap-5">
        <span className="relative block h-[26px] w-[118px]">
          <img src="/themes/valtech/logos/valtech-logo-white.png" alt="" className="absolute inset-0 h-full w-full object-contain object-left" style={{ opacity: dark ? 1 : 0, transition }} />
          <img src="/themes/valtech/logos/valtech-logo-black.png" alt="" className="absolute inset-0 h-full w-full object-contain object-left" style={{ opacity: dark ? 0 : 1, transition }} />
        </span>
        <span className="h-[20px] w-px bg-current opacity-30" />
        <span className="text-[17px] leading-none tracking-[0.01em]">{label}</span>
      </div>
      {showNumber && (
        <span className="absolute top-[50px] right-[64px] text-[17px] leading-[26px] tabular-nums">{String(number).padStart(2, "0")}</span>
      )}
      <span className="absolute right-[64px] bottom-[50px] block size-[28px]">
        <img src="/themes/valtech/logos/valtech-asterisk-white.png" alt="" className="absolute inset-0 size-full" style={{ opacity: dark ? 1 : 0, transition }} />
        <img src="/themes/valtech/logos/valtech-asterisk-black.png" alt="" className="absolute inset-0 size-full" style={{ opacity: dark ? 0 : 1, transition }} />
      </span>
      <div className="val-spectrum absolute inset-x-0 bottom-0 h-[6px]" style={{ opacity: band ? 1 : 0, transition }} />
    </div>
  );
}

// Placeholder look for on-canvas notes until Sebastian designs them.
export function ValtechAnnotation({ text, visible, transition }: AnnotationProps) {
  return (
    <div
      className="pointer-events-none absolute bottom-[110px] left-[64px] z-[45] max-w-[560px] border border-val-stone bg-val-bone px-7 py-6 font-val-sans text-[21px] leading-[1.45] text-black"
      style={{ opacity: visible ? 1 : 0, transform: visible ? "translateY(0)" : "translateY(16px)", transition }}
    >
      {text}
    </div>
  );
}
