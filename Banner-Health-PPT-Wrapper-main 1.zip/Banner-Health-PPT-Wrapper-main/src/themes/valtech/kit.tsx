// Building blocks for brand slides at the 1920×1080 canvas size. Copy Figma frames with Place
// for pixel-exact layouts; the type pieces carry the Valtech type rules (Neue Light headlines,
// Sons body, accent kicker rule, sentence case body). Colors come from the slide's tone
// (text-tone-fg, text-tone-dim, bg-tone-accent: lime on dark, signal red on light), so every slide
// works in the dark and the light version.

export function Place({ x, y, w, h, children, className = "" }: { x: number; y: number; w?: number; h?: number; children: React.ReactNode; className?: string }) {
  return (
    <div className={`absolute ${className}`} style={{ left: x, top: y, width: w, height: h }}>
      {children}
    </div>
  );
}

export function Kicker({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-4 font-val-sans">
      <span className="h-[2px] w-[46px] bg-tone-accent" />
      <span className="text-[18px] tracking-[0.14em] text-tone-dim uppercase">{children}</span>
    </div>
  );
}

export function Title({ children, size = 104, className = "" }: { children: React.ReactNode; size?: number; className?: string }) {
  return (
    <h1 className={`font-val-display font-light leading-[1.02] tracking-[-0.025em] ${className}`} style={{ fontSize: size }}>
      {children}
    </h1>
  );
}

export function Body({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return <p className={`font-val-sans text-[28px] leading-[1.4] font-light text-tone-dim ${className}`}>{children}</p>;
}

/** Marks a slide as a stand-in until Sebastian's design arrives. */
export function PlaceholderTag() {
  return (
    <div className="absolute bottom-[50px] left-[64px] font-val-sans text-[14px] tracking-[0.12em] text-tone-fg/35 uppercase">
      Placeholder slide · final design from Sebastian
    </div>
  );
}
