import { defineDeck } from "@/shell/deck/schema";
import { FollowUpSlide, MeetLuisaSlide, ThanksSlide, TitleSlide } from "./slides/Placeholders";

// The Banner pitch, in order. Brand slides are placeholders until Sebastian's frames arrive; the
// slide list and the strategy-to-experience handoff point are still open with Seth.
export const bannerDeck = defineDeck({
  id: "banner",
  title: "Banner Health",
  label: "Banner Health",
  // The look the deck opens in. T flips dark/light and Z zooms the site to fill the slide, live.
  tone: "dark",
  presentation: "framed",
  slides: [
    {
      id: "title",
      type: "brand",
      title: "Title",
      Component: TitleSlide,
      frame: { number: false, band: true },
      notes: "Hand-off from strategy. The experience begins with the brand.",
    },
    {
      id: "meet-luisa",
      type: "brand",
      title: "Meet Luisa",
      Component: MeetLuisaSlide,
      builds: 2,
      // The contrast slide: light in the dark version, dark in the light one.
      tone: "invert",
      notes: "Introduce Luisa: Mesa, a recurring stomach issue. Three moments with the AI assistant.",
      annotation: "Luisa is a returning Banner patient. Everything that follows is the live prototype.",
    },
    {
      id: "triage",
      type: "prototype",
      title: "Triage to urgent care",
      prototype: "banner",
      from: "home",
      to: "triage.result",
      entry: "play",
      notes: "Luisa asks the homepage assistant about belly pain. The symptom checker routes her to the right care, with the soonest times.",
      stepNotes: {
        "triage.compose": "The prompt is the front door: plain language, no menus.",
        "triage.warning": "Red-flag symptoms would route to emergency care instead.",
      },
      annotation: "One question in plain language. The site does the routing.",
    },
    {
      id: "follow-up",
      type: "brand",
      title: "A follow-up with the right specialist",
      Component: FollowUpSlide,
      notes: "Two days later Luisa needs a GI doctor who speaks Spanish.",
    },
    {
      id: "find-doctor",
      type: "prototype",
      title: "Find a doctor, book, return visit",
      prototype: "banner",
      from: "followup",
      to: "outro",
      entry: "settled",
      notes: "The assistant asks only what it needs (insurance, location), then shows six matching doctors. Booking takes two taps. On her next visit the site knows her, and switches to Spanish in one tap.",
      stepNotes: {
        doctors: "Results already match her insurance and language.",
        return: "Time passes: the return visit is personalized.",
      },
    },
    {
      id: "thanks",
      type: "brand",
      title: "Thank you",
      Component: ThanksSlide,
      frame: { number: false },
    },
  ],
});
