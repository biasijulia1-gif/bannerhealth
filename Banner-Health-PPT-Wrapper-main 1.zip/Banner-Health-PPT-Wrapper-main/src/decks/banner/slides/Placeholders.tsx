import { Build } from "@/shell/builds/Build";
import { Body, Kicker, Place, PlaceholderTag, Title } from "@/themes/valtech/kit";

// Stand-ins for Sebastian's brand slides, so the deck runs end to end today. Each becomes one
// file built from his Figma frames (build order from the layer names, e.g. "Title [1]"). Type
// colors follow the slide's tone, so each one works in the dark and the light version.

export function TitleSlide() {
  return (
    <div className="absolute inset-0 text-tone-fg">
      <Place x={160} y={330} w={1400}>
        <Build order={0} delay={0.2}>
          <Kicker>Experience</Kicker>
        </Build>
        <Build order={1} delay={0.2} className="mt-10">
          <Title size={150}>Banner Health</Title>
        </Build>
        <Build order={2} delay={0.2} className="mt-8 max-w-[900px]">
          <Body>AI-assisted patient journeys, shown live.</Body>
        </Build>
      </Place>
      <PlaceholderTag />
    </div>
  );
}

export function MeetLuisaSlide() {
  return (
    <div className="absolute inset-0 text-tone-fg">
      <Place x={160} y={250} w={1500}>
        <Build>
          <Kicker>The journeys</Kicker>
        </Build>
        <Build order={1} className="mt-10">
          <Title>Meet Luisa</Title>
        </Build>
        <Build at={1} className="mt-14 max-w-[1100px]">
          <Body>Luisa lives in Mesa and has a stomach issue that keeps coming back.</Body>
        </Build>
        <Build at={2} className="mt-6 max-w-[1100px]">
          <Body>Three moments show how Banner&apos;s AI assistant meets her where she is: on the homepage, in a conversation, and on her next visit.</Body>
        </Build>
      </Place>
      <PlaceholderTag />
    </div>
  );
}

export function FollowUpSlide() {
  return (
    <div className="absolute inset-0 text-tone-fg">
      <Place x={160} y={380} w={1500}>
        <Build>
          <Kicker>Journey 2</Kicker>
        </Build>
        <Build order={1} className="mt-10">
          <Title>A Follow-Up With the Right Specialist</Title>
        </Build>
      </Place>
      <PlaceholderTag />
    </div>
  );
}

export function ThanksSlide() {
  return (
    <div className="absolute inset-0 text-tone-fg">
      <Place x={160} y={400} w={1500}>
        <Build>
          <Title size={150}>Thank You</Title>
        </Build>
      </Place>
      <PlaceholderTag />
    </div>
  );
}
