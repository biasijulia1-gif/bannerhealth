import { describe, expect, it } from "vitest";
import { deckSequence } from "@/shell/deck/url";
import { derivePresenter } from "@/shell/presenter/model";
import { manifests } from "@/prototypes/manifests";
import { bannerDeck } from "./deck.config";

// The presenter view against the real deck: its next card must match what → does at every position.

describe("the Banner deck in the presenter", () => {
  const stepsOf = (id: string) => manifests[id]?.steps ?? [];
  const sequence = deckSequence(bannerDeck, stepsOf);

  it("says, at every position, exactly where the next → lands", () => {
    expect(sequence).toHaveLength(23);
    sequence.forEach((p, k) => {
      const { index, slideId, ...pos } = p;
      const next = derivePresenter(bannerDeck, manifests, {
        index,
        count: bannerDeck.slides.length,
        slideId,
        pos,
        black: false,
        notes: false,
        look: { tone: "dark", site: "framed" },
        auto: true,
      }).next;
      const want = sequence[k + 1];
      if (!want) return expect(next.kind).toBe("end");
      if (next.kind === "end") throw new Error(`${slideId} ended early`);
      const { index: wi, slideId: ws, ...wpos } = want;
      expect({ index: next.card.index, slideId: next.card.slideId, ...next.card.pos }).toEqual({ index: wi, slideId: ws, ...wpos });
    });
  });

  it("warns that Searching moves on by itself", () => {
    const i = bannerDeck.slides.findIndex((s) => s.id === "find-doctor");
    const p = derivePresenter(bannerDeck, manifests, {
      index: i,
      count: bannerDeck.slides.length,
      slideId: "find-doctor",
      pos: { step: "finddr.location" },
      black: false,
      notes: false,
      look: { tone: "dark", site: "framed" },
      auto: true,
    });
    expect(p.next).toMatchObject({ kind: "step", action: "Find doctor · Searching", then: "then moves on by itself to Doctors · Results" });
  });
});
