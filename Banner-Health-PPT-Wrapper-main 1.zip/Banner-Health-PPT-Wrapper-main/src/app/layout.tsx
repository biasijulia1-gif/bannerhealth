import type { Metadata, Viewport } from "next";
import { Manrope, Source_Serif_4 } from "next/font/google";
import "./globals.css";

// Banner's site faces. The Valtech deck faces load from public/ via themes/valtech/theme.css.
const manrope = Manrope({
  variable: "--font-manrope",
  subsets: ["latin"],
});

// Closest open stand-in for Utopia Std Display (Banner's licensed serif).
const serifDisplay = Source_Serif_4({
  variable: "--font-serif-display",
  subsets: ["latin"],
  axes: ["opsz"],
});

export const metadata: Metadata = {
  title: "Banner Health · Valtech",
  description: "Banner Health experience presentation with the live AI-journeys prototype.",
  robots: { index: false, follow: false },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: "#000000",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html
      lang="en"
      className={`${manrope.variable} ${serifDisplay.variable} h-full antialiased`}
      data-brand-fonts={process.env.NEXT_PUBLIC_BRAND_FONTS === "fallback" ? "fallback" : undefined}
    >
      <body className="h-full">{children}</body>
    </html>
  );
}
