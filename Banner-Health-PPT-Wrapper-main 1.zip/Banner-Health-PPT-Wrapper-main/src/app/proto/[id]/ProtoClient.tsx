"use client";

import dynamic from "next/dynamic";
import { useParams } from "next/navigation";

const Standalone = dynamic(
  () =>
    Promise.all([import("@/shell/standalone/StandalonePrototype"), import("@/prototypes")]).then(([s, p]) => {
      function Loaded({ id }: { id: string }) {
        return <s.StandalonePrototype prototype={p.getPrototype(id)} />;
      }
      return Loaded;
    }),
  { ssr: false, loading: () => <div className="h-dvh bg-white" /> },
);

export function ProtoClient() {
  const { id } = useParams<{ id: string }>();
  return <Standalone id={id} />;
}
