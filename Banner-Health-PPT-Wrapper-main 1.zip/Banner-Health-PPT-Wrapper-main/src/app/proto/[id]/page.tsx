import { Suspense } from "react";
import { ProtoClient } from "./ProtoClient";

export function generateStaticParams() {
  return [{ id: "banner" }];
}

// useParams suspends in the shell Next prerenders for ids not listed above (Cache Components with
// Partial Prefetching), so it needs a boundary or the build fails.
export default function Page() {
  return (
    <Suspense fallback={<div className="h-dvh bg-white" />}>
      <ProtoClient />
    </Suspense>
  );
}
