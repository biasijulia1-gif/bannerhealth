import { DeckClient } from "./DeckClient";

export default function DeckPage() {
  return <DeckClient />;
}
