"use client";

import dynamic from "next/dynamic";

// The deck is fully client-side (keyboard, live prototypes, motion runtime), so skip SSR.
export const DeckClient = dynamic(
  () =>
    Promise.all([import("@/shell/deck/Deck"), import("@/decks/banner/deck.config"), import("@/prototypes"), import("@/themes/valtech")]).then(
      ([{ Deck }, { bannerDeck }, { prototypes }, { valtechTheme }]) => {
        function BannerDeck() {
          return <Deck deck={bannerDeck} prototypes={prototypes} theme={valtechTheme} />;
        }
        return BannerDeck;
      },
    ),
  { ssr: false, loading: () => <div className="h-dvh bg-black" /> },
);
