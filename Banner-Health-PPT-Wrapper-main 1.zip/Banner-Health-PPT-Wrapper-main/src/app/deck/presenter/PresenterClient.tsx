"use client";

import dynamic from "next/dynamic";

// The presenter's private window (P in the deck). Client-only like the deck: it follows the deck
// window over a BroadcastChannel and loads plain data, never the prototypes.
export const PresenterClient = dynamic(
  () =>
    Promise.all([import("@/shell/presenter/Presenter"), import("@/decks/banner/deck.config"), import("@/prototypes/manifests")]).then(
      ([{ Presenter }, { bannerDeck }, { manifests }]) => {
        function BannerPresenter() {
          return <Presenter deck={bannerDeck} manifests={manifests} />;
        }
        return BannerPresenter;
      },
    ),
  { ssr: false, loading: () => <div className="h-dvh bg-black" /> },
);
