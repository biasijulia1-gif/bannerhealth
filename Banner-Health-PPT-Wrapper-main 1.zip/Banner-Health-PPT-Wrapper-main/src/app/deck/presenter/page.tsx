import type { Metadata } from "next";
import { PresenterClient } from "./PresenterClient";

// Easy to pick out in Teams' window list, and never the one to share.
export const metadata: Metadata = { title: "Presenter (private) · Banner Health" };

export default function PresenterPage() {
  return <PresenterClient />;
}
