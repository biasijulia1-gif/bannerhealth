import type { SlidePos } from "../deck/machine";
import { defaultLook, presentationOf, toneOf, type DeckConfig, type Presentation, type Tone } from "../deck/schema";
import { startPos } from "../deck/url";
import type { PrototypeManifest } from "../prototype/contract";
import type { AudienceState } from "./protocol";
import { s } from "./strings";

// What the presenter view shows, as a pure function of the deck config, the prototypes' manifests
// and where the deck window is. The next card mirrors what → does in the deck.

export type PresenterManifest = Pick<PrototypeManifest, "steps" | "labels" | "auto">;
export type DeckPosition = Pick<AudienceState, "index" | "count" | "slideId" | "pos" | "black" | "notes" | "look" | "auto">;

export type SlideCard = {
  index: number;
  number: number;
  count: number;
  slideId: string;
  title: string;
  type: "brand" | "prototype";
  pos: SlidePos;
  /** "Step 4/5 · Triage · Warning signs", "Build 1 of 2", "2 builds" before the first, or "" without builds. */
  detail: string;
  step?: { id: string; label: string; n: number; of: number };
  build?: { at: number; of: number };
  /** The slide's ground in the deck's current version, so the card mirrors it. */
  tone: Tone;
  site?: Presentation;
};

export type NextCard =
  | { kind: "build" | "step"; action: string; then?: string; card: SlideCard }
  | { kind: "slide"; action: string; card: SlideCard }
  | { kind: "unblack"; action: string; card: SlideCard }
  | { kind: "end"; action: string };

export type StepRow = { step: string; label: string; n: number; state: "done" | "current" | "todo"; auto: boolean; note: boolean };

export type PresenterModel = {
  /** The deck window runs the same slide list. */
  inSync: boolean;
  current: SlideCard & { autoNote?: string };
  next: NextCard;
  slides: Array<{ index: number; title: string; state: "done" | "current" | "todo" }>;
  steps: StepRow[] | null;
  builds: { at: number; of: number } | null;
  notes: { slide?: string; step?: string };
  annotation: { text: string; shown: boolean } | null;
  durationHintMs: number | null;
  /** The sum of every slide's durationHint, when any slide has one. */
  plannedMs: number | null;
};

const clamp = (n: number, lo: number, hi: number) => Math.max(lo, Math.min(hi, n));

function card(deck: DeckConfig, manifests: Record<string, PresenterManifest>, index: number, pos: SlidePos, look: DeckPosition["look"]): SlideCard {
  const slide = deck.slides[index];
  const base = { index, number: index + 1, count: deck.slides.length, slideId: slide.id, title: slide.title, tone: toneOf(slide, look.tone) };
  if (slide.type === "brand") {
    const of = slide.builds ?? 0;
    const at = clamp(pos.build ?? 0, 0, of);
    return { ...base, type: "brand", pos: { build: at }, detail: !of ? "" : at ? s.build(at, of) : s.buildsToCome(of), build: { at, of } };
  }
  const m = manifests[slide.prototype];
  const steps = m?.steps ?? [];
  const a = steps.indexOf(slide.from);
  const z = steps.indexOf(slide.to);
  const found = pos.step ? steps.indexOf(pos.step) : -1;
  const i = found >= 0 ? found : a;
  const id = steps[i] ?? slide.from;
  const label = m?.labels[id] ?? id;
  const n = i - a + 1;
  const of = z - a + 1;
  return {
    ...base,
    type: "prototype",
    pos: { step: id },
    detail: i >= a && i <= z ? s.step(n, of, label) : s.byHand(label),
    step: { id, label, n, of },
    site: presentationOf(slide, look),
  };
}

function nextCard(deck: DeckConfig, manifests: Record<string, PresenterManifest>, p: DeckPosition, current: SlideCard): NextCard {
  if (p.black) return { kind: "unblack", action: s.clears(p.black), card: current };
  const slide = deck.slides[current.index];
  if (slide.type === "brand" && current.build && current.build.at < current.build.of) {
    const at = current.build.at + 1;
    return { kind: "build", action: s.build(at, current.build.of), card: card(deck, manifests, current.index, { build: at }, p.look) };
  }
  if (slide.type === "prototype") {
    const m = manifests[slide.prototype];
    const steps = m?.steps ?? [];
    const i = steps.indexOf(current.pos.step ?? "");
    if (m && i >= 0 && i < steps.indexOf(slide.to)) {
      const step = steps[i + 1];
      const auto = p.auto && slide.autoAdvance !== false ? m.auto?.[step] : undefined;
      return {
        kind: "step",
        action: m.labels[step] ?? step,
        then: auto ? s.thenAuto(m.labels[auto.to] ?? auto.to) : undefined,
        card: card(deck, manifests, current.index, { step }, p.look),
      };
    }
  }
  const after = current.index + 1;
  if (after < deck.slides.length) {
    return { kind: "slide", action: s.nextSlide(deck.slides[after].title), card: card(deck, manifests, after, startPos(deck.slides[after]), p.look) };
  }
  return { kind: "end", action: s.endOfDeck };
}

export function derivePresenter(deck: DeckConfig, manifests: Record<string, PresenterManifest>, p: DeckPosition): PresenterModel {
  const byId = deck.slides.findIndex((x) => x.id === p.slideId);
  const index = byId >= 0 ? byId : clamp(p.index, 0, deck.slides.length - 1);
  const slide = deck.slides[index];
  const current = card(deck, manifests, index, p.pos, p.look);
  const hints = deck.slides.map((x) => x.durationHint).filter((h): h is number => typeof h === "number");

  let steps: StepRow[] | null = null;
  let autoNote: string | undefined;
  if (slide.type === "prototype") {
    const m = manifests[slide.prototype];
    const all = m?.steps ?? [];
    const a = all.indexOf(slide.from);
    const i = all.indexOf(current.pos.step ?? "");
    const autoOn = p.auto && slide.autoAdvance !== false;
    steps = all.slice(a, all.indexOf(slide.to) + 1).map((step, k) => ({
      step,
      label: m?.labels[step] ?? step,
      n: k + 1,
      state: a + k < i ? "done" : a + k === i ? "current" : "todo",
      auto: !!(autoOn && m?.auto?.[step]),
      note: !!slide.stepNotes?.[step],
    }));
    const auto = autoOn ? m?.auto?.[current.pos.step ?? ""] : undefined;
    if (auto) autoNote = s.autoNote(m?.labels[auto.to] ?? auto.to);
  }

  return {
    inSync: p.count === deck.slides.length && byId === p.index,
    current: { ...current, autoNote },
    next: nextCard(deck, manifests, p, current),
    slides: deck.slides.map((x, k) => ({ index: k, title: x.title, state: k < index ? "done" : k === index ? "current" : "todo" })),
    steps,
    builds: current.build && current.build.of > 0 ? current.build : null,
    notes: { slide: slide.notes, step: slide.type === "prototype" ? slide.stepNotes?.[current.pos.step ?? ""] : undefined },
    annotation: slide.annotation ? { text: slide.annotation, shown: p.notes } : null,
    durationHintMs: slide.durationHint ? slide.durationHint * 60_000 : null,
    plannedMs: hints.length ? hints.reduce((sum, h) => sum + h, 0) * 60_000 : null,
  };
}

/** What to show before any deck window has connected: the deck's first slide. */
export function waitingPosition(deck: DeckConfig): DeckPosition {
  const first = deck.slides[0];
  return { index: 0, count: deck.slides.length, slideId: first.id, pos: startPos(first), black: false, notes: false, look: defaultLook(deck), auto: true };
}

/** True at the deck's very first position (the timer doesn't start just because the presenter connected). */
export function atDeckStart(deck: DeckConfig, p: Pick<DeckPosition, "index" | "pos">): boolean {
  const first = deck.slides[0];
  if (p.index !== 0 || !first) return false;
  return first.type === "brand" ? (p.pos.build ?? 0) === 0 : (p.pos.step ?? first.from) === first.from;
}
