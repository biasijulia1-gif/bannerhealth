import { HEARTBEAT_MS, LOST_AFTER_MS, PRESENCE_MS, PROTOCOL, newId, readMessage, type AudienceState, type PresenterCommand } from "./protocol";
import type { Transport } from "./transport";

// Both ends of the presenter link, without React: who's there, what the deck shows, and commands
// that run exactly once in the deck window the presenter follows.

/** The deck window's end: sends its state on change and as a heartbeat, runs the presenter's commands. */
export function createAudienceLink(o: {
  deckId: string;
  transport: Transport;
  read(): Omit<AudienceState, "claimedAt">;
  run(cmd: PresenterCommand): void;
  now?: () => number;
}) {
  const id = newId();
  const now = o.now ?? (() => Date.now());
  const envelope = { v: PROTOCOL, deck: o.deckId, from: id } as const;
  const seen: string[] = [];
  let claimedAt = 0;
  let last = "";
  let closed = false;

  const sendState = () => {
    const state: AudienceState = { ...o.read(), claimedAt };
    last = JSON.stringify(state);
    o.transport.send({ ...envelope, type: "state", role: "audience", state });
  };

  const unsubscribe = o.transport.subscribe((data) => {
    const m = readMessage(data, o.deckId);
    if (!m || m === "incompatible" || m.role !== "presenter") return;
    if (m.type === "hello") sendState();
    if (m.type === "cmd" && m.to === id && !seen.includes(m.id)) {
      seen.push(m.id);
      if (seen.length > 32) seen.shift();
      o.run(m.cmd);
    }
  });
  const heartbeat = setInterval(sendState, HEARTBEAT_MS);
  o.transport.send({ ...envelope, type: "hello", role: "audience" });
  sendState();

  return {
    id,
    /** Sends the state now if it changed since the last send. */
    changed() {
      if (!closed && JSON.stringify({ ...o.read(), claimedAt }) !== last) sendState();
    },
    /** P was pressed here, so the presenter follows this window. */
    claim() {
      claimedAt = now();
      if (!closed) sendState();
    },
    close() {
      if (closed) return;
      closed = true;
      clearInterval(heartbeat);
      unsubscribe();
      o.transport.send({ ...envelope, type: "bye", role: "audience" });
    },
  };
}

export type LinkStatus = { kind: "waiting"; reason: "never" | "closed" } | { kind: "connected" } | { kind: "lost"; lastSeen: number };

export type PresenterSnapshot = {
  status: LinkStatus;
  /** What the followed deck window shows (kept after it goes quiet, so the notes stay up). */
  state: AudienceState | null;
  /** Deck windows heard from recently. */
  decks: number;
  /** A deck window on another protocol version is talking: reload both. */
  incompatible: boolean;
};

export type PresenterLink = ReturnType<typeof createPresenterLink>;

/** The presenter's end: follows one deck window (the last one where P was pressed) and sends it commands. */
export function createPresenterLink(o: { deckId: string; transport: Transport; now?: () => number }) {
  const id = newId();
  const now = o.now ?? (() => Date.now());
  const envelope = { v: PROTOCOL, deck: o.deckId, from: id } as const;
  type Peer = { firstSeen: number; lastSeen: number; state: AudienceState | null };
  const decks = new Map<string, Peer>();
  const listeners = new Set<() => void>();
  let followed: string | null = null;
  let lastState: AudienceState | null = null;
  let closedOnce = false;
  let incompatible = false;
  let snap: PresenterSnapshot = { status: { kind: "waiting", reason: "never" }, state: null, decks: 0, incompatible: false };

  const alive = (p: Peer, t: number) => t - p.lastSeen < LOST_AFTER_MS;

  const recompute = () => {
    const t = now();
    const live = [...decks.entries()].filter(([, p]) => alive(p, t));
    // Follow the live window where P was pressed last (the first one heard on a tie). A followed
    // window that goes quiet stays followed until another one is alive.
    if (live.length) {
      live.sort(([, a], [, b]) => (b.state?.claimedAt ?? 0) - (a.state?.claimedAt ?? 0) || a.firstSeen - b.firstSeen);
      followed = live[0][0];
    }
    const peer = followed ? decks.get(followed) : undefined;
    if (peer?.state) lastState = peer.state;
    const status: LinkStatus = peer
      ? alive(peer, t)
        ? { kind: "connected" }
        : { kind: "lost", lastSeen: peer.lastSeen }
      : { kind: "waiting", reason: closedOnce ? "closed" : "never" };
    const next: PresenterSnapshot = { status, state: lastState, decks: live.length, incompatible };
    if (JSON.stringify(next) === JSON.stringify(snap)) return;
    snap = next;
    listeners.forEach((l) => l());
  };

  const hello = () => o.transport.send({ ...envelope, type: "hello", role: "presenter" });

  const unsubscribe = o.transport.subscribe((data) => {
    const m = readMessage(data, o.deckId);
    if (m === "incompatible") {
      incompatible = true;
      return recompute();
    }
    if (!m || m.role !== "audience") return;
    if (m.type === "bye") {
      decks.delete(m.from);
      if (followed === m.from) {
        followed = null;
        closedOnce = true;
      }
      return recompute();
    }
    const t = now();
    const peer = decks.get(m.from) ?? { firstSeen: t, lastSeen: t, state: null };
    peer.lastSeen = t;
    if (m.type === "state") peer.state = m.state;
    decks.set(m.from, peer);
    // A deck window that just opened learns about this presenter straight away.
    if (m.type === "hello") hello();
    recompute();
  });
  const presence = setInterval(hello, PRESENCE_MS);
  const tick = setInterval(recompute, 500);
  hello();

  return {
    id,
    snapshot: () => snap,
    subscribe(listener: () => void) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    /** False when no deck window is connected to receive it. */
    send(cmd: PresenterCommand) {
      if (!followed || snap.status.kind !== "connected") return false;
      o.transport.send({ ...envelope, type: "cmd", role: "presenter", id: newId(), to: followed, cmd });
      return true;
    },
    /** Says hello now, e.g. when the presenter window comes back into view. */
    hello,
    close() {
      clearInterval(presence);
      clearInterval(tick);
      unsubscribe();
      o.transport.send({ ...envelope, type: "bye", role: "presenter" });
    },
  };
}
