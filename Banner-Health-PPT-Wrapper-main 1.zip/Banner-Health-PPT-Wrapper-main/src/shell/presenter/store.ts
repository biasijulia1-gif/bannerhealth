import { useSyncExternalStore } from "react";
import type { DeckConfig } from "../deck/schema";
import { createPresenterLink, type PresenterLink, type PresenterSnapshot } from "./link";
import { atDeckStart } from "./model";
import { channelName, type PresenterCommand } from "./protocol";
import { followDeck, initialTimers, timerReducer, type TimerState } from "./timers";
import { broadcastTransport, type Transport } from "./transport";

// The presenter window's state outside React: the link to the deck window, the timers (they start
// and follow slides as the deck's state arrives) and the notes text size. The link opens with the
// first subscriber and closes with the last.

export type PresenterView = {
  /** False where the browser can't link the windows. */
  supported: boolean;
  link: PresenterSnapshot;
  timers: TimerState;
  /** Index into NOTE_SIZES. */
  notesSize: number;
};

export const NOTE_SIZES = [0.8, 0.9, 1, 1.15, 1.3, 1.5];
const SIZE_KEY = "presenter:notes-size";
const timersKey = (deckId: string) => `presenter:${deckId}:timers`;

const initialLink: PresenterSnapshot = { status: { kind: "waiting", reason: "never" }, state: null, decks: 0, incompatible: false };

function read<T>(storage: () => Storage, key: string, fallback: T): T {
  try {
    const raw = storage().getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}

function write(storage: () => Storage, key: string, value: unknown) {
  try {
    storage().setItem(key, JSON.stringify(value));
  } catch {
    // Blocked storage: it still works for this window.
  }
}

export type PresenterStore = ReturnType<typeof createPresenterStore>;

export function createPresenterStore(deck: DeckConfig, opts: { transport?: () => Transport | null; now?: () => number } = {}) {
  const now = opts.now ?? (() => Date.now());
  const makeTransport = opts.transport ?? (() => broadcastTransport(channelName(deck.id)));
  const listeners = new Set<() => void>();
  let view: PresenterView = { supported: true, link: initialLink, timers: initialTimers, notesSize: 2 };
  let transport: Transport | null = null;
  let link: PresenterLink | null = null;
  let stopLink = () => {};
  /** The last deck position the timers followed. */
  let prevKey: string | null = null;

  const set = (next: Partial<PresenterView>) => {
    if (next.timers && next.timers !== view.timers) write(() => sessionStorage, timersKey(deck.id), next.timers);
    view = { ...view, ...next };
    listeners.forEach((l) => l());
  };

  const onLink = () => {
    if (!link) return;
    const snap = link.snapshot();
    let timers = view.timers;
    const st = snap.status.kind === "connected" ? snap.state : null;
    if (st) {
      const key = `${st.slideId}|${st.pos.step ?? ""}|${st.pos.build ?? ""}`;
      if (key !== prevKey) timers = followDeck(timers, prevKey, key, st.slideId, atDeckStart(deck, st), now());
      prevKey = key;
    }
    set({ link: snap, timers });
  };

  const open = () => {
    view = {
      ...view,
      timers: { ...initialTimers, ...read(() => sessionStorage, timersKey(deck.id), initialTimers) },
      notesSize: read(() => localStorage, SIZE_KEY, 2),
    };
    transport = makeTransport();
    if (!transport) {
      view = { ...view, supported: false };
      return;
    }
    link = createPresenterLink({ deckId: deck.id, transport, now });
    stopLink = link.subscribe(onLink);
    view = { ...view, link: link.snapshot() };
  };

  const close = () => {
    stopLink();
    link?.close();
    transport?.close();
    link = null;
    transport = null;
  };

  return {
    subscribe(listener: () => void) {
      listeners.add(listener);
      if (listeners.size === 1) open();
      return () => {
        listeners.delete(listener);
        if (!listeners.size) close();
      };
    },
    getSnapshot: () => view,
    /** False when no deck window is connected. */
    send: (cmd: PresenterCommand) => link?.send(cmd) ?? false,
    hello: () => link?.hello(),
    timer(type: "start" | "pause" | "reset") {
      set({ timers: timerReducer(view.timers, type === "reset" ? { type } : { type, now: now() }) });
    },
    setNotesSize(size: number) {
      const notesSize = Math.max(0, Math.min(NOTE_SIZES.length - 1, size));
      write(() => localStorage, SIZE_KEY, notesSize);
      set({ notesSize });
    },
  };
}

// A shared clock for the timer readouts, ticking only while something shows it.
const tickListeners = new Set<() => void>();
let tickNow = 0;
let tickId = 0;

function subscribeTick(listener: () => void) {
  tickListeners.add(listener);
  if (tickListeners.size === 1) {
    tickNow = Date.now();
    tickId = window.setInterval(() => {
      tickNow = Date.now();
      tickListeners.forEach((l) => l());
    }, 250);
  }
  return () => {
    tickListeners.delete(listener);
    if (!tickListeners.size) window.clearInterval(tickId);
  };
}

/** Now, refreshed four times a second. */
export const useNow = () => useSyncExternalStore(subscribeTick, () => tickNow);
