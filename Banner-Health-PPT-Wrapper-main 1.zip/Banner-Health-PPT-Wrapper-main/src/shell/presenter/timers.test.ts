import { describe, expect, it } from "vitest";
import { elapsedMs, followDeck, formatDuration, initialTimers, slideMs, timerReducer } from "./timers";

describe("presenter timers", () => {
  it("runs, pauses, resumes and resets", () => {
    let t = timerReducer(initialTimers, { type: "start", now: 1000 });
    expect(elapsedMs(t, 6000)).toBe(5000);
    t = timerReducer(t, { type: "pause", now: 6000 });
    expect(elapsedMs(t, 60_000)).toBe(5000);
    t = timerReducer(t, { type: "start", now: 10_000 });
    expect(elapsedMs(t, 12_000)).toBe(7000);
    expect(timerReducer(t, { type: "start", now: 11_000 })).toBe(t);
    t = timerReducer(t, { type: "reset" });
    expect(elapsedMs(t, 99_000)).toBe(0);
  });

  it("adds up time per slide across revisits", () => {
    let t = timerReducer(initialTimers, { type: "slide", now: 0, slideId: "a" });
    t = timerReducer(t, { type: "start", now: 0 });
    t = timerReducer(t, { type: "slide", now: 4000, slideId: "b" });
    t = timerReducer(t, { type: "slide", now: 5000, slideId: "a" });
    expect(slideMs(t, 7000)).toBe(6000);
    t = timerReducer(t, { type: "pause", now: 7000 });
    expect(slideMs(t, 50_000)).toBe(6000);
    expect(t.perSlide).toEqual({ a: 6000, b: 1000 });
  });

  it("starts on the first move, or at once when the deck is already mid-way", () => {
    let t = followDeck(initialTimers, null, "title|#0", "title", true, 0);
    expect(t.runningSince).toBeNull();
    t = followDeck(t, "title|#0", "meet-luisa|#0", "meet-luisa", false, 2000);
    expect(t.runningSince).toBe(2000);
    expect(followDeck(initialTimers, null, "triage|home", "triage", false, 500).runningSince).toBe(500);
  });

  it("formats durations", () => {
    expect(formatDuration(0)).toBe("0:00");
    expect(formatDuration(245_000)).toBe("4:05");
    expect(formatDuration(3_729_000)).toBe("1:02:09");
    expect(formatDuration(-50)).toBe("0:00");
  });
});
