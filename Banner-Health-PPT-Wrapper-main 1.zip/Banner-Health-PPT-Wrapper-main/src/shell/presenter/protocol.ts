import type { DeckState, SlidePos } from "../deck/machine";
import type { Look } from "../deck/schema";

// The deck window and the presenter window (P) talk over one channel per deck. The deck window is
// the source of truth: it sends its state, the presenter sends commands, and a heartbeat on each
// side tells the other it's still there.

export const PROTOCOL = 1;
/** The deck sends its state at least this often, even when nothing changed. */
export const HEARTBEAT_MS = 1000;
/** The presenter says hello this often, so a deck window that opens later finds it. */
export const PRESENCE_MS = 2000;
/** Silence after which the presenter shows "No signal". */
export const LOST_AFTER_MS = 3000;

export const channelName = (deckId: string) => `deck:${deckId}`;

export type Role = "audience" | "presenter";

export type AudienceState = {
  index: number;
  count: number;
  slideId: string;
  pos: SlidePos;
  black: DeckState["black"];
  /** The on-canvas note (N) is showing. */
  notes: boolean;
  look: Look;
  /** Steps that move on by themselves run (false with ?noauto). */
  auto: boolean;
  admin: { available: boolean; open: boolean };
  /** The deck window is showing (not minimized or a background tab). */
  visible: boolean;
  /** When P was last pressed in this window (Date.now()), 0 if never. The presenter follows the latest. */
  claimedAt: number;
};

export type PresenterCommand =
  | { type: "next" }
  | { type: "prev" }
  /** A slide index (0-based) and optionally a position on it. Always instant, like number + Enter. */
  | { type: "goto"; slide: number; pos?: SlidePos }
  /** Toggles, like B and W. */
  | { type: "black"; value: "black" | "white" }
  | { type: "notes" }
  | { type: "tone" }
  | { type: "zoom" };

type Envelope = { v: typeof PROTOCOL; deck: string; from: string };

export type DeckMessage =
  | (Envelope & { type: "hello"; role: Role })
  | (Envelope & { type: "state"; role: "audience"; state: AudienceState })
  | (Envelope & { type: "cmd"; role: "presenter"; id: string; to: string; cmd: PresenterCommand })
  | (Envelope & { type: "bye"; role: Role });

const TYPES = new Set(["hello", "state", "cmd", "bye"]);

/** A message for this deck, "incompatible" for this deck on another protocol version, else null. */
export function readMessage(data: unknown, deckId: string): DeckMessage | "incompatible" | null {
  if (!data || typeof data !== "object") return null;
  const m = data as Record<string, unknown>;
  if (m.deck !== deckId || typeof m.from !== "string" || typeof m.type !== "string" || !TYPES.has(m.type)) return null;
  if (m.v !== PROTOCOL) return "incompatible";
  if (m.type === "state" && (typeof m.state !== "object" || !m.state)) return null;
  if (m.type === "cmd" && (typeof m.cmd !== "object" || !m.cmd || typeof m.id !== "string")) return null;
  return data as DeckMessage;
}

/** Window and command ids. Not crypto.randomUUID, which plain-http LAN addresses don't have. */
export const newId = () => `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 8)}`;
