"use client";

import { useEffect, useRef } from "react";
import type { PresenterCommand } from "./protocol";

// Keys in the presenter window. The deck's keys are sent to the deck window, so the clicker works
// with focus in either window; text size, the jump buffer and full screen stay local. A (the admin
// panel) and P are swallowed: they never reach the deck from here.

export type PresenterIntent =
  | { type: "cmd"; cmd: PresenterCommand }
  | { type: "digit"; d: string }
  | { type: "enter" }
  | { type: "size"; delta: 1 | -1 }
  | { type: "fullscreen" }
  | { type: "escape" }
  | { type: "swallow" };

type KeyLike = Pick<KeyboardEvent, "key" | "repeat" | "ctrlKey" | "metaKey" | "altKey">;

const SWALLOW: PresenterIntent = { type: "swallow" };
const cmd = (e: KeyLike, c: PresenterCommand): PresenterIntent => (e.repeat ? SWALLOW : { type: "cmd", cmd: c });

/** What a key does in the presenter window, or null to leave it to the browser. */
export function presenterKeyIntent(e: KeyLike): PresenterIntent | null {
  if (e.ctrlKey || e.metaKey || e.altKey) return null;
  switch (e.key) {
    case "ArrowRight":
    case "PageDown":
    case " ":
      return cmd(e, { type: "next" });
    case "ArrowLeft":
    case "PageUp":
      return cmd(e, { type: "prev" });
    case "Enter":
      return e.repeat ? SWALLOW : { type: "enter" };
    case "b":
    case "B":
    case ".":
      return cmd(e, { type: "black", value: "black" });
    case "w":
    case "W":
    case ",":
      return cmd(e, { type: "black", value: "white" });
    case "n":
    case "N":
      return cmd(e, { type: "notes" });
    case "t":
    case "T":
      return cmd(e, { type: "tone" });
    case "z":
    case "Z":
      return cmd(e, { type: "zoom" });
    case "-":
    case "_":
      return { type: "size", delta: -1 };
    case "=":
    case "+":
      return { type: "size", delta: 1 };
    case "f":
    case "F":
      return { type: "fullscreen" };
    case "Escape":
      return { type: "escape" };
    case "F5":
    case "p":
    case "P":
    case "a":
    case "A":
      return SWALLOW;
    default:
      return /^[0-9]$/.test(e.key) ? { type: "digit", d: e.key } : null;
  }
}

/** One capture-phase handler for the presenter window. */
export function usePresenterKeys(onIntent: (intent: PresenterIntent) => void) {
  const ref = useRef(onIntent);
  useEffect(() => {
    ref.current = onIntent;
  });

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const intent = presenterKeyIntent(e);
      if (!intent) return;
      e.preventDefault();
      e.stopImmediatePropagation();
      ref.current(intent);
    };
    // Space and Enter also fire click on the focused button at keyup, so swallow those too.
    const onKeyUp = (e: KeyboardEvent) => {
      if (e.key === " " || e.key === "Enter") {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    };
    window.addEventListener("keydown", onKey, { capture: true });
    window.addEventListener("keyup", onKeyUp, { capture: true });
    return () => {
      window.removeEventListener("keydown", onKey, { capture: true });
      window.removeEventListener("keyup", onKeyUp, { capture: true });
    };
  }, []);
}
