import { describe, expect, it } from "vitest";
import { defineDeck } from "../deck/schema";
import { atDeckStart, derivePresenter, waitingPosition, type DeckPosition, type PresenterManifest } from "./model";

const Slide = () => null;
const demo: PresenterManifest = {
  steps: ["s0", "s1", "s2", "s3", "s4"],
  labels: { s0: "Zero", s1: "One", s2: "Two", s3: "Three", s4: "Four" },
  auto: { s3: { to: "s4", afterMs: 1000 } },
};
const deck = defineDeck({
  id: "t",
  title: "T",
  label: "T",
  slides: [
    { id: "intro", type: "brand", title: "Intro", Component: Slide, notes: "Hello." },
    { id: "builds", type: "brand", title: "Builds", Component: Slide, builds: 2, tone: "invert", annotation: "On canvas.", durationHint: 2 },
    { id: "proto", type: "prototype", title: "Proto", prototype: "demo", from: "s1", to: "s4", notes: "Slide note.", stepNotes: { s2: "Step note." } },
    { id: "end", type: "brand", title: "End", Component: Slide, durationHint: 1 },
  ],
});
const m = { demo };
const at = (index: number, pos: DeckPosition["pos"], extra: Partial<DeckPosition> = {}): DeckPosition => ({
  index,
  count: deck.slides.length,
  slideId: deck.slides[index].id,
  pos,
  black: false,
  notes: false,
  look: { tone: "dark", site: "framed" },
  auto: true,
  ...extra,
});

describe("derivePresenter", () => {
  it("describes builds and steps", () => {
    expect(derivePresenter(deck, m, at(1, { build: 1 })).current).toMatchObject({ detail: "Build 1 of 2", build: { at: 1, of: 2 }, tone: "light" });
    expect(derivePresenter(deck, m, at(0, { build: 0 })).current.detail).toBe("");
    expect(derivePresenter(deck, m, at(2, { step: "s2" })).current).toMatchObject({ detail: "Step 2/4 · Two", step: { n: 2, of: 4 }, site: "framed" });
    expect(derivePresenter(deck, m, at(2, { step: "s0" })).current.detail).toBe("Zero (clicked by hand)");
  });

  it("says what → does next", () => {
    expect(derivePresenter(deck, m, at(0, { build: 0 })).next).toMatchObject({ kind: "slide", action: "Next slide: Builds", card: { slideId: "builds", pos: { build: 0 } } });
    expect(derivePresenter(deck, m, at(1, { build: 0 })).next).toMatchObject({ kind: "build", action: "Build 1 of 2" });
    expect(derivePresenter(deck, m, at(1, { build: 2 })).next).toMatchObject({ kind: "slide", card: { slideId: "proto", pos: { step: "s1" } } });
    expect(derivePresenter(deck, m, at(2, { step: "s1" })).next).toMatchObject({ kind: "step", action: "Two", then: undefined });
    expect(derivePresenter(deck, m, at(2, { step: "s2" })).next).toMatchObject({ kind: "step", action: "Three", then: "then moves on by itself to Four" });
    expect(derivePresenter(deck, m, at(2, { step: "s4" })).next).toMatchObject({ kind: "slide", card: { slideId: "end" } });
    expect(derivePresenter(deck, m, at(3, { build: 0 })).next).toEqual({ kind: "end", action: "End of deck" });
    expect(derivePresenter(deck, m, at(1, { build: 1 }, { black: "white" })).next).toMatchObject({ kind: "unblack", action: "Clears the white screen" });
  });

  it("leaves out auto notes when steps don't move on by themselves", () => {
    expect(derivePresenter(deck, m, at(2, { step: "s2" }, { auto: false })).next).toMatchObject({ then: undefined });
    expect(derivePresenter(deck, m, at(2, { step: "s3" })).current.autoNote).toBe("Moves on by itself to Four");
    expect(derivePresenter(deck, m, at(2, { step: "s3" }, { auto: false })).current.autoNote).toBeUndefined();
  });

  it("lists steps, joins notes and reports the annotation", () => {
    const p = derivePresenter(deck, m, at(2, { step: "s2" }));
    expect(p.steps?.map((r) => `${r.step}:${r.state}${r.auto ? ":auto" : ""}${r.note ? ":note" : ""}`)).toEqual(["s1:done", "s2:current:note", "s3:todo:auto", "s4:todo"]);
    expect(p.notes).toEqual({ slide: "Slide note.", step: "Step note." });
    expect(derivePresenter(deck, m, at(1, { build: 0 }, { notes: true })).annotation).toEqual({ text: "On canvas.", shown: true });
    expect(p.slides.map((x) => x.state)).toEqual(["done", "done", "current", "todo"]);
  });

  it("times slides against their hints and flags a different slide list", () => {
    const p = derivePresenter(deck, m, at(1, { build: 0 }));
    expect(p).toMatchObject({ durationHintMs: 120_000, plannedMs: 180_000, inSync: true });
    expect(derivePresenter(deck, m, at(1, { build: 0 }, { count: 9 })).inSync).toBe(false);
  });

  it("starts from the deck's first slide while waiting, and knows the deck's start", () => {
    const w = waitingPosition(deck);
    expect(derivePresenter(deck, m, w).current.slideId).toBe("intro");
    expect(atDeckStart(deck, w)).toBe(true);
    expect(atDeckStart(deck, at(1, { build: 0 }))).toBe(false);
  });
});
