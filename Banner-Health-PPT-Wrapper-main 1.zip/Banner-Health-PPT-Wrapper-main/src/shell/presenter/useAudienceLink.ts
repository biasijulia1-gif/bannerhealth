"use client";

import { useEffect, useMemo, useRef } from "react";
import { flushSync } from "react-dom";
import type { DeckApi } from "../deck/DeckProvider";
import type { DeckKeyActions } from "../deck/keys";
import { createAudienceLink } from "./link";
import { channelName, type PresenterCommand } from "./protocol";
import { broadcastTransport } from "./transport";

// The deck window's end of the presenter link. It publishes the deck's state and runs the
// presenter's commands through the very actions the keys use, so a press in the presenter window
// behaves exactly like a key press here: a second → finishes a running move, → only clears a black
// screen, ← is instant, T and Z keep their rules.

function run(cmd: PresenterCommand, a: DeckKeyActions, api: DeckApi) {
  switch (cmd.type) {
    case "next":
      return a.next();
    case "prev":
      return a.prev();
    case "black":
      return a.black(cmd.value);
    case "notes":
      return a.notes();
    case "tone":
      return a.tone();
    case "zoom":
      return a.zoom();
    case "goto":
      return api.goTo(cmd.slide, cmd.pos, { instant: true });
  }
}

export function useAudienceLink({
  deckId,
  api,
  actions,
  enabled,
  auto,
  adminAvailable,
}: {
  deckId: string;
  api: DeckApi;
  actions: React.RefObject<DeckKeyActions | null>;
  enabled: boolean;
  auto: boolean;
  adminAvailable: boolean;
}) {
  const link = useRef<ReturnType<typeof createAudienceLink> | null>(null);

  useEffect(() => {
    if (!enabled) return;
    const transport = broadcastTransport(channelName(deckId));
    if (!transport) return;
    const l = createAudienceLink({
      deckId,
      transport,
      read() {
        const s = api.snapshot();
        return {
          index: s.index,
          count: s.count,
          slideId: s.slideId,
          pos: s.pos,
          black: s.black,
          notes: s.notes,
          look: s.look,
          auto,
          admin: { available: adminAvailable, open: s.admin },
          visible: document.visibilityState === "visible",
        };
      },
      // Keys are discrete events, so React commits each press before the next one; a channel
      // message isn't, so flush it the same way (the incoming slide registers its controller).
      run: (cmd) => {
        const a = actions.current;
        if (a) flushSync(() => run(cmd, a, api));
      },
    });
    link.current = l;
    const stop = api.subscribe(() => l.changed());
    const onVisibility = () => l.changed();
    const onHide = () => l.close();
    document.addEventListener("visibilitychange", onVisibility);
    window.addEventListener("pagehide", onHide);
    return () => {
      stop();
      document.removeEventListener("visibilitychange", onVisibility);
      window.removeEventListener("pagehide", onHide);
      l.close();
      transport.close();
      link.current = null;
    };
  }, [deckId, api, actions, enabled, auto, adminAvailable]);

  return useMemo(
    () => ({
      /** P was pressed in this window: the presenter follows it. */
      claim: () => link.current?.claim(),
    }),
    [],
  );
}
