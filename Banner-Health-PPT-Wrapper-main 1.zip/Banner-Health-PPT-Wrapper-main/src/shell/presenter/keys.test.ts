import { describe, expect, it } from "vitest";
import { presenterKeyIntent } from "./keys";

const key = (k: string, extra: Partial<KeyboardEvent> = {}) =>
  presenterKeyIntent({ key: k, repeat: false, ctrlKey: false, metaKey: false, altKey: false, ...extra });

describe("presenter keys", () => {
  it("sends the deck's keys to the deck window", () => {
    expect(key("PageDown")).toEqual({ type: "cmd", cmd: { type: "next" } });
    expect(key(" ")).toEqual({ type: "cmd", cmd: { type: "next" } });
    expect(key("PageUp")).toEqual({ type: "cmd", cmd: { type: "prev" } });
    expect(key(".")).toEqual({ type: "cmd", cmd: { type: "black", value: "black" } });
    expect(key("W")).toEqual({ type: "cmd", cmd: { type: "black", value: "white" } });
    expect(key("n")).toEqual({ type: "cmd", cmd: { type: "notes" } });
    expect(key("t")).toEqual({ type: "cmd", cmd: { type: "tone" } });
    expect(key("z")).toEqual({ type: "cmd", cmd: { type: "zoom" } });
  });

  it("keeps jumps, text size and full screen local", () => {
    expect(key("4")).toEqual({ type: "digit", d: "4" });
    expect(key("Enter")).toEqual({ type: "enter" });
    expect(key("=")).toEqual({ type: "size", delta: 1 });
    expect(key("-")).toEqual({ type: "size", delta: -1 });
    expect(key("f")).toEqual({ type: "fullscreen" });
    expect(key("Escape")).toEqual({ type: "escape" });
  });

  it("swallows repeats, P, A and F5, and leaves shortcuts to the browser", () => {
    expect(key("ArrowRight", { repeat: true })).toEqual({ type: "swallow" });
    for (const k of ["p", "A", "F5"]) expect(key(k)).toEqual({ type: "swallow" });
    expect(key("ArrowRight", { ctrlKey: true })).toBeNull();
    expect(key("r", { metaKey: true })).toBeNull();
    expect(key("q")).toBeNull();
  });
});
