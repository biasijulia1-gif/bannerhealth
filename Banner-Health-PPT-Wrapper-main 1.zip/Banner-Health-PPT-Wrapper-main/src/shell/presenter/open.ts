// P in the deck window: opens the presenter window, or brings the open one forward without
// reloading it (window.open with a URL would navigate a window that already has the name).

export function openPresenterWindow(deckId: string, path = "/deck/presenter") {
  const w = window.open("", `deck-presenter-${deckId}`, "popup,width=1280,height=800");
  if (!w) {
    console.warn("[deck] the presenter window was blocked: allow pop-ups for this site");
    return;
  }
  let there = false;
  try {
    there = w.location.pathname === path;
  } catch {
    // Another origin: navigate it.
  }
  // A new popup starts on about:blank. The presenter reads nothing from the URL: it follows the deck.
  if (!there) w.location.replace(path);
  w.focus();
}
