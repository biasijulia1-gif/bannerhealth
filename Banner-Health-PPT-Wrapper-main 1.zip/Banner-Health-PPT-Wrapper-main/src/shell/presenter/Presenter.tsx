"use client";

import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import type { DeckConfig } from "../deck/schema";
import type { LinkStatus } from "./link";
import { usePresenterKeys, type PresenterIntent } from "./keys";
import { derivePresenter, waitingPosition, type NextCard, type PresenterManifest, type PresenterModel, type SlideCard, type StepRow } from "./model";
import type { PresenterCommand } from "./protocol";
import { createPresenterStore, NOTE_SIZES, useNow } from "./store";
import { s } from "./strings";
import { elapsedMs, formatDuration, slideMs } from "./timers";

// The presenter's private window (P): what the audience sees, what → does next, the notes and the
// clocks, in sync with the deck window. Everything is sized from one unit, so the same layout
// works in the 1280×800 popup and full screen.

const u = (n: number) => `calc(var(--u) * ${n})`;
const clockFormat = new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" });

const cardData = (c: SlideCard) => ({ "data-index": c.index, "data-slide-id": c.slideId, "data-step": c.pos.step, "data-build": c.pos.build });

export function Presenter({ deck, manifests }: { deck: DeckConfig; manifests: Record<string, PresenterManifest> }) {
  const store = useMemo(() => createPresenterStore(deck), [deck]);
  const view = useSyncExternalStore(store.subscribe, store.getSnapshot);
  const now = useNow();
  const { status, state } = view.link;
  const connected = status.kind === "connected";
  const position = state ?? waitingPosition(deck);
  const model = derivePresenter(deck, manifests, position);
  const [jump, setJump] = useState("");
  const jumpTimer = useRef(0);
  const [confirmReset, setConfirmReset] = useState(false);
  const resetTimer = useRef(0);

  // A deck window opened from here can bring this window forward with P.
  useEffect(() => {
    if (!window.name) window.name = `deck-presenter-${deck.id}`;
  }, [deck.id]);

  // Coming back into view: say hello so the deck answers with its state at once.
  useEffect(() => {
    const onVisibility = () => document.visibilityState === "visible" && store.hello();
    document.addEventListener("visibilitychange", onVisibility);
    return () => document.removeEventListener("visibilitychange", onVisibility);
  }, [store]);

  const send = (cmd: PresenterCommand) => store.send(cmd);
  const clearJump = () => {
    window.clearTimeout(jumpTimer.current);
    setJump("");
  };

  usePresenterKeys((intent: PresenterIntent) => {
    switch (intent.type) {
      case "cmd":
        send(intent.cmd);
        return;
      case "digit":
        setJump((j) => (j + intent.d).slice(-3));
        window.clearTimeout(jumpTimer.current);
        jumpTimer.current = window.setTimeout(() => setJump(""), 1500);
        return;
      case "enter": {
        const n = Number(jump);
        clearJump();
        if (!jump) send({ type: "next" });
        else if (n >= 1 && n <= deck.slides.length) send({ type: "goto", slide: n - 1 });
        return;
      }
      case "size":
        store.setNotesSize(view.notesSize + intent.delta);
        return;
      case "fullscreen":
        if (document.fullscreenElement) void document.exitFullscreen();
        else void document.documentElement.requestFullscreen().catch(() => {});
        return;
      case "escape":
        clearJump();
        return;
    }
  });

  const reset = () => {
    window.clearTimeout(resetTimer.current);
    if (confirmReset) {
      setConfirmReset(false);
      store.timer("reset");
      return;
    }
    setConfirmReset(true);
    resetTimer.current = window.setTimeout(() => setConfirmReset(false), 3000);
  };

  const elapsed = elapsedMs(view.timers, now);
  const running = view.timers.runningSince !== null;
  const started = running || view.timers.banked > 0;
  const overall = model.plannedMs !== null && elapsed > model.plannedMs;

  const warnings: Array<{ text: string; serious?: boolean }> = [];
  if (!view.supported) warnings.push({ text: s.warn.unsupported, serious: true });
  if (view.link.incompatible) warnings.push({ text: s.warn.version, serious: true });
  if (state && connected) {
    if (!model.inSync) warnings.push({ text: s.warn.sync, serious: true });
    if (state.admin.open) warnings.push({ text: s.warn.admin, serious: true });
    if (!state.visible) warnings.push({ text: s.warn.hidden });
    if (view.link.decks > 1) warnings.push({ text: s.warn.decks(view.link.decks) });
  }

  return (
    <div
      data-presenter=""
      data-presenter-status={status.kind}
      className="fixed inset-0 flex flex-col bg-val-black font-val-sans text-val-paper"
      style={{ "--u": "min(1vw, 1.6vh)", colorScheme: "dark" } as React.CSSProperties}
    >
      <header className="flex shrink-0 items-center border-b border-val-line" style={{ height: u(4.2), padding: `0 ${u(1.6)}`, gap: u(1.2) }}>
        <Label>
          {s.title} · {deck.title}
        </Label>
        <Status status={status} now={now} />
        {status.kind === "waiting" && (
          <SmallButton onClick={() => window.open("/deck", `deck-audience-${deck.id}`)}>{s.openDeck}</SmallButton>
        )}
        <div className="flex min-w-0 flex-1 items-center overflow-hidden" style={{ gap: u(0.6) }}>
          {warnings.map((w) => (
            <span
              key={w.text}
              className={`shrink-0 ${w.serious ? "bg-val-red text-val-black" : "border border-val-line text-val-stone"}`}
              style={{ padding: `${u(0.2)} ${u(0.6)}`, fontSize: u(0.9) }}
            >
              {w.text}
            </span>
          ))}
        </div>
        <div className="flex items-center" style={{ gap: u(0.8) }}>
          <Label>{s.elapsed}</Label>
          <span
            data-presenter-elapsed=""
            className={`font-val-display font-light tabular-nums ${overall ? "bg-val-red text-val-black" : ""}`}
            style={{ fontSize: u(2.2), padding: `0 ${u(0.3)}` }}
          >
            {formatDuration(elapsed)}
            {model.plannedMs !== null && <span className="opacity-60"> / {formatDuration(model.plannedMs)}</span>}
          </span>
          <SmallButton onClick={() => store.timer(running ? "pause" : "start")}>{running ? s.pause : started ? s.resume : s.start}</SmallButton>
          <SmallButton onClick={reset}>{confirmReset ? s.resetConfirm : s.reset}</SmallButton>
        </div>
        <span className="tabular-nums text-val-stone" style={{ fontSize: u(1.4) }}>
          {now ? clockFormat.format(now) : ""}
        </span>
      </header>

      <main className="grid min-h-0 flex-1" style={{ gridTemplateColumns: "57fr 43fr" }}>
        <section className="flex min-h-0 flex-col border-r border-val-line" style={{ padding: u(1.6), gap: u(1) }}>
          <Label>
            {s.now} · {model.current.number} / {model.current.count}
          </Label>
          <div data-presenter-current="" {...cardData(model.current)}>
            <Card card={model.current} large black={position.black} />
          </div>
          <div className="flex items-baseline justify-between" style={{ gap: u(1) }}>
            <p className="min-w-0 text-val-faint" style={{ fontSize: u(1.15) }}>
              {model.current.autoNote}
            </p>
            <SlideTimer ms={slideMs(view.timers, now)} hint={model.durationHintMs} />
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto border-t border-val-line" style={{ paddingTop: u(1) }}>
            {model.steps ? (
              <Steps rows={model.steps} disabled={!connected} onPick={(step) => send({ type: "goto", slide: model.current.index, pos: { step } })} />
            ) : model.builds ? (
              <Builds builds={model.builds} />
            ) : null}
          </div>
        </section>

        <section className="flex min-h-0 flex-col" style={{ padding: u(1.6), gap: u(1) }}>
          <Label>{s.next}</Label>
          <Next next={model.next} />
          <Notes model={model} scale={NOTE_SIZES[view.notesSize] ?? 1} onSize={(d) => store.setNotesSize(view.notesSize + d)} />
        </section>
      </main>

      <footer className="flex shrink-0 items-center border-t border-val-line" style={{ height: u(4.8), padding: `0 ${u(1.6)}`, gap: u(0.6) }}>
        <Control id="prev" hint="←" disabled={!connected} onClick={() => send({ type: "prev" })}>
          ◀ {s.controls.prev}
        </Control>
        <Control id="next" hint="→" primary disabled={!connected} onClick={() => send({ type: "next" })}>
          {s.controls.next} ▶
        </Control>
        <Control id="black" hint="B" active={position.black === "black"} disabled={!connected} onClick={() => send({ type: "black", value: "black" })}>
          {s.controls.black}
        </Control>
        <Control id="white" hint="W" active={position.black === "white"} disabled={!connected} onClick={() => send({ type: "black", value: "white" })}>
          {s.controls.white}
        </Control>
        <Control id="notes" hint="N" active={position.notes} disabled={!connected} onClick={() => send({ type: "notes" })}>
          {s.controls.notes}
        </Control>
        <span style={{ width: u(0.8) }} />
        {model.slides.map((x) => (
          <button
            key={x.index}
            type="button"
            title={x.title}
            disabled={!connected}
            onClick={(e) => {
              e.currentTarget.blur();
              send({ type: "goto", slide: x.index });
            }}
            className={`tabular-nums disabled:opacity-40 ${
              x.state === "current" ? "bg-val-paper text-val-black" : `border border-val-line enabled:hover:bg-val-ink ${x.state === "done" ? "text-val-faint" : "text-val-stone"}`
            }`}
            style={{ width: u(2.4), height: u(2.4), fontSize: u(1) }}
          >
            {x.index + 1}
          </button>
        ))}
        {jump && (
          <span className="bg-val-ink tabular-nums" style={{ padding: `${u(0.4)} ${u(0.8)}`, fontSize: u(1.1) }}>
            {s.goTo(jump, model.current.count)}
          </span>
        )}
        <span className="min-w-0 flex-1 truncate text-right text-val-faint" style={{ fontSize: u(0.85) }}>
          {s.legend}
        </span>
      </footer>
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <p className="shrink-0 uppercase text-val-faint" style={{ fontSize: u(0.8), letterSpacing: "0.14em" }}>
      {children}
    </p>
  );
}

function SmallButton({ onClick, children }: { onClick(): void; children: React.ReactNode }) {
  return (
    <button
      type="button"
      onClick={(e) => {
        e.currentTarget.blur();
        onClick();
      }}
      className="shrink-0 border border-val-line text-val-stone hover:bg-val-ink"
      style={{ padding: `${u(0.25)} ${u(0.7)}`, fontSize: u(0.9) }}
    >
      {children}
    </button>
  );
}

function Status({ status, now }: { status: LinkStatus; now: number }) {
  const dot = { width: u(0.7), height: u(0.7) };
  if (status.kind === "connected") {
    return (
      <span className="flex shrink-0 items-center" style={{ gap: u(0.5), fontSize: u(1) }}>
        <span className="bg-val-lime" style={dot} />
        {s.status.connected}
      </span>
    );
  }
  if (status.kind === "lost") {
    return (
      <span className="shrink-0 bg-val-red text-val-black" style={{ padding: `${u(0.2)} ${u(0.6)}`, fontSize: u(1) }}>
        {s.status.lost(Math.max(0, Math.floor((now - status.lastSeen) / 1000)))}
      </span>
    );
  }
  return (
    <span className="flex shrink-0 items-center text-val-stone" style={{ gap: u(0.5), fontSize: u(1) }}>
      <span className="border border-val-faint" style={dot} />
      {status.reason === "closed" ? s.status.closed : s.status.never}
    </span>
  );
}

function Card({ card, large, black }: { card: SlideCard; large?: boolean; black?: false | "black" | "white" }) {
  return (
    <div
      data-tone={card.tone}
      className="relative aspect-video w-full overflow-hidden border border-val-line"
      style={large ? { maxWidth: "calc(42vh * 16 / 9)" } : undefined}
    >
      <div className="absolute inset-0 flex flex-col justify-between" style={{ padding: large ? u(2) : u(1.1) }}>
        <span className="uppercase text-tone-faint" style={{ fontSize: large ? u(0.85) : u(0.7), letterSpacing: "0.14em" }}>
          {card.type === "brand" ? s.brand : `${s.prototype} · ${s.sites[card.site ?? "framed"]}`}
        </span>
        <div>
          <p className="font-val-display font-light text-tone-fg" style={{ fontSize: large ? u(3.4) : u(1.8), lineHeight: 1.05, letterSpacing: "-0.015em" }}>
            {card.title}
          </p>
          {card.detail && (
            <p className="text-tone-dim" style={{ fontSize: large ? u(1.3) : u(0.95), marginTop: u(0.6) }}>
              {card.detail}
            </p>
          )}
        </div>
      </div>
      {black && (
        <div
          data-presenter-black={black}
          className={`absolute inset-0 flex items-center justify-center text-center ${black === "white" ? "bg-val-paper text-val-black" : "bg-val-black text-val-paper"}`}
          style={{ padding: u(3), fontSize: u(1.4) }}
        >
          {s.blackShown(black)}
        </div>
      )}
    </div>
  );
}

function SlideTimer({ ms, hint }: { ms: number; hint: number | null }) {
  const over = hint !== null && ms > hint;
  return (
    <div className="flex shrink-0 items-center" style={{ gap: u(0.6) }}>
      <Label>{s.thisSlide}</Label>
      <span className={`tabular-nums ${over ? "bg-val-red text-val-black" : "text-val-stone"}`} style={{ fontSize: u(1.3), padding: `0 ${u(0.3)}` }}>
        {formatDuration(ms)}
        {hint !== null && ` / ${formatDuration(hint)}`}
      </span>
      {hint !== null && (
        <span className="relative bg-val-line" style={{ width: u(6), height: u(0.3) }}>
          <span className={`absolute inset-y-0 left-0 ${over ? "bg-val-red" : "bg-val-lime"}`} style={{ width: `${Math.min(100, (ms / hint) * 100)}%` }} />
        </span>
      )}
    </div>
  );
}

function Steps({ rows, disabled, onPick }: { rows: StepRow[]; disabled: boolean; onPick(step: string): void }) {
  return (
    <>
      <Label>{s.steps}</Label>
      {/* Two columns that read down, so the steps keep their order. */}
      <ol
        className="grid"
        style={{ gridTemplateColumns: "1fr 1fr", gridTemplateRows: `repeat(${Math.ceil(rows.length / 2)}, auto)`, gridAutoFlow: "column", columnGap: u(1.2), marginTop: u(0.6) }}
      >
        {rows.map((r) => (
          <li key={r.step}>
            <button
              type="button"
              disabled={disabled}
              data-presenter-step={r.step}
              onClick={(e) => {
                e.currentTarget.blur();
                onPick(r.step);
              }}
              className={`flex w-full items-center text-left ${
                r.state === "current" ? "bg-val-lime text-val-black" : `enabled:hover:bg-val-ink ${r.state === "done" ? "text-val-faint" : "text-val-stone"}`
              }`}
              style={{ gap: u(0.6), padding: `${u(0.35)} ${u(0.6)}`, fontSize: u(1.05) }}
            >
              <span className="shrink-0 tabular-nums" style={{ width: u(1.6) }}>
                {r.n}
              </span>
              <span className="min-w-0 flex-1 truncate">{r.label}</span>
              {r.auto && <span title={s.autoNote("the next step")}>↻</span>}
              {r.note && <span title={s.atThisStep}>✎</span>}
            </button>
          </li>
        ))}
      </ol>
    </>
  );
}

function Builds({ builds }: { builds: { at: number; of: number } }) {
  return (
    <>
      <Label>{s.builds}</Label>
      <div className="flex items-center" style={{ gap: u(0.6), marginTop: u(0.6) }}>
        {Array.from({ length: builds.of }, (_, k) => (
          <span key={k} className={k < builds.at ? "bg-val-lime" : "border border-val-faint"} style={{ width: u(1), height: u(1) }} />
        ))}
        <span className="text-val-stone" style={{ fontSize: u(1.05), marginLeft: u(0.6) }}>
          {builds.at ? s.build(builds.at, builds.of) : s.buildsToCome(builds.of)}
        </span>
      </div>
    </>
  );
}

function Next({ next }: { next: NextCard }) {
  const c = next.kind === "end" ? null : next.card;
  return (
    <div data-presenter-next="" data-kind={next.kind} {...(c ? cardData(c) : {})} className="flex shrink-0" style={{ gap: u(1.2) }}>
      {c && (
        <div className="shrink-0" style={{ width: "52%" }}>
          <Card card={c} />
        </div>
      )}
      <div className="min-w-0">
        <p style={{ fontSize: u(1.5), lineHeight: 1.25 }}>→ {next.action}</p>
        {"then" in next && next.then && (
          <p className="text-val-faint" style={{ fontSize: u(1.1), marginTop: u(0.4) }}>
            {next.then}
          </p>
        )}
      </div>
    </div>
  );
}

function Notes({ model, scale, onSize }: { model: PresenterModel; scale: number; onSize(delta: 1 | -1): void }) {
  const { slide, step } = model.notes;
  return (
    <div className="flex min-h-0 flex-1 flex-col border-t border-val-line" style={{ paddingTop: u(1) }}>
      <div className="flex items-center justify-between">
        <Label>{s.notes}</Label>
        <div className="flex" style={{ gap: u(0.4) }}>
          <SmallButton onClick={() => onSize(-1)}>A−</SmallButton>
          <SmallButton onClick={() => onSize(1)}>A+</SmallButton>
        </div>
      </div>
      <div data-presenter-notes="" className="min-h-0 flex-1 overflow-y-auto" style={{ fontSize: u(1.8 * scale), lineHeight: 1.4, marginTop: u(0.8) }}>
        {slide ? <p>{slide}</p> : !step && <p className="text-val-faint">{s.noNotes}</p>}
        {step && (
          <div className="border-l-[3px] border-val-lime" style={{ marginTop: u(1.2), paddingLeft: u(1) }}>
            <p className="uppercase text-val-faint" style={{ fontSize: u(0.8), letterSpacing: "0.14em" }}>
              {s.atThisStep}
            </p>
            <p>{step}</p>
          </div>
        )}
        {model.annotation && (
          <p className="text-val-faint" style={{ marginTop: u(1.2), fontSize: "0.7em" }}>
            {s.onScreen}, {model.annotation.shown ? s.showing : s.hidden}: {model.annotation.text}
          </p>
        )}
      </div>
    </div>
  );
}

function Control({
  id,
  hint,
  primary,
  active,
  disabled,
  onClick,
  children,
}: {
  id: string;
  hint: string;
  primary?: boolean;
  active?: boolean;
  disabled: boolean;
  onClick(): void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      data-presenter-control={id}
      disabled={disabled}
      onClick={(e) => {
        e.currentTarget.blur();
        onClick();
      }}
      className={`flex shrink-0 items-center border disabled:opacity-40 ${
        primary ? "border-val-lime bg-val-lime text-val-black" : active ? "border-val-paper bg-val-paper text-val-black" : "border-val-line text-val-paper enabled:hover:bg-val-ink"
      }`}
      style={{ gap: u(0.6), padding: `${u(0.55)} ${u(1)}`, fontSize: u(1.1) }}
    >
      {children}
      <kbd className="font-val-sans opacity-60" style={{ fontSize: u(0.85) }}>
        {hint}
      </kbd>
    </button>
  );
}
