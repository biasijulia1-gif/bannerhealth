// The presenter's clocks: time since the talk started, and time spent on each slide (revisits add
// up), as plain data so they survive a reload of the presenter window. Wall-clock based, so
// nothing needs to tick to keep them right.

export type TimerState = {
  /** When the elapsed clock last (re)started, null while it isn't running. */
  runningSince: number | null;
  /** Elapsed time banked before the last start. */
  banked: number;
  /** The slide on screen, and since when it has been counting (null while paused). */
  slideId: string | null;
  slideSince: number | null;
  perSlide: Record<string, number>;
};

export type TimerAction =
  | { type: "start"; now: number }
  | { type: "pause"; now: number }
  | { type: "reset" }
  | { type: "slide"; now: number; slideId: string };

export const initialTimers: TimerState = { runningSince: null, banked: 0, slideId: null, slideSince: null, perSlide: {} };

const bankSlide = (t: TimerState, now: number) =>
  t.slideId && t.slideSince !== null ? { ...t.perSlide, [t.slideId]: (t.perSlide[t.slideId] ?? 0) + now - t.slideSince } : t.perSlide;

export function timerReducer(t: TimerState, a: TimerAction): TimerState {
  switch (a.type) {
    case "start":
      return t.runningSince !== null ? t : { ...t, runningSince: a.now, slideSince: t.slideId ? a.now : null };
    case "pause":
      if (t.runningSince === null) return t;
      return { ...t, banked: elapsedMs(t, a.now), perSlide: bankSlide(t, a.now), runningSince: null, slideSince: null };
    case "reset":
      return { ...initialTimers, slideId: t.slideId };
    case "slide":
      if (a.slideId === t.slideId) return t;
      return { ...t, perSlide: bankSlide(t, a.now), slideId: a.slideId, slideSince: t.runningSince !== null ? a.now : null };
  }
}

export const elapsedMs = (t: TimerState, now: number) => t.banked + (t.runningSince !== null ? now - t.runningSince : 0);

export const slideMs = (t: TimerState, now: number) =>
  t.slideId ? (t.perSlide[t.slideId] ?? 0) + (t.slideSince !== null ? now - t.slideSince : 0) : 0;

/**
 * Follows the deck window. The clock starts on the first move, or straight away when the presenter
 * connects to a deck that's already past its first position (P pressed mid-talk).
 * `prevKey` is null for the first position seen.
 */
export function followDeck(t: TimerState, prevKey: string | null, key: string, slideId: string, atStart: boolean, now: number): TimerState {
  const moved = prevKey === null ? !atStart : key !== prevKey;
  const started = moved ? timerReducer(t, { type: "start", now }) : t;
  return timerReducer(started, { type: "slide", now, slideId });
}

/** "4:05", or "1:02:09" past an hour. */
export function formatDuration(ms: number): string {
  const total = Math.max(0, Math.floor(ms / 1000));
  const h = Math.floor(total / 3600);
  const m = Math.floor((total % 3600) / 60);
  const sec = String(total % 60).padStart(2, "0");
  return h ? `${h}:${String(m).padStart(2, "0")}:${sec}` : `${m}:${sec}`;
}
