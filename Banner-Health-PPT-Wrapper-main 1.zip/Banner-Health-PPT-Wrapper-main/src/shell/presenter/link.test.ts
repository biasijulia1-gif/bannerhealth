import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createAudienceLink, createPresenterLink } from "./link";
import { channelName, LOST_AFTER_MS, type AudienceState, type PresenterCommand } from "./protocol";
import { broadcastTransport, createMemoryHub, type Transport } from "./transport";

const base: Omit<AudienceState, "claimedAt"> = {
  index: 0,
  count: 6,
  slideId: "title",
  pos: { build: 0 },
  black: false,
  notes: false,
  look: { tone: "dark", site: "framed" },
  auto: true,
  admin: { available: false, open: false },
  visible: true,
};

function deckWindow(t: Transport, state: Partial<typeof base> = {}) {
  let current = { ...base, ...state };
  const ran: PresenterCommand[] = [];
  const link = createAudienceLink({ deckId: "banner", transport: t, read: () => current, run: (c) => ran.push(c) });
  return {
    link,
    ran,
    move(next: Partial<typeof base>) {
      current = { ...current, ...next };
      link.changed();
    },
  };
}

describe("presenter link", () => {
  beforeEach(() => vi.useFakeTimers());
  afterEach(() => vi.useRealTimers());

  it("waits for a deck window, then follows its state", async () => {
    const hub = createMemoryHub();
    const presenter = createPresenterLink({ deckId: "banner", transport: hub.connect() });
    expect(presenter.snapshot().status).toEqual({ kind: "waiting", reason: "never" });
    const deck = deckWindow(hub.connect());
    await vi.advanceTimersByTimeAsync(10);
    expect(presenter.snapshot()).toMatchObject({ status: { kind: "connected" }, state: { slideId: "title" }, decks: 1 });
    deck.move({ index: 1, slideId: "meet-luisa" });
    await vi.advanceTimersByTimeAsync(10);
    expect(presenter.snapshot().state?.slideId).toBe("meet-luisa");
  });

  it("stays connected on the heartbeat, shows a lost signal, and a closed window", async () => {
    const hub = createMemoryHub();
    const presenter = createPresenterLink({ deckId: "banner", transport: hub.connect() });
    const t = hub.connect();
    let muted = false;
    const deck = deckWindow({ ...t, send: (msg) => !muted && t.send(msg) });
    await vi.advanceTimersByTimeAsync(5000);
    expect(presenter.snapshot().status.kind).toBe("connected");
    muted = true;
    await vi.advanceTimersByTimeAsync(LOST_AFTER_MS + 600);
    expect(presenter.snapshot().status.kind).toBe("lost");
    expect(presenter.snapshot().state?.slideId).toBe("title");
    muted = false;
    deck.link.close();
    await vi.advanceTimersByTimeAsync(10);
    expect(presenter.snapshot().status).toEqual({ kind: "waiting", reason: "closed" });
  });

  it("runs each command once, only in the deck window it follows", async () => {
    const hub = createMemoryHub();
    const presenter = createPresenterLink({ deckId: "banner", transport: hub.connect() });
    const a = deckWindow(hub.connect());
    await vi.advanceTimersByTimeAsync(10);
    const b = deckWindow(hub.connect());
    await vi.advanceTimersByTimeAsync(10);
    expect(presenter.snapshot().decks).toBe(2);
    expect(presenter.send({ type: "next" })).toBe(true);
    await vi.advanceTimersByTimeAsync(10);
    expect(a.ran).toEqual([{ type: "next" }]);
    expect(b.ran).toEqual([]);
    // P pressed in the second window: the presenter follows it.
    b.link.claim();
    await vi.advanceTimersByTimeAsync(10);
    presenter.send({ type: "black", value: "black" });
    await vi.advanceTimersByTimeAsync(10);
    expect(b.ran).toEqual([{ type: "black", value: "black" }]);
    expect(a.ran).toHaveLength(1);
  });

  it("reconnects when the deck window reloads, and refuses commands with nobody there", async () => {
    const hub = createMemoryHub();
    const presenter = createPresenterLink({ deckId: "banner", transport: hub.connect() });
    expect(presenter.send({ type: "next" })).toBe(false);
    const first = deckWindow(hub.connect());
    await vi.advanceTimersByTimeAsync(10);
    first.link.close();
    const second = deckWindow(hub.connect(), { index: 2, slideId: "triage", pos: { step: "home" } });
    await vi.advanceTimersByTimeAsync(10);
    expect(presenter.snapshot()).toMatchObject({ status: { kind: "connected" }, state: { slideId: "triage" } });
    presenter.send({ type: "next" });
    await vi.advanceTimersByTimeAsync(10);
    expect(second.ran).toEqual([{ type: "next" }]);
  });

  it("flags a deck window on another protocol version", async () => {
    const hub = createMemoryHub();
    const presenter = createPresenterLink({ deckId: "banner", transport: hub.connect() });
    hub.connect().send({ v: 2, deck: "banner", from: "old", type: "hello", role: "audience" } as never);
    await vi.advanceTimersByTimeAsync(10);
    expect(presenter.snapshot().incompatible).toBe(true);
  });
});

describe("over a real BroadcastChannel", () => {
  it("connects and delivers a command", async () => {
    const name = channelName("banner");
    const presenter = createPresenterLink({ deckId: "banner", transport: broadcastTransport(name)! });
    const deck = deckWindow(broadcastTransport(name)!);
    await vi.waitFor(() => expect(presenter.snapshot().status.kind).toBe("connected"));
    presenter.send({ type: "prev" });
    await vi.waitFor(() => expect(deck.ran).toEqual([{ type: "prev" }]));
    presenter.close();
    deck.link.close();
  });
});
