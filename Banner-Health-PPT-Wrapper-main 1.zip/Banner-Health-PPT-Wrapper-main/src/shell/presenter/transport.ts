import type { DeckMessage } from "./protocol";

// How the two windows reach each other. A BroadcastChannel covers one browser on one machine; a
// WebSocket relay (a follow-along link) would be another Transport.

export interface Transport {
  send(msg: DeckMessage): void;
  subscribe(listener: (data: unknown) => void): () => void;
  close(): void;
}

/** Null where BroadcastChannel doesn't exist. */
export function broadcastTransport(name: string): Transport | null {
  if (typeof BroadcastChannel === "undefined") return null;
  const channel = new BroadcastChannel(name);
  const listeners = new Set<(data: unknown) => void>();
  channel.onmessage = (e) => listeners.forEach((l) => l(e.data));
  return {
    send: (msg) => channel.postMessage(msg),
    subscribe(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    close() {
      listeners.clear();
      channel.close();
    },
  };
}

/** In-memory endpoints for tests: a message reaches every other endpoint on a 0 ms timer, like a channel. */
export function createMemoryHub() {
  const ends = new Set<(data: unknown) => void>();
  return {
    connect(): Transport {
      const listeners = new Set<(data: unknown) => void>();
      const deliver = (data: unknown) => listeners.forEach((l) => l(data));
      ends.add(deliver);
      return {
        send(msg) {
          const data = structuredClone(msg);
          for (const other of ends) if (other !== deliver) setTimeout(() => other(data), 0);
        },
        subscribe(listener) {
          listeners.add(listener);
          return () => {
            listeners.delete(listener);
          };
        },
        close() {
          ends.delete(deliver);
          listeners.clear();
        },
      };
    },
  };
}
