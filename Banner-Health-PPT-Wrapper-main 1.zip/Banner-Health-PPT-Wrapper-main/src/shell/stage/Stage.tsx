"use client";

import { createContext, useCallback, useContext, useLayoutEffect, useMemo, useRef } from "react";
import { ScaledSpace } from "@/motion";

// The 16:9 canvas. Slides are designed at 1920×1080 (Figma slide size, crisp 1:1 on a 1080p screen
// share, 3840×2160 at 2× for exports) and scaled to whatever space the stage area has, which
// shrinks live when the admin drawer docks beside it.

export const CANVAS_W = 1920;
export const CANVAS_H = 1080;

type StageContextValue = {
  /** Current screen pixels per canvas pixel. */
  getScale(): number;
  canvas: React.RefObject<HTMLDivElement | null>;
};

const StageContext = createContext<StageContextValue>({ getScale: () => 1, canvas: { current: null } });
export const useStage = () => useContext(StageContext);

export function Stage({ children, letterbox = "#000" }: { children: React.ReactNode; letterbox?: string }) {
  const area = useRef<HTMLDivElement>(null);
  const canvas = useRef<HTMLDivElement>(null);
  const fit = useRef(1);

  useLayoutEffect(() => {
    const el = area.current;
    const cv = canvas.current;
    if (!el || !cv) return;
    const apply = () => {
      const w = el.clientWidth;
      const h = el.clientHeight;
      const s = Math.max(0.05, Math.min(w / CANVAS_W, h / CANVAS_H));
      // Snap the offset to device pixels so 1px hairlines stay crisp.
      const dpr = window.devicePixelRatio || 1;
      const x = Math.round(((w - CANVAS_W * s) / 2) * dpr) / dpr;
      const y = Math.round(((h - CANVAS_H * s) / 2) * dpr) / dpr;
      fit.current = s;
      // Written straight to the DOM: resizing (and the admin drawer opening) never re-renders slides.
      cv.style.transform = `translate(${x}px, ${y}px) scale(${s})`;
    };
    const ro = new ResizeObserver(apply);
    ro.observe(el);
    apply();
    return () => ro.disconnect();
  }, []);

  const getScale = useCallback(() => fit.current, []);
  const value = useMemo(() => ({ getScale, canvas }), [getScale]);

  return (
    <div ref={area} className="relative h-full w-full min-w-0 overflow-hidden" style={{ background: letterbox }}>
      <div
        ref={canvas}
        data-deck-canvas=""
        className="absolute top-0 left-0 origin-top-left overflow-hidden"
        style={{ width: CANVAS_W, height: CANVAS_H }}
      >
        <StageContext.Provider value={value}>
          <ScaledSpace getScale={getScale}>{children}</ScaledSpace>
        </StageContext.Provider>
      </div>
    </div>
  );
}
