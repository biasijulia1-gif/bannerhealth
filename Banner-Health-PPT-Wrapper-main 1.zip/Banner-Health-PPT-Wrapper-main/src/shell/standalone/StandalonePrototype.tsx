"use client";

import { useEffect, useMemo, useState, useSyncExternalStore } from "react";
import { MotionTokensProvider } from "@/motion";
import type { InProcessPrototype, StepId } from "../prototype/contract";
import { createShellEnv } from "../env";
import { PhoneFrame } from "../devices/PhoneFrame";

const INPUT = { pointer: true, keyboard: true };

function readUrl(steps: readonly StepId[]) {
  const p = new URLSearchParams(window.location.search);
  const raw = p.get("step");
  return { step: raw && steps.includes(raw) ? raw : steps[0], mobile: p.get("device") === "mobile" };
}

// A prototype on its own, at the size of the window (or in a phone), for building and comparing.
// `?step=<id>` deep-links any state and stays in sync; `&device=mobile` shows the phone layout.
export function StandalonePrototype({ prototype }: { prototype: InProcessPrototype }) {
  const { manifest } = prototype;
  const [initial] = useState(() => readUrl(manifest.steps));
  const session = useMemo(() => {
    const env = createShellEnv();
    const s = prototype.createSession({ initialStep: manifest.steps[0], env, autoAdvance: true });
    // A deep link lands settled, exactly like the deck's ← and deep links.
    if (initial.step !== manifest.steps[0]) s.goTo(initial.step, { instant: true, source: "shell" });
    return s;
  }, [prototype, manifest, initial]);
  useEffect(() => () => session.dispose(), [session]);

  const { step } = useSyncExternalStore(session.subscribe, session.getState, session.getState);

  useEffect(() => {
    const url = new URL(window.location.href);
    if (step === manifest.steps[0]) url.searchParams.delete("step");
    else url.searchParams.set("step", step);
    window.history.replaceState(null, "", url);
  }, [step, manifest]);

  // Shift+← / Shift+→ step through the journey (← lands instantly, like the deck).
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!e.shiftKey || e.metaKey || e.ctrlKey) return;
      const i = manifest.steps.indexOf(session.getState().step);
      if (e.key === "ArrowRight" && i < manifest.steps.length - 1) session.goTo(manifest.steps[i + 1], { source: "shell" });
      if (e.key === "ArrowLeft" && i > 0) session.goTo(manifest.steps[i - 1], { instant: true, source: "shell" });
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [session, manifest]);

  const View = prototype.View;
  const view = (
    <View session={session} instanceId={initial.mobile ? "phone" : "desk"} layout={initial.mobile ? "mobile" : "desktop"} role="primary" input={INPUT} />
  );

  return (
    <MotionTokensProvider>
      {initial.mobile ? (
        <div className="grid h-dvh w-full place-items-center bg-[#eef3f8]">
          <PhoneFrame className="max-h-[96dvh]">{view}</PhoneFrame>
        </div>
      ) : (
        <div className="h-dvh w-full bg-white">{view}</div>
      )}
      <div className="pointer-events-none fixed bottom-4 left-4 z-[200] rounded-full bg-black/75 px-4 py-2 font-[family-name:var(--font-val-sans)] text-[12px] text-white">
        {manifest.labels[step] ?? step} · Shift+←/→
      </div>
    </MotionTokensProvider>
  );
}
