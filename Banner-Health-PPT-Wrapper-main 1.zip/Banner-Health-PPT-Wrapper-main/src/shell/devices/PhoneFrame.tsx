// A 390×780 phone. Its 372px screen gets the prototype's mobile layout through container queries.
// translateZ makes the screen the containing block, so fixed sheets stay inside the phone.
export function PhoneFrame({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative h-[780px] w-[390px] rounded-[56px] bg-[#0b0d12] p-[9px] shadow-[0_60px_120px_-40px_rgba(0,33,95,0.55)] ${className}`}>
      <div className="relative flex h-full w-full flex-col overflow-hidden rounded-[47px] bg-white [transform:translateZ(0)]">
        <StatusBar />
        <div className="relative min-h-0 flex-1">{children}</div>
        <div className="pointer-events-none absolute top-2.5 left-1/2 z-[80] h-[30px] w-[110px] -translate-x-1/2 rounded-full bg-[#0b0d12]" />
      </div>
    </div>
  );
}

function StatusBar() {
  return (
    <div className="flex h-[48px] shrink-0 items-center justify-between px-8 pt-1 font-[family-name:var(--font-banner)] text-[15px] font-semibold text-[#0b0d12]">
      <span>9:41</span>
      <span className="flex items-center gap-1.5">
        <svg width="18" height="12" viewBox="0 0 18 12" fill="currentColor" aria-hidden>
          <rect x="0" y="8" width="3" height="4" rx="1" />
          <rect x="5" y="5.5" width="3" height="6.5" rx="1" />
          <rect x="10" y="3" width="3" height="9" rx="1" />
          <rect x="15" y="0" width="3" height="12" rx="1" />
        </svg>
        <svg width="16" height="12" viewBox="0 0 16 12" fill="currentColor" aria-hidden>
          <path d="M8 2.2c2.3 0 4.4.9 6 2.4l1.2-1.2A10.2 10.2 0 0 0 8 .5 10.2 10.2 0 0 0 .8 3.4L2 4.6a8.5 8.5 0 0 1 6-2.4Zm0 3.4c1.4 0 2.6.5 3.6 1.4l1.2-1.2A6.8 6.8 0 0 0 8 3.9a6.8 6.8 0 0 0-4.8 1.9L4.4 7c1-.9 2.2-1.4 3.6-1.4ZM8 9l2.4-1a3.4 3.4 0 0 0-4.8 0L8 9Z" />
        </svg>
        <span className="relative h-[12px] w-[25px] rounded-[4px] border border-current/40 p-[1.5px]">
          <span className="block h-full w-[80%] rounded-[2px] bg-current" />
        </span>
      </span>
    </div>
  );
}
