"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { settle } from "@/motion";
import { useDeck } from "../deck/DeckProvider";
import type { SlidePos } from "../deck/machine";
import type { BrandSlideConfig } from "../deck/schema";
import { BuildContext } from "../builds/Build";

// A live-React brand slide. → reveals the next build; past the last build the deck moves on.
// ← hides the last build instantly.
export function BrandSlide({ slide, active, landing }: { slide: BrandSlideConfig; active: boolean; landing: SlidePos }) {
  const { reportPos, registerController } = useDeck();
  const max = slide.builds ?? 0;
  const [build, setBuild] = useState(() => Math.min(landing.build ?? 0, max));
  const buildRef = useRef(build);
  useEffect(() => {
    buildRef.current = build;
  }, [build]);

  const controller = useMemo(
    () => ({
      next() {
        if (buildRef.current >= max) return false;
        const b = buildRef.current + 1;
        buildRef.current = b;
        setBuild(b);
        reportPos({ build: b });
        return true;
      },
      prev() {
        if (buildRef.current <= 0) return false;
        void settle(3);
        const b = buildRef.current - 1;
        buildRef.current = b;
        setBuild(b);
        reportPos({ build: b });
        return true;
      },
      isBusy: () => false,
      finish() {},
      idle: () => Promise.resolve(),
    }),
    [max, reportPos],
  );

  useEffect(() => {
    if (!active) return;
    return registerController(controller);
  }, [active, controller, registerController]);

  const Component = slide.Component;
  return (
    <BuildContext.Provider value={build}>
      <Component build={build} />
    </BuildContext.Provider>
  );
}
