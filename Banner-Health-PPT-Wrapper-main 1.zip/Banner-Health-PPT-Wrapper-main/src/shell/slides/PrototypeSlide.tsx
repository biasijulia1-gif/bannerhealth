"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { deck as deckTokens, motionStore, useTokens } from "@/motion";
import { useDeck, type SlideController } from "../deck/DeckProvider";
import type { SlidePos } from "../deck/machine";
import { presentationOf, type PrototypeSlideConfig } from "../deck/schema";
import { createShellEnv } from "../env";
import type { ViewHandle } from "../prototype/contract";
import { createPrototypeController } from "../prototype/controller";
import { ProtoViewport } from "../prototype/ProtoViewport";
import { toCss } from "../transitions/css";

// A live prototype on a slide: one journey step per →, still clickable by hand. The session is
// created where the deck says to land (its first step going forward, its last going back, or a
// deep-linked step), so remounts and deep links always reproduce the same frame.
export function PrototypeSlide({ slide, active, landing }: { slide: PrototypeSlideConfig; active: boolean; landing: SlidePos }) {
  const { prototypes, reportPos, registerController, flags, state } = useDeck();
  const d = useTokens(deckTokens);
  const prototype = prototypes[slide.prototype];
  const env = useMemo(() => createShellEnv(), []);
  const [session] = useState(() =>
    prototype.createSession({ initialStep: landing.step ?? slide.from, env, autoAdvance: (slide.autoAdvance ?? true) && !flags.noauto }),
  );
  const handle = useRef<ViewHandle | null>(null);
  const onHandle = useCallback((h: ViewHandle | null) => {
    handle.current = h;
  }, []);

  // While this is the active slide, the deck drives it through a journey controller, plus moment
  // replay for the admin panel.
  useEffect(() => {
    if (!active) return;
    const { manifest } = prototype;
    const { moments = {}, steps } = manifest;
    const controller = createPrototypeController({
      session,
      manifest,
      from: slide.from,
      to: slide.to,
      getHandle: () => handle.current,
      env,
    });
    const inRange = (step: string) => steps.indexOf(step) >= steps.indexOf(slide.from) && steps.indexOf(step) <= steps.indexOf(slide.to);
    const slideController: SlideController = {
      next: controller.next,
      prev: controller.prev,
      isBusy: controller.isBusy,
      finish: controller.finish,
      idle: controller.idle,
      moments: () =>
        Object.entries(moments)
          .filter(([, m]) => m.at === session.getState().step)
          .map(([id]) => id),
      replayMoment(id) {
        const m = moments[id];
        if (!m || !inRange(m.at)) return false;
        if (m.replay === "remount" || !m.from || !inRange(m.from)) {
          if (session.getState().step !== m.at) controller.goTo(m.at, { instant: true });
          motionStore.replay(id);
          return true;
        }
        // Land just before the moment, then play the same scripted step the audience sees.
        controller.goTo(m.from, { instant: true });
        requestAnimationFrame(() => requestAnimationFrame(() => requestAnimationFrame(() => controller.next())));
        return true;
      },
    };
    const unregister = registerController(slideController);
    return () => {
      unregister();
      controller.dispose();
    };
  }, [active, prototype, session, slide.from, slide.to, env, registerController]);

  // Steps clicked by hand count too: the deck (and the URL) follow the session.
  useEffect(() => {
    if (!active) return;
    return session.subscribe((e) => {
      if (e?.type === "step") reportPos({ step: e.step });
    });
  }, [active, session, reportPos]);

  useEffect(() => () => session.dispose(), [session]);

  return (
    <ProtoViewport
      prototype={prototype}
      session={session}
      presentation={presentationOf(slide, state.look)}
      instanceId={`${slide.id}-desk`}
      onHandle={onHandle}
      zoom={toCss(d.zoom)}
    />
  );
}
