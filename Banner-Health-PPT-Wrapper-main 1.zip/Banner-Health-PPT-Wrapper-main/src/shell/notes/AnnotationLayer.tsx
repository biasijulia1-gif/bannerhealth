"use client";

import { deck as deckTokens, useTokens } from "@/motion";
import { useDeck } from "../deck/DeckProvider";
import { cssTransition, toCss } from "../transitions/css";

// The audience-visible note for the current slide (N). Its look comes from the theme, so
// Sebastian's design replaces one component.
export function AnnotationLayer() {
  const { deck, state, theme } = useDeck();
  const d = useTokens(deckTokens);
  const slide = deck.slides[state.index];
  const text = slide.annotation ?? "";
  const Annotation = theme.Annotation;
  return <Annotation text={text} visible={state.notes && !!text} transition={cssTransition(["opacity", "transform"], toCss(d.slide))} />;
}
