"use client";

import { deck as deckTokens, useTokens } from "@/motion";
import { useDeck } from "../deck/DeckProvider";
import { presentationOf, toneOf } from "../deck/schema";
import { cssTransition, toCss } from "./css";

// The brand frame (deck label, slide number, asterisk) as one persistent layer above the slides,
// so it holds still while slides change and only fades between its dark and light versions.
export function FrameLayer() {
  const { deck, state, theme } = useDeck();
  const d = useTokens(deckTokens);
  const slide = deck.slides[state.index];
  const frame = slide.frame === false ? null : (slide.frame ?? {});
  const fade = toCss(d.frame);
  const transition = cssTransition(["opacity", "color", "background-color"], fade);

  // The frame steps aside while the site fills the slide, where it would sit on the site's nav. On
  // a prototype slide that only happens with Z, so the frame clears quickly as the site grows and
  // comes back once the site has shrunk clear of it.
  const filling = slide.type === "prototype" && presentationOf(slide, state.look) === "fullbleed";
  const zoomable = slide.type === "prototype" && !slide.presentation;
  const show = filling
    ? cssTransition(["opacity"], zoomable ? { ...fade, ms: fade.ms * 0.6 } : fade)
    : cssTransition(["opacity"], fade, zoomable ? toCss(d.zoom).ms * 0.6 : 0);

  const Frame = theme.Frame;
  return (
    <div
      data-deck-frame={frame && !filling ? "shown" : "hidden"}
      className="pointer-events-none absolute inset-0 z-40"
      style={{ opacity: filling ? 0 : 1, transition: show }}
    >
      <Frame
        tone={toneOf(slide, state.look.tone)}
        visible={frame !== null}
        number={state.index + 1}
        showNumber={frame?.number ?? true}
        band={frame?.band ?? false}
        label={deck.label}
        transition={transition}
      />
    </div>
  );
}
