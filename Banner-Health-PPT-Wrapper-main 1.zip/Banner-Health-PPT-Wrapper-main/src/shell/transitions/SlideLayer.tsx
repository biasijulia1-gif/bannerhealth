"use client";

import { useEffect, useState } from "react";
import { deck as deckTokens, useTokens } from "@/motion";
import { useDeck } from "../deck/DeckProvider";
import type { SlidePos } from "../deck/machine";
import { toneOf, type SlideConfig, type TransitionKind } from "../deck/schema";
import { CANVAS_W } from "../stage/Stage";
import { BrandSlide } from "../slides/BrandSlide";
import { PrototypeSlide } from "../slides/PrototypeSlide";
import { cssTransition, toCss } from "./css";

// Renders the active slide and, during a transition, the outgoing one. The change itself is a CSS
// transition driven by the deck's motion tokens, so it plays even while the incoming slide settles
// its own contents instantly (landing mid-journey, going back).

type Layer = {
  key: string;
  index: number;
  landing: SlidePos;
  phase: "enter" | "in" | "out";
  dir: 1 | -1;
  kind: TransitionKind;
};

export function SlideLayer() {
  const { deck, state } = useDeck();
  const d = useTokens(deckTokens);
  const slide = deck.slides[state.index];
  const key = `${slide.id}:${state.epoch}`;
  const kindFor = (s: SlideConfig): TransitionKind => s.transition ?? d.transition;

  const [layers, setLayers] = useState<Layer[]>(() => [
    { key, index: state.index, landing: state.pos, phase: "in", dir: 1, kind: kindFor(slide) },
  ]);

  // A new active slide: cut straight to it, or add it on top of the outgoing one. Derived while
  // rendering (React's pattern for state that follows a prop), so the new slide mounts at once.
  const [shownKey, setShownKey] = useState(key);
  if (shownKey !== key) {
    setShownKey(key);
    const kind = kindFor(slide);
    const next: Layer = { key, index: state.index, landing: state.pos, phase: "enter", dir: state.nav.dir, kind };
    setLayers(
      state.nav.instant || kind === "cut"
        ? [{ ...next, phase: "in" }]
        : [...layers.filter((l) => l.phase !== "out").map((l) => ({ ...l, phase: "out" as const })), next],
    );
  }

  // enter → in on the next frame, so the browser has painted the start state.
  useEffect(() => {
    if (!layers.some((l) => l.phase === "enter")) return;
    let inner = 0;
    const outer = requestAnimationFrame(() => {
      inner = requestAnimationFrame(() => setLayers((ls) => ls.map((l) => (l.phase === "enter" ? { ...l, phase: "in" } : l))));
    });
    return () => {
      cancelAnimationFrame(outer);
      cancelAnimationFrame(inner);
    };
  }, [layers]);

  const timing = toCss(d.slide);

  // Drop outgoing slides once the incoming one has fully arrived.
  useEffect(() => {
    if (!layers.some((l) => l.phase === "out")) return;
    const id = window.setTimeout(() => setLayers((ls) => ls.filter((l) => l.phase !== "out")), timing.ms + 80);
    return () => window.clearTimeout(id);
  }, [layers, timing.ms]);

  const active = layers[layers.length - 1];
  const fade = toCss(d.frame);

  return (
    // --deck-fade times the theme's light/dark fade (T), in step with the frame.
    <div className="absolute inset-0" style={{ "--deck-fade": `${fade.ms}ms ${fade.easing}` } as React.CSSProperties}>
      {layers.map((layer) => {
        const s = deck.slides[layer.index];
        return (
          <div
            key={layer.key}
            className="absolute inset-0 overflow-hidden"
            style={{
              pointerEvents: layer.phase === "out" ? "none" : undefined,
              zIndex: layer === active ? 2 : 1,
              ...layerStyle(layer, active, timing, d.pushDistance),
            }}
          >
            {/* The theme draws each tone's ground and type from data-tone. */}
            <div data-tone={toneOf(s, state.look.tone)} className="absolute inset-0">
              {s.type === "prototype" ? (
                <PrototypeSlide slide={s} active={layer === active} landing={layer.landing} />
              ) : (
                <BrandSlide slide={s} active={layer === active} landing={layer.landing} />
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}

function layerStyle(layer: Layer, active: Layer, timing: ReturnType<typeof toCss>, push: number): React.CSSProperties {
  const kind = active.kind;
  const travel = push * CANVAS_W * active.dir;
  const half = { ms: timing.ms / 2, easing: timing.easing };
  if (kind === "cut") return {};
  if (layer.phase === "enter") {
    if (kind === "push") return { opacity: 0, transform: `translateX(${travel}px)` };
    return { opacity: 0 };
  }
  if (layer.phase === "in") {
    if (kind === "push") return { opacity: 1, transform: "translateX(0)", transition: cssTransition(["opacity", "transform"], timing) };
    if (kind === "fade-through") return { opacity: 1, transition: cssTransition(["opacity"], half, half.ms) };
    return { opacity: 1, transition: cssTransition(["opacity"], timing) };
  }
  // Outgoing. A crossfade keeps the old slide fully opaque underneath, so nothing dips to black.
  if (kind === "push") return { opacity: 0, transform: `translateX(${-travel}px)`, transition: cssTransition(["opacity", "transform"], timing) };
  if (kind === "fade-through") return { opacity: 0, transition: cssTransition(["opacity"], half) };
  return { opacity: 1 };
}
