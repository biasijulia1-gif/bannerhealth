import { spring, type Transition } from "motion/react";

// Deck-level transitions (slides, frame) run as CSS transitions, not Motion animations, so an
// instant jump inside a slide (which pauses every Motion animation for a few frames) can never
// freeze a slide change in progress. Springs become CSS linear() easings with Motion's own math.

export type CssTiming = { ms: number; easing: string };

export function toCss(t: Transition | undefined): CssTiming {
  if (!t) return { ms: 0, easing: "linear" };
  if (t.type === "spring") {
    const generator = spring({ keyframes: [0, 1], visualDuration: t.visualDuration ?? 0.5, bounce: t.bounce ?? 0 });
    const match = /^([\d.]+)ms (.*)$/.exec(generator.toString());
    if (match) return { ms: Number(match[1]), easing: match[2] };
    return { ms: (t.visualDuration ?? 0.5) * 1000, easing: "cubic-bezier(0.22, 1, 0.36, 1)" };
  }
  const ease = Array.isArray(t.ease) && t.ease.length === 4 && typeof t.ease[0] === "number" ? `cubic-bezier(${t.ease.join(", ")})` : "ease-out";
  return { ms: (typeof t.duration === "number" ? t.duration : 0.3) * 1000, easing: ease };
}

export const cssTransition = (props: string[], timing: CssTiming, delayMs = 0) =>
  props.map((p) => `${p} ${timing.ms}ms ${timing.easing} ${delayMs}ms`).join(", ");
