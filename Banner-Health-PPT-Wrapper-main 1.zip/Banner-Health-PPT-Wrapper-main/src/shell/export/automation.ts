"use client";

import { useEffect } from "react";
import { freeze } from "@/motion";
import type { DeckApi, DeckSnapshot } from "../deck/DeckProvider";
import type { SlidePos } from "../deck/machine";
import type { DeckFlags } from "../deck/url";

// window.__deck: how the export script and the smoke test drive the deck. Installed with ?export,
// ?debug or in development. Replaces v1's window.__capture.

export type DeckAutomation = {
  version: 1;
  position(): DeckSnapshot;
  sequence(): ReturnType<DeckApi["sequence"]>;
  next(): void;
  prev(): void;
  goTo(slide: number | string, pos?: SlidePos): void;
  isBusy(): boolean;
  idle(): Promise<void>;
  /** Skip every animation from now on (still frames). */
  freeze(): void;
  /** Resolves when fonts and images are ready, no scripted advance is running and nothing moves. */
  settled(opts?: { timeout?: number; quietMs?: number }): Promise<{ ok: boolean; waitedMs: number }>;
  canvasRect(): { x: number; y: number; width: number; height: number };
};

declare global {
  interface Window {
    __deck?: DeckAutomation;
  }
}

const frame = () => new Promise<void>((r) => requestAnimationFrame(() => r()));

export function useDeckAutomation(api: DeckApi, flags: DeckFlags) {
  useEffect(() => {
    if (!(flags.export || flags.debug || process.env.NODE_ENV === "development")) return;
    const canvas = () => document.querySelector<HTMLElement>("[data-deck-canvas]");
    window.__deck = {
      version: 1,
      position: () => api.snapshot(),
      sequence: () => api.sequence(),
      next: () => api.next(),
      prev: () => api.prev(),
      goTo: (slide, pos) => api.goTo(slide, pos, { instant: true }),
      isBusy: () => api.isBusy(),
      idle: () => api.idle(),
      freeze() {
        freeze();
        document.documentElement.dataset.export = "";
      },
      async settled({ timeout = 10000, quietMs = 600 } = {}) {
        const start = performance.now();
        await frame();
        await frame();
        await document.fonts.ready;
        await api.idle();
        const imgs = [...(canvas()?.querySelectorAll("img") ?? [])];
        await Promise.all(imgs.map((img) => (img.complete ? img.decode().catch(() => {}) : new Promise((r) => img.addEventListener("load", r, { once: true })))));
        // Quiet means no running CSS/WAAPI animation with an end, for `quietMs` in a row.
        let quietSince = performance.now();
        while (performance.now() - start < timeout) {
          const moving = document.getAnimations().some((a) => {
            const end = a.effect?.getComputedTiming().endTime;
            return a.playState === "running" && typeof end === "number" && Number.isFinite(end);
          });
          if (moving) quietSince = performance.now();
          if (performance.now() - quietSince >= quietMs && !api.isBusy()) return { ok: true, waitedMs: performance.now() - start };
          await frame();
        }
        return { ok: false, waitedMs: performance.now() - start };
      },
      canvasRect() {
        const r = canvas()?.getBoundingClientRect();
        return { x: r?.left ?? 0, y: r?.top ?? 0, width: r?.width ?? 0, height: r?.height ?? 0 };
      },
    };
    return () => {
      delete window.__deck;
    };
  }, [api, flags]);
}
