import type { Rect, ScrollPort, ViewHandle } from "./contract";

// ViewHandle for an in-process view: every lookup is scoped to the view's own root, so two copies
// of the same site on one slide never answer for each other.

function findIn(root: HTMLElement, id: string): HTMLElement | null {
  const nodes = root.querySelectorAll<HTMLElement>(`[data-target="${CSS.escape(id)}"]`);
  for (const node of nodes) {
    const r = node.getBoundingClientRect();
    if (r.width > 0 && r.height > 0) return node;
  }
  return null;
}

/** Ratio between on-screen pixels and the root's layout pixels (the stage and slide scale). */
function scaleOf(root: HTMLElement) {
  return root.offsetWidth ? root.getBoundingClientRect().width / root.offsetWidth : 1;
}

export function createScrollPort(scroller: HTMLElement, root: HTMLElement): ScrollPort {
  let programmatic = 0;
  return {
    get: () => ({ top: scroller.scrollTop, max: Math.max(0, scroller.scrollHeight - scroller.clientHeight) }),
    set: (top) => {
      programmatic++;
      scroller.scrollTop = top;
      requestAnimationFrame(() => (programmatic = Math.max(0, programmatic - 1)));
    },
    anchors: () => {
      const base = scroller.getBoundingClientRect().top;
      const s = scaleOf(root);
      return [...scroller.querySelectorAll<HTMLElement>("[data-anchor]")].map((el) => ({
        id: el.dataset.anchor ?? "",
        top: (el.getBoundingClientRect().top - base) / s + scroller.scrollTop,
      }));
    },
    onScroll: (listener) => {
      const onScroll = () => listener(scroller.scrollTop, programmatic === 0);
      scroller.addEventListener("scroll", onScroll, { passive: true });
      return () => scroller.removeEventListener("scroll", onScroll);
    },
  };
}

export function createDomHandle(root: HTMLElement, scroller: () => HTMLElement | null): ViewHandle {
  const scrollEl = scroller();
  return {
    rect(id): Rect | null {
      const el = findIn(root, id);
      if (!el) return null;
      const base = root.getBoundingClientRect();
      const r = el.getBoundingClientRect();
      const s = scaleOf(root);
      return { x: (r.left - base.left) / s, y: (r.top - base.top) / s, w: r.width / s, h: r.height / s };
    },
    activate(id) {
      const el = findIn(root, id);
      if (!el) return false;
      el.click();
      return true;
    },
    matches(id, selector) {
      const el = findIn(root, id);
      return !!el && el.matches(selector);
    },
    scroll: scrollEl ? createScrollPort(scrollEl, root) : null,
  };
}
