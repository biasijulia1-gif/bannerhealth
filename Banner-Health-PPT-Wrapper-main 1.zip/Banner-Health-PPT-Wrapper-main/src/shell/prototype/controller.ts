import type { AdvanceAction, PrototypeManifest, PrototypeSession, ShellEnv, StepId, ViewHandle } from "./contract";

// Drives one prototype slide from the deck's arrow keys. → plays the same clicks a person would
// make (through the view handle, so the components' own handlers and timing run); ← lands on the
// previous step instantly. The prototype itself knows nothing about decks, ranges or cursors.

export type CursorDriver = {
  /** Travel to a target, resolving on arrival. `lead` is the travel time in seconds. */
  moveTo(target: string, lead: number): Promise<void>;
  press(target: string): void;
};

export interface PrototypeController {
  /** Plays the next step. False at (or past) the slide's last step, so the deck moves on. */
  next(): boolean;
  /** Lands on the previous step instantly. False at (or before) the slide's first step. */
  prev(): boolean;
  goTo(step: StepId, opts?: { instant?: boolean }): void;
  /** A scripted advance is in flight (cursor travel, the component's click-to-advance delay). */
  isBusy(): boolean;
  /** Completes the advance in flight now: a second press finishes the move, it never skips one. */
  finish(): void;
  /** Resolves when no advance is in flight. */
  idle(): Promise<void>;
  dispose(): void;
}

const MISSED_CLICK_MS = 2500;

export function createPrototypeController(o: {
  session: PrototypeSession;
  manifest: PrototypeManifest;
  from: StepId;
  to: StepId;
  getHandle: () => ViewHandle | null;
  getCursor?: () => CursorDriver | null;
  env: ShellEnv;
}): PrototypeController {
  const { session, manifest, env } = o;
  const index = (s: StepId) => manifest.steps.indexOf(s);
  let run: { expected: StepId; cancelled: boolean } | null = null;
  let waiters: Array<() => void> = [];

  const settleRun = () => {
    run = null;
    const w = waiters;
    waiters = [];
    w.forEach((f) => f());
  };

  const wait = (ms: number) => new Promise<void>((r) => window.setTimeout(r, ms));

  const waitForStep = (expected: StepId, ms: number) =>
    new Promise<boolean>((resolve) => {
      if (session.getState().step === expected) return resolve(true);
      const off = session.subscribe(() => {
        if (session.getState().step === expected) {
          off();
          window.clearTimeout(timer);
          resolve(true);
        }
      });
      const timer = window.setTimeout(() => {
        off();
        resolve(session.getState().step === expected);
      }, ms);
    });

  async function play(actions: AdvanceAction[], current: { expected: StepId; cancelled: boolean }) {
    for (const action of actions) {
      if (current.cancelled) return;
      if ("wait" in action) {
        await wait(action.wait * 1000 * env.timeScale());
      } else if ("go" in action) {
        session.goTo(action.go, { source: "shell" });
      } else if ("click" in action) {
        const handle = o.getHandle();
        if (!handle) continue;
        if (action.unless && handle.matches(action.click, action.unless)) continue;
        const cursor = o.getCursor?.();
        if (cursor) await cursor.moveTo(action.click, action.lead ?? 0.55);
        if (current.cancelled) return;
        cursor?.press(action.click);
        if (!handle.activate(action.click)) console.warn(`[deck] click target "${action.click}" not found`);
      } else if ("hover" in action) {
        const cursor = o.getCursor?.();
        if (cursor) await cursor.moveTo(action.hover, action.lead ?? 0.55);
      }
    }
    if (current.cancelled) return;
    const arrived = await waitForStep(current.expected, MISSED_CLICK_MS * env.timeScale());
    if (current.cancelled) return;
    // A missed click must never stall the live pitch: land on the expected step regardless.
    if (!arrived) {
      console.warn(`[deck] expected "${current.expected}" after the scripted advance; going there directly`);
      session.goTo(current.expected, { source: "shell" });
    }
    if (run === current) settleRun();
  }

  const controller: PrototypeController = {
    next() {
      if (run) {
        controller.finish();
        return true;
      }
      const step = session.getState().step;
      if (index(step) >= index(o.to)) return false;
      const expected = manifest.steps[index(step) + 1];
      const current = { expected, cancelled: false };
      run = current;
      void play(manifest.advance[step] ?? [{ go: expected }], current);
      return true;
    },
    prev() {
      if (run) {
        run.cancelled = true;
        settleRun();
      }
      const step = session.getState().step;
      if (index(step) <= index(o.from)) return false;
      session.goTo(manifest.steps[index(step) - 1], { instant: true, source: "shell" });
      return true;
    },
    goTo(step, opts) {
      if (run) {
        run.cancelled = true;
        settleRun();
      }
      session.goTo(step, { instant: opts?.instant, source: "shell" });
    },
    isBusy: () => run !== null,
    finish() {
      if (!run) return;
      const { expected } = run;
      run.cancelled = true;
      settleRun();
      if (session.getState().step !== expected) session.goTo(expected, { source: "shell" });
    },
    idle: () => (run ? new Promise<void>((r) => waiters.push(r)) : Promise.resolve()),
    dispose() {
      if (run) run.cancelled = true;
      settleRun();
    },
  };
  return controller;
}
