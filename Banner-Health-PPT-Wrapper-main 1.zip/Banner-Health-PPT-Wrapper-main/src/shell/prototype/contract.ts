import type { ComponentType } from "react";

// The contract between the deck shell and a prototype. A prototype is three parts:
// - a manifest: plain data (no React), so the presenter view and tooling can import it;
// - createSession(): an external store whose state is JSON-safe;
// - a View: the React component, which can be rendered more than once against one session.
// The shell only reaches into prototype DOM through a ViewHandle. That handle is the seam an
// iframe/postMessage adapter implements later, so every handle call site awaits its result.

export type StepId = string;
export type Rect = { x: number; y: number; w: number; h: number };

export type AdvanceAction =
  /** Click a [data-target]. `unless` is a selector that means "already done" (skip the click). */
  | { click: string; unless?: string; lead?: number }
  /** Move the cursor onto a target without clicking. */
  | { hover: string; lead?: number }
  /** Jump straight to a step (no on-screen control drives it). */
  | { go: StepId }
  | { wait: number };

export type Moment<S extends StepId = StepId> = {
  label: string;
  /** Step the moment plays on. */
  at: S;
  /** "advance": jump to `from`, then run the scripted advance. "remount": remount at `at`. */
  replay: "advance" | "remount";
  from?: S;
};

export interface PrototypeManifest<S extends StepId = StepId> {
  id: string;
  title: string;
  steps: readonly S[];
  labels: Record<S, string>;
  /** Layout size the prototype is designed at. The shell scales it, never relays it out. */
  viewports: { desktop: { w: number; h: number }; mobile?: { w: number; h: number } };
  /** What → does at each step. Steps without a script go straight to the next step. */
  advance: Partial<Record<S, AdvanceAction[]>>;
  /** Steps that move on by themselves (interactive pacing), unless the shell turns it off. */
  auto?: Partial<Record<S, { to: S; afterMs: number }>>;
  /** data-anchor ids in page order, per page, for scroll sync between two views. */
  anchors?: Record<string, readonly string[]>;
  moments?: Record<string, Moment<S>>;
  capabilities: { multiView: boolean; cursor: boolean; scroll: boolean };
}

export interface ShellEnv {
  /** Finish every running animation now (instant jumps). */
  settle(frames?: number): Promise<void>;
  justSettled(): boolean;
  /** Seconds multiplier from the global motion speed. */
  timeScale(): number;
  track(event: string, props?: Record<string, unknown>): void;
}

export type SessionSource = "ui" | "shell" | "auto";

export interface SessionState<S extends StepId = StepId> {
  step: S;
  prevStep: S | null;
  lang: string;
  /** Increments on every instant jump so components can reset local timelines. */
  jumpId: number;
}

export type SessionEvent<S extends StepId = StepId> =
  | { type: "step"; step: S; from: S | null; instant: boolean; source: SessionSource }
  | { type: "change" };

export interface PrototypeSession<S extends StepId = StepId, St extends SessionState<S> = SessionState<S>> {
  getState(): St;
  subscribe(listener: (e?: SessionEvent<S>) => void): () => void;
  goTo(step: S, opts?: { instant?: boolean; source?: SessionSource }): void;
  reset(step?: S): void;
  setAutoAdvance(on: boolean): void;
  dispose(): void;
}

export interface ScrollPort {
  get(): { top: number; max: number };
  set(top: number): void;
  anchors(): { id: string; top: number }[];
  onScroll(listener: (top: number, byUser: boolean) => void): () => void;
}

export interface ViewHandle {
  /** Target rect in the prototype's own layout pixels (relative to the view root). */
  rect(id: string): Rect | null;
  /** A real click, so the component's own handlers run. False when the target isn't there. */
  activate(id: string): boolean;
  matches(id: string, selector: string): boolean;
  scroll: ScrollPort | null;
}

export type ViewInput = { pointer: boolean; keyboard: boolean };

export interface ViewProps<Se extends PrototypeSession = PrototypeSession> {
  session: Se;
  instanceId: string;
  layout: "desktop" | "mobile";
  role: "primary" | "mirror";
  input: ViewInput;
  onHandle?: (handle: ViewHandle | null) => void;
}

export interface InProcessPrototype<S extends StepId = StepId, Se extends PrototypeSession<S> = PrototypeSession<S>> {
  manifest: PrototypeManifest<S>;
  createSession(opts: { initialStep: S; env: ShellEnv; autoAdvance: boolean }): Se;
  View: ComponentType<ViewProps<Se>>;
}

export const definePrototype = <S extends StepId, Se extends PrototypeSession<S>>(p: InProcessPrototype<S, Se>) => p;
