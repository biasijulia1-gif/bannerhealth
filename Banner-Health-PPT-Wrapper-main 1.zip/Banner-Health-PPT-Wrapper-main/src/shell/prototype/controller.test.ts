import { describe, expect, it, vi } from "vitest";
import type { PrototypeManifest, PrototypeSession, SessionEvent, ShellEnv, ViewHandle } from "./contract";
import { createPrototypeController } from "./controller";

const steps = ["home", "compose", "result", "done"] as const;

function fakeSession(start: string) {
  let state = { step: start, prevStep: null as string | null, lang: "en", jumpId: 0 };
  const listeners = new Set<(e?: SessionEvent) => void>();
  const goTo = vi.fn((step: string, opts?: { instant?: boolean; source?: string }) => {
    const from = state.step;
    state = { ...state, prevStep: from, step, jumpId: opts?.instant ? state.jumpId + 1 : state.jumpId };
    listeners.forEach((l) => l({ type: "step", step, from, instant: !!opts?.instant, source: "shell" }));
  });
  const session: PrototypeSession = {
    getState: () => state,
    subscribe(l) {
      listeners.add(l);
      return () => {
        listeners.delete(l);
      };
    },
    goTo,
    reset: () => {},
    setAutoAdvance: () => {},
    dispose: () => {},
  };
  return { session, goTo };
}

const manifest: PrototypeManifest = {
  id: "demo",
  title: "Demo",
  steps,
  labels: { home: "", compose: "", result: "", done: "" },
  viewports: { desktop: { w: 1440, h: 810 } },
  advance: { home: [{ click: "open" }], compose: [{ click: "send" }] },
  capabilities: { multiView: false, cursor: false, scroll: false },
};

const env: ShellEnv = { settle: async () => {}, justSettled: () => false, timeScale: () => 1, track: () => {} };
const inertHandle: ViewHandle = { rect: () => null, matches: () => false, activate: () => true, scroll: null };

describe("createPrototypeController", () => {
  it("plays the scripted click and waits for the step it causes", async () => {
    const { session } = fakeSession("home");
    // The component's own handler moves the journey on after its click delay.
    const handle: ViewHandle = {
      ...inertHandle,
      activate: (id) => {
        setTimeout(() => id === "open" && session.goTo("compose"), 20);
        return true;
      },
    };
    const c = createPrototypeController({ session, manifest, from: "home", to: "result", getHandle: () => handle, env });
    expect(c.next()).toBe(true);
    expect(c.isBusy()).toBe(true);
    await c.idle();
    expect(session.getState().step).toBe("compose");
    expect(c.isBusy()).toBe(false);
  });

  it("steps back instantly and reports the slide's boundaries", () => {
    const { session, goTo } = fakeSession("result");
    const c = createPrototypeController({ session, manifest, from: "home", to: "result", getHandle: () => null, env });
    expect(c.next()).toBe(false);
    expect(c.prev()).toBe(true);
    expect(goTo).toHaveBeenLastCalledWith("compose", { instant: true, source: "shell" });
    c.prev();
    expect(c.prev()).toBe(false);
  });

  it("completes the move in flight on a second press instead of skipping ahead", () => {
    const { session } = fakeSession("home");
    const c = createPrototypeController({ session, manifest, from: "home", to: "done", getHandle: () => inertHandle, env });
    c.next();
    expect(c.next()).toBe(true);
    expect(session.getState().step).toBe("compose");
    expect(c.isBusy()).toBe(false);
  });

  it("lands on the expected step when the click never arrives", async () => {
    vi.useFakeTimers();
    const { session } = fakeSession("home");
    const warn = vi.spyOn(console, "warn").mockImplementation(() => {});
    const c = createPrototypeController({ session, manifest, from: "home", to: "done", getHandle: () => inertHandle, env });
    c.next();
    await vi.advanceTimersByTimeAsync(3000);
    expect(session.getState().step).toBe("compose");
    expect(warn).toHaveBeenCalled();
    warn.mockRestore();
    vi.useRealTimers();
  });
});
