"use client";

import { useCallback, useMemo } from "react";
import { ScaledSpace } from "@/motion";
import type { Presentation } from "../deck/schema";
import { CANVAS_H, CANVAS_W, useStage } from "../stage/Stage";
import { cssTransition, type CssTiming } from "../transitions/css";
import type { InProcessPrototype, PrototypeSession, ViewHandle, ViewInput } from "./contract";

// Places a live prototype on the 1920×1080 canvas. The prototype always lays out at its native
// desktop size (1440×810 for Banner) and is scaled, never relaid out, so its breakpoints, type
// sizes and crops stay exactly as designed. A single transform places it, so changing framing
// (Z: framed ↔ fills the slide) is one smooth zoom of one layer.

const DECK_INPUT: ViewInput = { pointer: true, keyboard: false };
const BROWSER_CHROME = 44;

export function placement(presentation: Presentation, vw: number, vh: number) {
  if (presentation === "fullbleed") {
    const scale = Math.max(CANVAS_W / vw, CANVAS_H / vh);
    return { scale, x: (CANVAS_W - vw * scale) / 2, y: (CANVAS_H - vh * scale) / 2 };
  }
  if (presentation === "browser") {
    const scale = 1600 / vw;
    const h = vh * scale + BROWSER_CHROME;
    return { scale, x: (CANVAS_W - vw * scale) / 2, y: (CANVAS_H - h) / 2 + BROWSER_CHROME };
  }
  // framed: 1:1 inside the frame's margins.
  return { scale: 1, x: (CANVAS_W - vw) / 2, y: (CANVAS_H - vh) / 2 };
}

export function ProtoViewport({
  prototype,
  session,
  presentation,
  instanceId,
  onHandle,
  zoom,
}: {
  prototype: InProcessPrototype;
  session: PrototypeSession;
  presentation: Presentation;
  instanceId: string;
  onHandle?: (handle: ViewHandle | null) => void;
  /** Timing for a change of framing (the Z zoom). */
  zoom?: CssTiming;
}) {
  const stage = useStage();
  const { w: vw, h: vh } = prototype.manifest.viewports.desktop;
  const place = useMemo(() => placement(presentation, vw, vh), [presentation, vw, vh]);
  // Layout morphs inside the site measure against the framing it's zooming to.
  const getScale = useCallback(() => stage.getScale() * place.scale, [stage, place.scale]);
  const View = prototype.View;

  return (
    <div
      data-site-box=""
      className="absolute top-0 left-0"
      style={{
        width: vw,
        height: vh,
        transform: `translate(${place.x}px, ${place.y}px) scale(${place.scale})`,
        transformOrigin: "0 0",
        transition: zoom && cssTransition(["transform"], zoom),
      }}
    >
      <BrowserChrome
        visible={presentation === "browser"}
        height={BROWSER_CHROME / placement("browser", vw, vh).scale}
        transition={zoom && cssTransition(["opacity"], zoom)}
      />
      <div
        // The theme draws the framed site's edge for each tone from data-site-frame.
        data-site-frame={presentation}
        className="relative h-full w-full overflow-hidden bg-white"
        style={{
          // The containing block for the site's fixed overlays (booking sheet, curtain, end
          // card), so they cover the site frame, not the whole slide.
          contain: "layout paint",
          isolation: "isolate",
        }}
      >
        <ScaledSpace getScale={getScale}>
          <View session={session} instanceId={instanceId} layout="desktop" role="primary" input={DECK_INPUT} onHandle={onHandle} />
        </ScaledSpace>
      </div>
    </div>
  );
}

function BrowserChrome({ visible, height, transition }: { visible: boolean; height: number; transition?: string }) {
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-x-0 bottom-full flex items-center gap-2 bg-val-ink px-4"
      style={{ height, opacity: visible ? 1 : 0, transition }}
    >
      <span className="size-3 rounded-full bg-white/20" />
      <span className="size-3 rounded-full bg-white/20" />
      <span className="size-3 rounded-full bg-white/20" />
      <span className="ml-4 h-6 flex-1 bg-white/5 px-3 font-val-sans text-[13px] leading-6 text-white/50">bannerhealth.com</span>
    </div>
  );
}
