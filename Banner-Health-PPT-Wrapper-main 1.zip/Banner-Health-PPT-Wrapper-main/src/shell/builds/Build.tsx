"use client";

import { motion, type Variants } from "motion/react";
import { createContext, useContext } from "react";
import { deck as deckTokens, useTokens, type Resolved } from "@/motion";

// Keynote-style builds on brand slides. A slide's build index starts at 0 and each → reveals the
// next `<Build at={n}>`; at={0} pieces arrive with the slide itself. Going back hides the last
// build instantly (the deck settles before it steps back).

export const BuildContext = createContext(0);

type BuildStyle = Resolved<typeof deckTokens.tokens>["buildStyle"];

function variantsFor(style: BuildStyle, d: Resolved<typeof deckTokens.tokens>): Variants {
  switch (style) {
    case "fade":
      return { hidden: { opacity: 0 }, shown: { opacity: 1 } };
    case "blur-in":
      return { hidden: { opacity: 0, filter: `blur(${d.buildBlur * 2}px)` }, shown: { opacity: 1, filter: "blur(0px)" } };
    case "mask-rise":
      return { hidden: { y: "105%", opacity: 0 }, shown: { y: "0%", opacity: 1 } };
    case "scale-settle":
      return { hidden: { opacity: 0, scale: 0.96, y: d.buildRise / 2 }, shown: { opacity: 1, scale: 1, y: 0 } };
    default:
      return {
        hidden: { opacity: 0, y: d.buildRise, filter: `blur(${d.buildBlur}px)` },
        shown: { opacity: 1, y: 0, filter: "blur(0px)" },
      };
  }
}

export function Build({
  at = 0,
  order = 0,
  delay = 0,
  className,
  style,
  children,
}: {
  /** The → press that reveals this piece (0 = with the slide). */
  at?: number;
  /** Position within its build, for the stagger. */
  order?: number;
  /** Extra seconds before it starts. */
  delay?: number;
  className?: string;
  style?: React.CSSProperties;
  children: React.ReactNode;
}) {
  const build = useContext(BuildContext);
  const d = useTokens(deckTokens);
  const shown = build >= at;
  const variants = variantsFor(d.buildStyle, d);
  const motionEl = (
    <motion.div
      className={d.buildStyle === "mask-rise" ? undefined : className}
      style={d.buildStyle === "mask-rise" ? undefined : style}
      initial="hidden"
      animate={shown ? "shown" : "hidden"}
      variants={variants}
      transition={{ ...d.build, delay: shown ? delay + order * d.buildStagger : 0 }}
    >
      {children}
    </motion.div>
  );
  if (d.buildStyle !== "mask-rise") return motionEl;
  return (
    <div className={`overflow-hidden ${className ?? ""}`} style={style}>
      {motionEl}
    </div>
  );
}
