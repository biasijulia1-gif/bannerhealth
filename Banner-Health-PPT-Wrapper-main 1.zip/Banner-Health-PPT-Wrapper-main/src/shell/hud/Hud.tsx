"use client";

import { useDeck } from "../deck/DeckProvider";

/** Black or white screen (B / . and W / ,), drawn on the canvas so exports never include it. */
export function BlackLayer() {
  const { state } = useDeck();
  return (
    <div
      aria-hidden
      className="pointer-events-none absolute inset-0 z-[90]"
      style={{
        background: state.black === "white" ? "#fff" : "#000",
        opacity: state.black ? 1 : 0,
        transition: "opacity 250ms ease-out",
      }}
    />
  );
}

/** Window-space HUD: the "Go to 12_" jump buffer. Never part of the canvas or an export. */
export function Hud() {
  const { state, deck } = useDeck();
  if (!state.jump) return null;
  return (
    <div className="pointer-events-none fixed top-6 left-1/2 z-[300] -translate-x-1/2 bg-black/85 px-5 py-3 font-val-sans text-[15px] text-white">
      Go to {state.jump}
      <span className="animate-pulse">_</span>
      <span className="ml-3 text-white/50">of {deck.slides.length}</span>
    </div>
  );
}
