import type { ComponentType } from "react";
import type { Tone } from "./deck/schema";

// What a deck theme provides to the shell. The engine never imports a brand directly, so the
// next pitch can swap the Valtech frame for another without touching the shell.
//
// A theme also ships CSS. The shell puts data-tone="dark" | "light" on every slide and the theme
// draws that tone's ground and type from it, fading them when T flips the deck (the shell sets
// --deck-fade to the deck's fade timing). data-site-frame on a prototype's site box lets the theme
// draw the framed site's edge.

export type FrameProps = {
  /** The active slide's tone. */
  tone: Tone;
  visible: boolean;
  number: number;
  showNumber: boolean;
  band: boolean;
  label: string;
  /** CSS timing for fades, from the deck's motion tokens. */
  transition: string;
};

export type AnnotationProps = { text: string; visible: boolean; transition: string };

export type DeckTheme = {
  Frame: ComponentType<FrameProps>;
  Annotation: ComponentType<AnnotationProps>;
  letterbox: string;
};
