import { justSettled, motionStore, settle } from "@/motion";
import type { ShellEnv } from "./prototype/contract";

/** The services the shell hands every prototype session. */
export function createShellEnv(track?: ShellEnv["track"]): ShellEnv {
  return {
    settle,
    justSettled,
    timeScale: () => motionStore.timeScale(),
    track: track ?? (() => {}),
  };
}
