"use client";

import { createContext, useContext, useEffect, useId, useLayoutEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

// The admin's tooltips: a small "?" (or any element it wraps) that explains what a setting does.
// The tip renders on document.body with fixed positioning, so the scrolling panel never clips it,
// and it stays inside the dock's column, flipping above its trigger when there's no room below.

/** False while the dock is closed, so a tip can't linger after the panel slides away. */
export const TipsEnabled = createContext(true);

const OPEN_DELAY = 180;
const MAX_WIDTH = 300;
const GAP = 8;

export function Tip({ text, children }: { text?: string; children?: React.ReactNode }) {
  const enabled = useContext(TipsEnabled);
  const [open, setOpen] = useState(false);
  const anchor = useRef<HTMLSpanElement>(null);
  const tip = useRef<HTMLDivElement>(null);
  const timer = useRef(0);
  const id = useId();

  const show = () => {
    window.clearTimeout(timer.current);
    timer.current = window.setTimeout(() => setOpen(true), OPEN_DELAY);
  };
  const hide = () => {
    window.clearTimeout(timer.current);
    setOpen(false);
  };
  useEffect(() => () => window.clearTimeout(timer.current), []);

  // Place it once it has rendered (hidden), now that its height is known.
  useLayoutEffect(() => {
    const el = tip.current;
    const a = anchor.current?.getBoundingClientRect();
    if (!open || !el || !a) return;
    const dock = anchor.current?.closest("aside")?.getBoundingClientRect();
    const minX = (dock?.left ?? 0) + 12;
    const maxX = (dock?.right ?? window.innerWidth) - 12;
    const width = Math.min(MAX_WIDTH, maxX - minX);
    const left = Math.min(Math.max(a.left + a.width / 2 - width / 2, minX), maxX - width);
    el.style.width = `${width}px`;
    el.style.left = `${left}px`;
    const below = a.bottom + GAP;
    el.style.top = `${below + el.offsetHeight > window.innerHeight - GAP ? a.top - GAP - el.offsetHeight : below}px`;
    el.style.visibility = "visible";
  }, [open]);

  if (!text) return children ?? null;
  const visible = open && enabled;

  return (
    <>
      <span
        ref={anchor}
        className="inline-flex"
        onPointerEnter={show}
        onPointerLeave={hide}
        onFocus={show}
        onBlur={hide}
        aria-describedby={visible ? id : undefined}
      >
        {children ?? (
          <button
            type="button"
            aria-label={text}
            onClick={() => setOpen((o) => !o)}
            className="flex size-[15px] cursor-help items-center justify-center rounded-full border border-white/25 text-[9.5px] leading-none text-white/55 hover:border-[#20db9b]/70 hover:text-[#20db9b]"
          >
            ?
          </button>
        )}
      </span>
      {visible &&
        createPortal(
          <div
            ref={tip}
            id={id}
            role="tooltip"
            className="pointer-events-none fixed z-[500] rounded-md border border-white/12 bg-[#1a1e26] px-3 py-2 font-val-sans text-[12px] leading-[1.5] whitespace-pre-line text-white/85 shadow-[0_8px_24px_rgb(0_0_0/0.45)]"
            style={{ visibility: "hidden", top: 0, left: 0 }}
          >
            {text}
          </div>,
          document.body,
        )}
    </>
  );
}
