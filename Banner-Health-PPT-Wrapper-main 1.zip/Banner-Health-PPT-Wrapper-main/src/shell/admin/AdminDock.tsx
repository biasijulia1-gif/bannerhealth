"use client";

import { useEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { allGroups, curves, deck as deckTokens, cursor, global, LANGS, motionStore, onRegistryChange, useMotionDisplay, type Preset } from "@/motion";
import { useDeck } from "../deck/DeckProvider";
import { defaultLook, PRESENTATIONS, TONES } from "../deck/schema";
import { GroupSection, Row, SectionTitle, Segmented, Toggle } from "./controls";
import { setAdminLang, useAdminText } from "./i18n";
import { Tip, TipsEnabled } from "./Tip";

// The A-key motion panel (Julia's tool). It docks beside the stage, which shrinks so the whole
// slide stays visible while tuning. Edits apply live; Replay shows them; they persist in this
// browser and copy out as JSON. Every word switches between English and Portuguese (EN | PT in the
// header), and every section explains itself in a tooltip.

type Tab = "moment" | "global" | "deck" | "display";
const TABS = ["moment", "global", "deck", "display"] as const;

/** The deck's look: the same switches as T and Z. Not motion, so it stays out of the settings JSON. */
function LookSection() {
  const { api, state, deck } = useDeck();
  const { s } = useAdminText();
  const base = defaultLook(deck);
  const { tone, site } = state.look;
  return (
    <section className="border-b border-white/8 px-5 py-3">
      <SectionTitle label={s.look} help={s.lookTip} />
      <Row label={s.background} help={s.backgroundTip} dirty={tone !== base.tone} onReset={() => api.setLook({ tone: base.tone })}>
        <Segmented value={tone} options={TONES} labels={s.tones} onChange={(v) => api.setLook({ tone: v })} />
      </Row>
      <Row label={s.prototype} help={s.prototypeTip} dirty={site !== base.site} onReset={() => api.setLook({ site: base.site })}>
        <Segmented value={site} options={PRESENTATIONS} labels={s.sites} onChange={(v) => api.setLook({ site: v })} />
      </Row>
      <p className="py-1 text-[11.5px] leading-[1.5] text-white/40">{s.lookNote(`${s.tones[base.tone].label} · ${s.sites[base.site].label}`)}</p>
    </section>
  );
}

function useDirtyCount() {
  return useSyncExternalStore(motionStore.subscribe, motionStore.dirtyCount, motionStore.dirtyCount);
}

function useGroups() {
  const [groups, setGroups] = useState(allGroups);
  useEffect(() => onRegistryChange(() => setGroups(allGroups())), []);
  return groups;
}

function usePersistence(deckId: string) {
  useEffect(() => {
    const key = `motion:${deckId}:edits`;
    const displayKey = `motion:display`;
    try {
      const saved = JSON.parse(localStorage.getItem(key) ?? "null") as { values?: Preset["values"] } | null;
      if (saved?.values) motionStore.replaceValues(saved.values);
      const display = JSON.parse(localStorage.getItem(displayKey) ?? "null");
      if (display) motionStore.setDisplay({ reducedMotion: display.reducedMotion ?? "never", teamsSafe: !!display.teamsSafe });
    } catch {
      // Private windows and blocked storage just start from the committed defaults.
    }
    return motionStore.subscribe(() => {
      try {
        const { values, display } = motionStore.getState();
        localStorage.setItem(key, JSON.stringify({ values }));
        localStorage.setItem(displayKey, JSON.stringify({ reducedMotion: display.reducedMotion, teamsSafe: display.teamsSafe }));
      } catch {
        // Storage can be unavailable; edits still apply for this session.
      }
    });
  }, [deckId]);
}

const REDUCED = "(prefers-reduced-motion: reduce)";
const subscribeReduced = (cb: () => void) => {
  const mq = window.matchMedia(REDUCED);
  mq.addEventListener("change", cb);
  return () => mq.removeEventListener("change", cb);
};

function useOsReducedMotion() {
  return useSyncExternalStore(subscribeReduced, () => window.matchMedia(REDUCED).matches, () => false);
}

function Fps({ on }: { on: boolean }) {
  const { s } = useAdminText();
  const [fps, setFps] = useState(0);
  useEffect(() => {
    if (!on) return;
    let raf = 0;
    let frames = 0;
    let last = performance.now();
    const tick = (now: number) => {
      frames++;
      if (now - last >= 250) {
        setFps(Math.round((frames * 1000) / (now - last)));
        frames = 0;
        last = now;
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [on]);
  if (!on) return null;
  const color = fps >= 50 ? "text-[#20db9b]" : fps >= 40 ? "text-amber-300" : "text-red-400";
  return (
    <Tip text={s.fpsTip}>
      <span className={`tabular-nums ${color}`}>{s.fps(fps)}</span>
    </Tip>
  );
}

/** EN | PT, next to the fps readout. */
function LangSwitch() {
  const { lang, s } = useAdminText();
  return (
    <Tip text={s.langTip}>
      <span className="flex rounded bg-white/6 p-0.5" role="group" aria-label={s.langTip}>
        {LANGS.map((l) => (
          <button
            key={l}
            type="button"
            aria-pressed={l === lang}
            onClick={() => setAdminLang(l)}
            className={`rounded-[3px] px-1.5 py-px text-[10.5px] font-semibold tracking-[0.06em] uppercase ${l === lang ? "bg-[#20db9b] text-black" : "text-white/55 hover:text-white"}`}
          >
            {l}
          </button>
        ))}
      </span>
    </Tip>
  );
}

export function AdminDock({ open, width }: { open: boolean; width: number }) {
  const { api, state, deck, prototypes } = useDeck();
  const { s, moment } = useAdminText();
  const [tab, setTab] = useState<Tab>("moment");
  const [fpsOn, setFpsOn] = useState(true);
  const [copied, setCopied] = useState(false);
  const [importError, setImportError] = useState("");
  const display = useMotionDisplay();
  const dirty = useDirtyCount();
  const groups = useGroups();
  const osReduced = useOsReducedMotion();
  const fileInput = useRef<HTMLInputElement>(null);
  usePersistence(deck.id);

  const slide = deck.slides[state.index];
  // Moments depend on the active slide's controller, which registers after it renders.
  const momentsKey = useSyncExternalStore(api.subscribe, () => api.moments().join("|"), () => "");
  const moments = useMemo(() => (momentsKey ? momentsKey.split("|") : []), [momentsKey]);

  // Shortcuts while the panel is available: Shift+R replays the moment.
  useEffect(
    () =>
      api.registerKeys([
        {
          key: "r",
          shift: true,
          run: () => {
            const m = api.moments()[0];
            if (m) api.replayMoment(m);
          },
        },
      ]),
    [api],
  );

  const preset = (): Preset => ({
    schema: 1,
    id: `${deck.id}-${new Date().toISOString().slice(0, 16).replace(/[:T]/g, "")}`,
    name: `${deck.title} tuning`,
    updatedAt: new Date().toISOString(),
    basedOn: motionStore.getState().presetId,
    values: motionStore.getState().values,
  });

  const copyJson = async () => {
    await navigator.clipboard.writeText(JSON.stringify(preset(), null, 2));
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1500);
  };

  const exportFile = () => {
    const blob = new Blob([JSON.stringify(preset(), null, 2)], { type: "application/json" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `${preset().id}.json`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  const importFile = async (file: File) => {
    try {
      const parsed = JSON.parse(await file.text()) as Preset;
      if (!parsed?.values) throw new Error("no values");
      motionStore.replaceValues(parsed.values);
      setImportError("");
    } catch {
      setImportError(file.name);
    }
  };

  const momentTokens = (groupMoments: readonly string[] | undefined) => groupMoments?.some((m) => moments.includes(m)) ?? false;
  const momentLabel = (id: string) =>
    moment(id, (slide.type === "prototype" ? prototypes[slide.prototype]?.manifest.moments?.[id]?.label : undefined) ?? id);
  // The groups that own what's on screen come first; the deck's own groups last.
  const momentGroups = groups
    .filter((g) => g.id !== global.id && g.id !== curves.id)
    .map((g) => ({ g, rank: g.moments.some((m) => moments.includes(m) && !m.startsWith("deck.")) ? 0 : g.id === deckTokens.id ? 2 : 1 }))
    .sort((a, b) => a.rank - b.rank)
    .map(({ g }) => g);
  const stepLabel = state.pos.step ? ` · ${state.pos.step}` : state.pos.build !== undefined ? s.build(state.pos.build) : "";

  return (
    <TipsEnabled.Provider value={open}>
      <aside
        aria-label={s.aria}
        className="absolute inset-y-0 right-0 flex flex-col border-l border-white/10 bg-[#0d0f14] font-val-sans text-white"
        style={{ width, transform: open ? "translateX(0)" : `translateX(${width}px)`, transition: "transform 450ms cubic-bezier(0.22, 1, 0.36, 1)" }}
      >
        <header className="border-b border-white/10 px-5 pt-4 pb-3">
          <div className="flex items-center gap-2">
            <h2 className="text-[15px] font-semibold">{s.title}</h2>
            <span className="text-[11px] text-white/40">{s.closeHint}</span>
            <span className="flex-1" />
            <LangSwitch />
            <span className="text-[11px]">
              <Fps on={fpsOn && open} />
            </span>
          </div>
          <p className="mt-1 truncate text-[12px] text-white/55">
            {s.slide(state.index + 1, slide.title)}
            {stepLabel}
          </p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            {moments.map((m) => (
              <Tip key={m} text={s.replayMomentTip}>
                <button
                  type="button"
                  onClick={() => api.replayMoment(m)}
                  className="rounded-full border border-[#20db9b]/50 px-2.5 py-1 text-[11.5px] text-[#20db9b] hover:bg-[#20db9b]/10"
                >
                  ↻ {momentLabel(m)}
                </button>
              </Tip>
            ))}
            <Tip text={s.replaySlideTip}>
              <button type="button" onClick={() => api.replaySlide()} className="rounded-full border border-white/20 px-2.5 py-1 text-[11.5px] text-white/75 hover:bg-white/10">
                ↻ {s.slideChip}
              </button>
            </Tip>
          </div>
          {display.reducedMotion === "never" && osReduced && (
            <p className="mt-2.5 rounded bg-amber-400/15 px-2.5 py-1.5 text-[11.5px] text-amber-200">{s.reducedOverride}</p>
          )}
          {dirty > 0 && (
            <div className="mt-2.5 flex items-center gap-2 text-[11.5px] text-white/60">
              <span className="size-1.5 rounded-full bg-amber-300" />
              {s.changes(dirty)}
              <Tip text={s.revertAllTip}>
                <button type="button" onClick={() => motionStore.revertAll()} className="text-[#20db9b] hover:underline">
                  {s.revertAll}
                </button>
              </Tip>
            </div>
          )}
        </header>

        <nav className="flex border-b border-white/10 px-3 text-[12px]">
          {TABS.map((id) => (
            <Tip key={id} text={s.tabTips[id]}>
              <button
                type="button"
                onClick={() => setTab(id)}
                className={`border-b-2 px-2.5 py-2.5 ${tab === id ? "border-[#20db9b] text-white" : "border-transparent text-white/50 hover:text-white/80"}`}
              >
                {s.tabs[id]}
              </button>
            </Tip>
          ))}
        </nav>

        <div className="min-h-0 flex-1 overflow-y-auto">
          {tab === "moment" && (
            <>
              {momentGroups.map((g) => (
                <GroupSection key={g.id} group={g} filter={(t) => momentTokens(t.moments)} />
              ))}
              <p className="px-5 py-4 text-[11.5px] leading-[1.5] text-white/40">{s.momentNote}</p>
            </>
          )}
          {tab === "global" && (
            <>
              <GroupSection group={global} />
              <GroupSection group={curves} />
            </>
          )}
          {tab === "deck" && (
            <>
              <LookSection />
              <GroupSection group={deckTokens} />
              <GroupSection group={cursor} />
            </>
          )}
          {tab === "display" && (
            <section className="flex flex-col gap-3 px-5 py-4">
              <div>
                <div className="mb-1.5 flex items-center gap-2">
                  <p className="text-[12.5px] text-white/85">{s.reducedMotion}</p>
                  <Tip text={s.reducedMotionTip} />
                </div>
                <Segmented
                  value={display.reducedMotion}
                  options={["never", "user", "always"] as const}
                  labels={s.reducedOptions}
                  onChange={(v) => motionStore.setDisplay({ reducedMotion: v })}
                />
              </div>
              <Toggle on={display.teamsSafe} label={s.teamsSafe} help={s.teamsSafeTip} onChange={(v) => motionStore.setDisplay({ teamsSafe: v })} />
              <div>
                <div className="mb-1.5 flex items-center gap-2">
                  <p className="text-[12.5px] text-white/85">{s.slowmo}</p>
                  <Tip text={s.slowmoTip} />
                </div>
                <Segmented
                  value={String(display.slowmo)}
                  options={["1", "0.5", "0.25"] as const}
                  labels={{ "1": { label: "1×" }, "0.5": { label: "½×" }, "0.25": { label: "¼×" } }}
                  onChange={(v) => motionStore.setDisplay({ slowmo: Number(v) })}
                />
              </div>
              <Toggle on={fpsOn} label={s.fpsMeter} help={s.fpsMeterTip} onChange={setFpsOn} />
              <div className="mt-2 flex flex-wrap gap-2 border-t border-white/10 pt-4">
                <Tip text={s.copyTip}>
                  <button type="button" onClick={copyJson} className="rounded bg-[#20db9b] px-3 py-1.5 text-[12px] text-black">
                    {copied ? s.copied : s.copy}
                  </button>
                </Tip>
                <Tip text={s.exportTip}>
                  <button type="button" onClick={exportFile} className="rounded border border-white/20 px-3 py-1.5 text-[12px] text-white/80 hover:bg-white/10">
                    {s.exportFile}
                  </button>
                </Tip>
                <Tip text={s.importTip}>
                  <button
                    type="button"
                    onClick={() => fileInput.current?.click()}
                    className="rounded border border-white/20 px-3 py-1.5 text-[12px] text-white/80 hover:bg-white/10"
                  >
                    {s.importFile}
                  </button>
                </Tip>
                <input
                  ref={fileInput}
                  type="file"
                  accept="application/json"
                  className="hidden"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    if (f) void importFile(f);
                    e.target.value = "";
                  }}
                />
              </div>
              {importError && <p className="text-[11.5px] text-red-300">{s.importError(importError)}</p>}
              <p className="text-[11.5px] leading-[1.5] text-white/40">{s.settingsNote}</p>
            </section>
          )}
        </div>
      </aside>
    </TipsEnabled.Provider>
  );
}
