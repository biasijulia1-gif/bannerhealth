"use client";

import { useSyncExternalStore } from "react";
import { groupText, momentText, tokenText, type Lang, type TokenGroup } from "@/motion";

// The admin panel's own words, in English and Brazilian Portuguese (for Julia). Token and section
// names come from the motion registry (@/motion), which holds the same two languages. `pt` has to
// match `en` key for key, so a string added in English without its Portuguese fails the typecheck.

const en = {
  aria: "Motion admin",
  title: "Motion",
  closeHint: "A to close",
  langTip: "Panel language. Your choice is remembered in this browser.",
  fps: (n: number) => `${n} fps`,
  fpsTip: "Frames per second while the deck plays. 60 is smooth. Amber below 50 and red below 40 mean the motion is too heavy for this machine.",
  slide: (n: number, title: string) => `Slide ${n} · ${title}`,
  build: (n: number) => ` · build ${n}`,
  replayMomentTip: "Replays this moment from just before it starts, so you can see your change. Shift+R replays the first one.",
  slideChip: "Slide",
  replaySlideTip: "Replays the whole slide from its start, entrance included.",
  reducedOverride: "This computer has Reduce Motion on. The deck overrides it so the motion still plays.",
  changes: (n: number) => `${n} change${n === 1 ? "" : "s"} from the preset`,
  revertAll: "Revert all",
  revertAllTip: "Puts every setting back to the preset's value. This can't be undone.",
  tabs: { moment: "This moment", global: "Global", deck: "Deck", display: "Display" },
  tabTips: {
    moment: "Only the settings for what's on screen right now. Move through the deck and this tab follows.",
    global: "Settings that change every animation at once: speed, bounce, stagger and the shared curves.",
    deck: "The presentation itself: the look (dark or light, framed or filling the slide), slide transitions, builds and the zoom.",
    display: "How this browser shows the deck while you work. None of it is part of the settings you copy, apart from the buttons at the bottom.",
  },
  momentNote: "Showing the settings for what's on screen. Move through the deck to tune other moments, or open Global for the multipliers.",
  moments: { "deck.transition": "Slide transition", "deck.build": "Slide builds", "deck.zoom": "Zoom in/out (Z)" } as Record<string, string>,
  look: "Look",
  lookTip: "How the deck looks: the same switches as the T and Z keys. The look isn't a motion setting, so it isn't in the settings you copy.",
  background: "Background",
  backgroundTip: "The dark or light version of the deck. Contrast slides stay the opposite color. T switches it while presenting.",
  tones: { dark: { label: "Dark" }, light: { label: "Light" } },
  prototype: "Prototype",
  prototypeTip: "How prototype slides show the live site: framed 1:1 inside the Valtech frame, in a browser window, or filling the whole slide. Z zooms between this and Fill slide while presenting.",
  sites: {
    framed: { label: "Framed", hint: "1:1 inside the Valtech frame" },
    browser: { label: "Browser", hint: "In a browser window" },
    fullbleed: { label: "Fill slide", hint: "The site fills the whole slide" },
  },
  lookNote: (look: string) => `The deck opens on ${look} (deck.config.ts). The address bar carries any change, so a reload or a copied link keeps it.`,
  reducedMotion: "Reduced motion",
  reducedMotionTip: "What to do when this computer has the system's Reduce Motion setting on. Force full motion (the default) makes sure the motion always plays when presenting.",
  reducedOptions: { never: { label: "Force full motion" }, user: { label: "Follow the OS" }, always: { label: "Reduce" } },
  teamsSafe: "Teams-safe (stronger edges, lighter blur, decisive moves)",
  teamsSafeTip: "For sharing the screen in Teams, which washes out edges and drops frames: stronger card edges, lighter blur and shorter long fades. Only affects this browser.",
  slowmo: "Slow motion",
  slowmoTip: "Plays everything at half or quarter speed so you can study a move. Only affects this browser and isn't saved in the settings.",
  fpsMeter: "Frame rate meter",
  fpsMeterTip: "Shows frames per second at the top of the panel. Turn it off if it distracts you.",
  copy: "Copy settings (JSON)",
  copied: "Copied",
  copyTip: "Copies all your motion settings as text. Paste them to Trey in Teams or an email.",
  exportFile: "Export file",
  exportTip: "Downloads your settings as a .json file to send or keep.",
  importFile: "Import file",
  importTip: "Loads settings from a .json file someone sent you. It replaces your current settings.",
  importError: (name: string) => `“${name}” isn't a motion preset.`,
  settingsNote: "Settings save in this browser automatically. Copy them to send to Trey, or export a file to commit as the default.",
  reset: "reset",
  resetTip: "Back to the preset's value",
  linkedCurve: (name: string) => `Linked curve: ${name}`,
  ownSpring: "Own spring",
  ownTween: "Own tween (duration + ease)",
  linkedNote: (d: number, b: number) => `${d}s · bounce ${b} (edit it under Global → Shared curves; everything linked to it follows)`,
  duration: "Duration",
  bounce: "Bounce (elasticity)",
  ease: "Ease in / out",
  customBezier: "Custom bezier",
  overshoot: (n: number) => `overshoot ${n}%`,
  wobbles: (n: number) => `wobbles ${n}×`,
  tooPlayful: (n: number) => `wobbles ${n}× (too playful?)`,
  more: (n: number) => `+ More (${n})`,
  fewer: "− Fewer",
};

const pt: typeof en = {
  aria: "Painel de movimento",
  title: "Movimento",
  closeHint: "A para fechar",
  langTip: "Idioma do painel. Sua escolha fica salva neste navegador.",
  fps: (n) => `${n} fps`,
  fpsTip: "Quadros por segundo enquanto o deck roda. 60 é fluido. Âmbar abaixo de 50 e vermelho abaixo de 40 indicam que a animação está pesada demais para esta máquina.",
  slide: (n, title) => `Slide ${n} · ${title}`,
  build: (n) => ` · build ${n}`,
  replayMomentTip: "Repete este momento a partir de um pouco antes do início, para você ver a mudança. Shift+R repete o primeiro.",
  slideChip: "Slide",
  replaySlideTip: "Repete o slide inteiro desde o início, com a entrada.",
  reducedOverride: "Este computador está com Reduzir movimento ativado. O deck ignora essa opção para que as animações continuem rodando.",
  changes: (n) => (n === 1 ? "1 alteração em relação ao preset" : `${n} alterações em relação ao preset`),
  revertAll: "Restaurar tudo",
  revertAllTip: "Volta todas as configurações para o valor do preset. Não dá para desfazer.",
  tabs: { moment: "Este momento", global: "Global", deck: "Deck", display: "Exibição" },
  tabTips: {
    moment: "Só as configurações do que está na tela agora. Avance pelo deck e esta aba acompanha.",
    global: "Configurações que mudam todas as animações de uma vez: velocidade, bounce, stagger e as curvas compartilhadas.",
    deck: "A apresentação em si: o visual (escuro ou claro, emoldurado ou preenchendo o slide), as transições de slide, os builds e o zoom.",
    display: "Como este navegador mostra o deck enquanto você trabalha. Nada disso entra nas configurações que você copia, exceto os botões no fim.",
  },
  momentNote: "Mostrando as configurações do que está na tela. Avance pelo deck para ajustar outros momentos, ou abra Global para os multiplicadores.",
  moments: { "deck.transition": "Transição de slide", "deck.build": "Builds do slide", "deck.zoom": "Zoom in/out (Z)" },
  look: "Visual",
  lookTip: "Como o deck aparece: são os mesmos controles das teclas T e Z. O visual não é uma configuração de movimento, então não entra nas configurações que você copia.",
  background: "Fundo",
  backgroundTip: "A versão escura ou clara do deck. Os slides de contraste ficam na cor oposta. A tecla T troca durante a apresentação.",
  tones: { dark: { label: "Escuro" }, light: { label: "Claro" } },
  prototype: "Protótipo",
  prototypeTip: "Como os slides de protótipo mostram o site ao vivo: emoldurado em 1:1 dentro da moldura da Valtech, numa janela de navegador, ou preenchendo o slide inteiro. A tecla Z alterna entre esta opção e Preencher o slide durante a apresentação.",
  sites: {
    framed: { label: "Emoldurado", hint: "1:1 dentro da moldura da Valtech" },
    browser: { label: "Navegador", hint: "Numa janela de navegador" },
    fullbleed: { label: "Preencher o slide", hint: "O site ocupa o slide inteiro" },
  },
  lookNote: (look) => `O deck abre em ${look} (deck.config.ts). A barra de endereço guarda qualquer mudança, então recarregar a página ou copiar o link mantém o visual.`,
  reducedMotion: "Movimento reduzido",
  reducedMotionTip: "O que fazer quando este computador está com a opção Reduzir movimento do sistema ativada. Forçar movimento total (o padrão) garante que as animações sempre rodem na apresentação.",
  reducedOptions: { never: { label: "Forçar movimento total" }, user: { label: "Seguir o sistema" }, always: { label: "Reduzir" } },
  teamsSafe: "Seguro para Teams (bordas mais fortes, menos blur, movimentos decididos)",
  teamsSafeTip: "Para compartilhar a tela no Teams, que apaga as bordas e perde quadros: bordas de card mais fortes, blur mais leve e fades longos mais curtos. Só vale para este navegador.",
  slowmo: "Câmera lenta",
  slowmoTip: "Roda tudo na metade ou a um quarto da velocidade, para você estudar um movimento. Só vale para este navegador e não é salvo nas configurações.",
  fpsMeter: "Medidor de quadros por segundo",
  fpsMeterTip: "Mostra os quadros por segundo no topo do painel. Desligue se atrapalhar.",
  copy: "Copiar configurações (JSON)",
  copied: "Copiado",
  copyTip: "Copia todas as suas configurações de movimento como texto. Cole para o Trey no Teams ou num e-mail.",
  exportFile: "Exportar arquivo",
  exportTip: "Baixa suas configurações num arquivo .json para enviar ou guardar.",
  importFile: "Importar arquivo",
  importTip: "Carrega as configurações de um arquivo .json que alguém te enviou. Substitui as suas configurações atuais.",
  importError: (name) => `“${name}” não é um preset de movimento.`,
  settingsNote: "As configurações ficam salvas neste navegador automaticamente. Copie para enviar ao Trey, ou exporte um arquivo para virar o padrão.",
  reset: "redefinir",
  resetTip: "Voltar ao valor do preset",
  linkedCurve: (name) => `Curva vinculada: ${name}`,
  ownSpring: "Spring próprio",
  ownTween: "Tween próprio (duração + ease)",
  linkedNote: (d, b) => `${d}s · bounce ${b} (edite em Global → Curvas compartilhadas; tudo o que está vinculado a ela acompanha)`,
  duration: "Duração",
  bounce: "Bounce (elasticidade)",
  ease: "Ease (entrada / saída)",
  customBezier: "Bezier personalizada",
  overshoot: (n) => `overshoot ${n}%`,
  wobbles: (n) => `oscila ${n}×`,
  tooPlayful: (n) => `oscila ${n}× (brincalhão demais?)`,
  more: (n) => `+ Mais (${n})`,
  fewer: "− Menos",
};

export const STRINGS: Record<Lang, typeof en> = { en, pt };

// The panel's language: the browser's language until someone picks one, then remembered here.
const KEY = "admin:lang";
const listeners = new Set<() => void>();
let current: Lang | null = null;

function readLang(): Lang {
  if (current) return current;
  try {
    const saved = localStorage.getItem(KEY);
    if (saved === "en" || saved === "pt") return (current = saved);
  } catch {
    // Blocked storage: fall through to the browser's language.
  }
  current = navigator.language.toLowerCase().startsWith("pt") ? "pt" : "en";
  return current;
}

export function setAdminLang(lang: Lang) {
  current = lang;
  try {
    localStorage.setItem(KEY, lang);
  } catch {
    // Still switches for this session.
  }
  listeners.forEach((l) => l());
}

const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => {
    listeners.delete(l);
  };
};

/** The panel's words in its current language, plus token, section and moment names from the registry. */
export function useAdminText() {
  const lang = useSyncExternalStore(subscribe, readLang, () => "en" as Lang);
  return {
    lang,
    s: STRINGS[lang],
    group: (g: TokenGroup) => groupText(g, lang),
    token: (g: TokenGroup, key: string) => tokenText(g, key, lang),
    moment: (id: string, fallback: string) => momentText(id, lang, STRINGS[lang].moments[id] ?? fallback),
  };
}
