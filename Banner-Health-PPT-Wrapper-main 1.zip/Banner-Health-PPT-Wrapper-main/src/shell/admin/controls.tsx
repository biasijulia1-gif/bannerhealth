"use client";

import { spring as springGenerator } from "motion/react";
import { useMemo, useState, useSyncExternalStore } from "react";
import {
  curves,
  motionStore,
  type Bezier,
  type MotionSpec,
  type MotionToken,
  type NumberToken,
  type RawValue,
  type Token,
  type TokenGroup,
} from "@/motion";
import { useAdminText } from "./i18n";
import { Tip } from "./Tip";

// Admin controls, one per token kind. They read and write raw token values in the motion store;
// components re-render with the resolved values and Replay shows the change. Labels, help and
// option names come in the panel's language (useAdminText).

function useRaw(groupId: string, key: string): RawValue | undefined {
  const get = () => motionStore.raw(groupId, key);
  return useSyncExternalStore(motionStore.subscribe, get, get);
}

const same = (a: unknown, b: unknown) => JSON.stringify(a) === JSON.stringify(b);

export function Row({
  label,
  help,
  dirty,
  onReset,
  children,
}: {
  label: string;
  help?: string;
  dirty: boolean;
  onReset(): void;
  children: React.ReactNode;
}) {
  const { s } = useAdminText();
  return (
    <div className="flex flex-col gap-1.5 py-2">
      <div className="flex items-center gap-2">
        <span className="text-[12.5px] text-white/85">{label}</span>
        <Tip text={help} />
        <span className="flex-1" />
        {dirty && (
          <button type="button" onClick={onReset} title={s.resetTip} className="text-[11px] text-[#20db9b] hover:underline">
            {s.reset}
          </button>
        )}
      </div>
      {children}
    </div>
  );
}

function fmt(v: number, unit?: string) {
  const n = Math.abs(v) >= 10 ? v.toFixed(0) : Math.abs(v) >= 1 ? v.toFixed(2) : v.toFixed(3);
  const clean = String(Number(n));
  if (unit === "s") return `${clean}s · ${Math.round(v * 60)}f`;
  return unit ? `${clean}${unit === "×" ? "×" : unit}` : clean;
}

export function NumberSlider({
  value,
  min,
  max,
  step,
  unit,
  onChange,
}: {
  value: number;
  min: number;
  max: number;
  step: number;
  unit?: string;
  onChange(v: number): void;
}) {
  return (
    <div className="flex items-center gap-3">
      <input
        type="range"
        min={min}
        max={max}
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="h-1 flex-1 cursor-pointer accent-[#20db9b]"
      />
      <input
        type="number"
        min={min}
        max={max}
        step={step}
        value={Number(value.toFixed(4))}
        onChange={(e) => e.target.value !== "" && onChange(Number(e.target.value))}
        className="w-[64px] rounded bg-white/8 px-1.5 py-0.5 text-right text-[12px] text-white tabular-nums outline-none focus:bg-white/15"
      />
      <span className="w-[54px] text-[11px] text-white/40 tabular-nums">{fmt(value, unit).replace(/^[\d.-]+/, "") || ""}</span>
    </div>
  );
}

export function Segmented<T extends string>({
  value,
  options,
  labels,
  onChange,
}: {
  value: T;
  options: readonly T[];
  labels?: Partial<Record<T, { label: string; hint?: string }>>;
  onChange(v: T): void;
}) {
  return (
    <div className="flex flex-wrap gap-1 rounded-md bg-white/6 p-1">
      {options.map((o) => (
        <button
          key={o}
          type="button"
          title={labels?.[o]?.hint}
          onClick={() => onChange(o)}
          className={`rounded px-2.5 py-1 text-[12px] transition-colors ${o === value ? "bg-[#20db9b] text-black" : "text-white/70 hover:bg-white/10"}`}
        >
          {labels?.[o]?.label ?? o}
        </button>
      ))}
    </div>
  );
}

export function Toggle({ on, onChange, label, help }: { on: boolean; onChange(v: boolean): void; label: string; help?: string }) {
  return (
    <div className="flex items-center justify-between gap-3 py-1.5 text-[12.5px] text-white/85">
      <span className="flex items-center gap-2">
        <span className="cursor-pointer" onClick={() => onChange(!on)}>
          {label}
        </span>
        <Tip text={help} />
      </span>
      <button
        type="button"
        role="switch"
        aria-checked={on}
        aria-label={label}
        onClick={() => onChange(!on)}
        className={`relative h-5 w-9 shrink-0 rounded-full transition-colors ${on ? "bg-[#20db9b]" : "bg-white/15"}`}
      >
        <span className={`absolute top-0.5 left-0 size-4 rounded-full bg-white transition-transform ${on ? "translate-x-[18px]" : "translate-x-0.5"}`} />
      </button>
    </div>
  );
}

/** The real curve a spring will play, from Motion's own spring math. */
function SpringCurve({ visualDuration, bounce }: { visualDuration: number; bounce: number }) {
  const { s } = useAdminText();
  const { path, overshoot, wobbles } = useMemo(() => {
    const gen = springGenerator({ keyframes: [0, 1], visualDuration, bounce });
    const total = Math.min(4000, visualDuration * 1000 * 2.2);
    const pts: string[] = [];
    let max = 0;
    let crossings = 0;
    let prevAbove = false;
    for (let i = 0; i <= 60; i++) {
      const t = (i / 60) * total;
      const v = gen.next(t).value as number;
      max = Math.max(max, v);
      const above = v > 1.005;
      if (above && !prevAbove) crossings++;
      prevAbove = above;
      pts.push(`${(i / 60) * 140},${44 - v * 30}`);
    }
    return { path: `M${pts.join(" L")}`, overshoot: Math.max(0, max - 1), wobbles: crossings };
  }, [visualDuration, bounce]);
  return (
    <div className="flex items-center gap-3">
      <svg width="140" height="50" className="shrink-0 overflow-visible">
        <line x1="0" x2="140" y1="14" y2="14" stroke="rgb(255 255 255 / 0.12)" strokeDasharray="2 3" />
        <path d={path} fill="none" stroke="#20db9b" strokeWidth="1.5" />
      </svg>
      <div className="text-[11px] leading-[1.5] text-white/45">
        {s.overshoot(Math.round(overshoot * 100))}
        <br />
        {wobbles > 1 ? <span className="text-amber-300">{s.tooPlayful(wobbles)}</span> : s.wobbles(wobbles)}
      </div>
    </div>
  );
}

const easeNames = () => Object.entries(curves.tokens).filter(([, t]) => t.kind === "ease").map(([k]) => k);
const springNames = () => Object.entries(curves.tokens).filter(([, t]) => t.kind === "motion").map(([k]) => k);

function MotionControl({ group, k }: { group: TokenGroup; k: string }) {
  const { s, token } = useAdminText();
  const tok = group.tokens[k] as MotionToken;
  const text = token(group, k);
  const raw = (useRaw(group.id, k) ?? tok.default) as MotionSpec;
  const base = (motionStore.baselineRaw(group.id, k) ?? tok.default) as MotionSpec;
  const set = (v: MotionSpec) => motionStore.set(group.id, k, v);
  const linked = "ref" in raw;
  const env = motionStore.env();
  const concrete = "ref" in raw ? (env.springs[raw.ref] ?? { type: "spring" as const, visualDuration: 0.5, bounce: 0.1 }) : raw;
  const mode = linked ? `ref:${raw.ref}` : concrete.type;
  const modes = [...springNames().map((n) => `ref:${n}`), "spring", "tween"];
  const curveLabel = (name: string) => (name in curves.tokens ? token(curves, name).label : name);

  return (
    <Row label={text.label} help={text.help} dirty={!same(raw, base)} onReset={() => motionStore.revertToken(group.id, k)}>
      <select
        value={mode}
        onChange={(e) => {
          const v = e.target.value;
          if (v.startsWith("ref:")) set({ ref: v.slice(4) });
          else if (v === "spring") set({ type: "spring", visualDuration: "visualDuration" in concrete ? concrete.visualDuration : concrete.duration, bounce: "bounce" in concrete ? concrete.bounce : 0.1 });
          else set({ type: "tween", duration: "duration" in concrete ? concrete.duration : concrete.visualDuration, ease: "ease" in concrete ? concrete.ease : "outExpo" });
        }}
        className="rounded bg-white/8 px-2 py-1 text-[12px] text-white outline-none"
      >
        {modes.map((m) => (
          <option key={m} value={m} className="bg-[#14171d]">
            {m.startsWith("ref:") ? s.linkedCurve(curveLabel(m.slice(4))) : m === "spring" ? s.ownSpring : s.ownTween}
          </option>
        ))}
      </select>
      {linked && concrete.type === "spring" && <div className="text-[11px] text-white/40">{s.linkedNote(concrete.visualDuration, concrete.bounce)}</div>}
      {!linked && concrete.type === "spring" && (
        <>
          <span className="text-[11px] text-white/45">{s.duration}</span>
          <NumberSlider value={concrete.visualDuration} min={0.05} max={3} step={0.01} unit="s" onChange={(v) => set({ ...concrete, visualDuration: v })} />
          <span className="text-[11px] text-white/45">{s.bounce}</span>
          <NumberSlider value={concrete.bounce} min={0} max={0.6} step={0.01} onChange={(v) => set({ ...concrete, bounce: v })} />
        </>
      )}
      {concrete.type === "spring" && <SpringCurve visualDuration={concrete.visualDuration} bounce={Math.min(concrete.bounce * env.elasticity, env.maxBounce)} />}
      {!linked && concrete.type === "tween" && (
        <>
          <span className="text-[11px] text-white/45">{s.duration}</span>
          <NumberSlider value={concrete.duration} min={0.05} max={8} step={0.01} unit="s" onChange={(v) => set({ ...concrete, duration: v })} />
          <span className="text-[11px] text-white/45">{s.ease}</span>
          <select
            value={typeof concrete.ease === "string" ? concrete.ease : "custom"}
            onChange={(e) => set({ ...concrete, ease: e.target.value })}
            className="rounded bg-white/8 px-2 py-1 text-[12px] text-white outline-none"
          >
            {easeNames().map((n) => (
              <option key={n} value={n} className="bg-[#14171d]">
                {curveLabel(n)}
              </option>
            ))}
            {typeof concrete.ease !== "string" && (
              <option value="custom" className="bg-[#14171d]">
                {s.customBezier}
              </option>
            )}
          </select>
        </>
      )}
    </Row>
  );
}

function BezierFields({ group, k }: { group: TokenGroup; k: string }) {
  const { token } = useAdminText();
  const tok = group.tokens[k];
  const text = token(group, k);
  const raw = (useRaw(group.id, k) ?? tok.default) as Bezier;
  const base = (motionStore.baselineRaw(group.id, k) ?? tok.default) as Bezier;
  return (
    <Row label={text.label} help={text.help} dirty={!same(raw, base)} onReset={() => motionStore.revertToken(group.id, k)}>
      <div className="flex gap-1.5">
        {raw.map((v, i) => (
          <input
            key={i}
            type="number"
            step={0.01}
            value={v}
            onChange={(e) => {
              const next = [...raw] as [number, number, number, number];
              next[i] = Number(e.target.value);
              motionStore.set(group.id, k, next);
            }}
            className="w-full rounded bg-white/8 px-1.5 py-0.5 text-right text-[12px] text-white tabular-nums outline-none"
          />
        ))}
      </div>
    </Row>
  );
}

export function TokenControl({ group, k, tok }: { group: TokenGroup; k: string; tok: Token }) {
  const { token } = useAdminText();
  const text = token(group, k);
  const raw = useRaw(group.id, k) ?? tok.default;
  const base = motionStore.baselineRaw(group.id, k) ?? tok.default;
  const reset = () => motionStore.revertToken(group.id, k);
  switch (tok.kind) {
    case "motion":
      return <MotionControl group={group} k={k} />;
    case "ease":
      return <BezierFields group={group} k={k} />;
    case "number": {
      const t = tok as NumberToken;
      return (
        <Row label={text.label} help={text.help} dirty={!same(raw, base)} onReset={reset}>
          <NumberSlider value={raw as number} min={t.min} max={t.max} step={t.step} unit={t.unit} onChange={(v) => motionStore.set(group.id, k, v)} />
        </Row>
      );
    }
    case "enum":
      return (
        <Row label={text.label} help={text.help} dirty={!same(raw, base)} onReset={reset}>
          <Segmented value={raw as string} options={tok.options} labels={text.options} onChange={(v) => motionStore.set(group.id, k, v)} />
        </Row>
      );
    case "bool":
      return <Toggle on={raw as boolean} label={text.label} help={text.help} onChange={(v) => motionStore.set(group.id, k, v)} />;
    default:
      return null;
  }
}

/** Is a token relevant right now (its `when` condition holds)? */
export function useVisible(group: TokenGroup, tok: Token): boolean {
  const key = tok.when?.key ?? "";
  const raw = useRaw(group.id, key);
  if (!tok.when) return true;
  const is = tok.when.is;
  return Array.isArray(is) ? is.includes(raw as string) : raw === is;
}

/** A section title with its tooltip. */
export function SectionTitle({ label, help }: { label: string; help?: string }) {
  return (
    <div className="mb-1 flex items-center gap-2">
      <h3 className="text-[11px] tracking-[0.12em] text-white/45 uppercase">{label}</h3>
      <Tip text={help} />
    </div>
  );
}

export function GroupSection({ group, filter }: { group: TokenGroup; filter?: (tok: Token) => boolean }) {
  const { s, group: groupText } = useAdminText();
  const [more, setMore] = useState(false);
  const entries = (Object.entries(group.tokens) as [string, Token][]).filter(([, t]) => (filter ? filter(t) : true));
  const basic = entries.filter(([, t]) => t.tier !== "advanced");
  const advanced = entries.filter(([, t]) => t.tier === "advanced");
  if (!entries.length) return null;
  const title = groupText(group);
  return (
    <section className="border-b border-white/8 px-5 py-3">
      <SectionTitle label={title.label} help={title.help} />
      {basic.map(([k, t]) => (
        <Visible key={k} group={group} k={k} tok={t} />
      ))}
      {advanced.length > 0 && (
        <>
          <button type="button" onClick={() => setMore((m) => !m)} className="mt-1 text-[11.5px] text-white/45 hover:text-white/80">
            {more ? s.fewer : s.more(advanced.length)}
          </button>
          {more && advanced.map(([k, t]) => <Visible key={k} group={group} k={k} tok={t} />)}
        </>
      )}
    </section>
  );
}

function Visible({ group, k, tok }: { group: TokenGroup; k: string; tok: Token }) {
  return useVisible(group, tok) ? <TokenControl group={group} k={k} tok={tok} /> : null;
}
