"use client";

import { createContext, useCallback, useContext, useEffect, useLayoutEffect, useMemo, useReducer, useRef, useState } from "react";
import { settle } from "@/motion";
import type { InProcessPrototype } from "../prototype/contract";
import { openPresenterWindow } from "../presenter/open";
import { useAudienceLink } from "../presenter/useAudienceLink";
import type { DeckTheme } from "../theme";
import type { DeckConfig, Look, SlideConfig } from "./schema";
import { deckReducer, initialDeckState, type DeckState, type SlidePos } from "./machine";
import { deckSequence, endPos, readDeckUrl, startPos, validPos, writeDeckUrl, type DeckFlags } from "./url";
import { useDeckKeys, type DeckKeyActions, type KeyBinding } from "./keys";

// Deck state and navigation. The active slide registers a controller; → and ← ask it first
// (builds, journey steps) and move between slides only when it has nothing left.

export type SlideController = {
  next(): boolean;
  prev(): boolean;
  isBusy(): boolean;
  finish(): void;
  idle(): Promise<void>;
  /** Moments playing at the current position (for the admin's "This moment" tab). */
  moments?(): string[];
  /** Replays a moment in place. False when this slide doesn't own it. */
  replayMoment?(id: string): boolean;
};

export type DeckSnapshot = {
  deckId: string;
  index: number;
  count: number;
  slideId: string;
  slideType: SlideConfig["type"];
  title: string;
  pos: SlidePos;
  black: DeckState["black"];
  notes: boolean;
  admin: boolean;
  look: Look;
};

export type DeckApi = {
  snapshot(): DeckSnapshot;
  subscribe(listener: () => void): () => void;
  next(): void;
  prev(): void;
  goTo(slide: number | string, pos?: SlidePos, opts?: { instant?: boolean }): void;
  /** Remount the active slide from its start, with its entrance (Replay slide). */
  replaySlide(): void;
  /** Land on the previous slide's end, then play the transition into this one again. */
  replayTransition(): void;
  /** Moments playing right now, deck-level ones included. */
  moments(): string[];
  replayMoment(id: string): void;
  /** Every position → walks through, in order (for the smoke test and exports). */
  sequence(): Array<{ index: number; slideId: string } & SlidePos>;
  isBusy(): boolean;
  idle(): Promise<void>;
  toggleAdmin(open?: boolean): void;
  /** Tone and site framing, the same switches as T and Z. */
  setLook(look: Partial<Look>): void;
  registerKeys(bindings: KeyBinding[]): () => void;
};

type DeckContextValue = {
  deck: DeckConfig;
  state: DeckState;
  slide: SlideConfig;
  flags: DeckFlags;
  prototypes: Record<string, InProcessPrototype>;
  theme: DeckTheme;
  stepsOf: (prototype: string) => readonly string[];
  api: DeckApi;
  /** Slides report their inner position (current build or step). */
  reportPos(pos: SlidePos): void;
  /** The active slide's controller. Returns an unregister that only clears its own registration. */
  registerController(c: SlideController): () => void;
  adminAvailable: boolean;
};

const DeckContext = createContext<DeckContextValue | null>(null);

export function useDeck() {
  const ctx = useContext(DeckContext);
  if (!ctx) throw new Error("useDeck must be used inside <DeckProvider>");
  return ctx;
}

const ADMIN_MODE = process.env.NEXT_PUBLIC_ADMIN ?? "flag";
/** T stays out of the client build, so the client only ever sees the committed version. */
const TONE_KEY = ADMIN_MODE !== "off";

export function DeckProvider({
  deck,
  prototypes,
  theme,
  children,
}: {
  deck: DeckConfig;
  prototypes: Record<string, InProcessPrototype>;
  theme: DeckTheme;
  children: React.ReactNode;
}) {
  const stepsOf = useCallback((id: string) => prototypes[id]?.manifest.steps ?? [], [prototypes]);
  const [boot] = useState(() => readDeckUrl(deck, stepsOf));
  const [state, dispatch] = useReducer(deckReducer, initialDeckState(boot.index, boot.pos, boot.look));
  const stateRef = useRef(state);
  useLayoutEffect(() => {
    stateRef.current = state;
  }, [state]);
  const controller = useRef<SlideController | null>(null);
  const bindings = useRef<KeyBinding[]>([]);
  const listeners = useRef(new Set<() => void>());

  const adminAvailable = useMemo(() => {
    if (boot.flags.export || ADMIN_MODE === "off") return false;
    if (ADMIN_MODE === "on") return true;
    try {
      if (boot.flags.admin) sessionStorage.setItem("deck:admin", "1");
      return sessionStorage.getItem("deck:admin") === "1";
    } catch {
      return boot.flags.admin;
    }
  }, [boot.flags]);

  useEffect(() => {
    writeDeckUrl(deck, state.index, state.pos, state.look);
    listeners.current.forEach((l) => l());
  }, [deck, state]);

  const goTo = useCallback(
    (target: number | string, pos?: SlidePos, opts?: { instant?: boolean; dir?: 1 | -1 }) => {
      const index = typeof target === "number" ? target : deck.slides.findIndex((s) => s.id === target);
      if (index < 0 || index >= deck.slides.length) return;
      const slide = deck.slides[index];
      const landing = validPos(slide, pos, stepsOf);
      const dir = opts?.dir ?? (index >= stateRef.current.index ? 1 : -1);
      const instant = opts?.instant ?? false;
      // Landing anywhere but a slide's natural start (going back, deep links, mid-journey slides)
      // settles its contents immediately; the slide change itself is a CSS transition, so it
      // still plays.
      const midway = slide.type === "prototype" ? landing.step !== slide.from || slide.entry === "settled" : (landing.build ?? 0) > 0;
      if (instant || midway) void settle(4);
      dispatch({ type: "go", index, pos: landing, dir, instant });
    },
    [deck, stepsOf],
  );

  const next = useCallback(() => {
    const s = stateRef.current;
    if (s.black) return dispatch({ type: "black", value: false });
    if (controller.current?.next()) return;
    if (s.index < deck.slides.length - 1) goTo(s.index + 1, startPos(deck.slides[s.index + 1]), { dir: 1 });
  }, [deck, goTo]);

  const prev = useCallback(() => {
    const s = stateRef.current;
    if (s.black) return dispatch({ type: "black", value: false });
    if (controller.current?.prev()) return;
    if (s.index > 0) goTo(s.index - 1, endPos(deck.slides[s.index - 1]), { dir: -1, instant: true });
  }, [deck, goTo]);

  // Z acts only where the change shows: a prototype slide that doesn't pin its own framing.
  const zoom = useCallback(() => {
    const slide = deck.slides[stateRef.current.index];
    if (slide.type === "prototype" && !slide.presentation) dispatch({ type: "site" });
  }, [deck]);

  const api = useMemo<DeckApi>(() => {
    const snapshot = (): DeckSnapshot => {
      const s = stateRef.current;
      const slide = deck.slides[s.index];
      return {
        deckId: deck.id,
        index: s.index,
        count: deck.slides.length,
        slideId: slide.id,
        slideType: slide.type,
        title: slide.title,
        pos: s.pos,
        black: s.black,
        notes: s.notes,
        admin: s.admin,
        look: s.look,
      };
    };
    const self: DeckApi = {
      snapshot,
      subscribe(listener) {
        listeners.current.add(listener);
        return () => {
          listeners.current.delete(listener);
        };
      },
      next,
      prev,
      goTo: (slide, pos, opts) => goTo(slide, pos, { instant: opts?.instant ?? true }),
      replaySlide: () => dispatch({ type: "replay", pos: startPos(deck.slides[stateRef.current.index]) }),
      replayTransition() {
        const i = stateRef.current.index;
        if (i === 0) return;
        goTo(i - 1, endPos(deck.slides[i - 1]), { instant: true });
        requestAnimationFrame(() => requestAnimationFrame(() => requestAnimationFrame(() => goTo(i, startPos(deck.slides[i]), { dir: 1 }))));
      },
      moments() {
        const slide = deck.slides[stateRef.current.index];
        const own = controller.current?.moments?.() ?? [];
        const deckOwn = slide.type === "brand" ? "deck.build" : slide.presentation ? null : "deck.zoom";
        return [...own, deckOwn, "deck.transition"].filter((m): m is string => !!m);
      },
      replayMoment(id) {
        if (id === "deck.transition") return self.replayTransition();
        if (id === "deck.zoom") return zoom();
        if (id === "deck.build") return dispatch({ type: "replay", pos: startPos(deck.slides[stateRef.current.index]) });
        controller.current?.replayMoment?.(id);
      },
      sequence: () => deckSequence(deck, stepsOf),
      isBusy: () => controller.current?.isBusy() ?? false,
      idle: () => controller.current?.idle() ?? Promise.resolve(),
      toggleAdmin: (open) => adminAvailable && dispatch({ type: "admin", value: open }),
      setLook({ tone, site }) {
        if (tone) dispatch({ type: "tone", value: tone });
        if (site) dispatch({ type: "site", value: site });
      },
      registerKeys(list) {
        bindings.current = [...bindings.current, ...list];
        return () => {
          bindings.current = bindings.current.filter((b) => !list.includes(b));
        };
      },
    };
    return self;
  }, [deck, next, prev, goTo, zoom, adminAvailable, stepsOf]);

  // One set of actions for the keys and for commands from the presenter window (P), so a press
  // there behaves exactly like a key here.
  const actionsRef = useRef<DeckKeyActions | null>(null);
  const audience = useAudienceLink({ deckId: deck.id, api, actions: actionsRef, enabled: !boot.flags.export, auto: !boot.flags.noauto, adminAvailable });
  const actions = useMemo<DeckKeyActions>(
    () => ({
      next,
      prev,
      black: (value) => dispatch({ type: "black", value: stateRef.current.black === value ? false : value }),
      notes: () => dispatch({ type: "notes" }),
      presenter: () => {
        audience.claim();
        openPresenterWindow(deck.id);
      },
      admin: () => adminAvailable && dispatch({ type: "admin" }),
      fullscreen: () => {
        if (document.fullscreenElement) void document.exitFullscreen();
        else void document.documentElement.requestFullscreen().catch(() => {});
      },
      tone: () => TONE_KEY && dispatch({ type: "tone" }),
      zoom,
      escape: () => {
        const s = stateRef.current;
        if (s.jump) dispatch({ type: "jump", value: "" });
        else if (s.admin) dispatch({ type: "admin", value: false });
        else if (s.notes) dispatch({ type: "notes", value: false });
        else if (s.black) dispatch({ type: "black", value: false });
        else return false;
        return true;
      },
      jumpDigit: (d) => dispatch({ type: "jump", value: (stateRef.current.jump + d).slice(-3) }),
      jumpCommit: () => {
        const n = Number(stateRef.current.jump);
        if (!stateRef.current.jump) return false;
        dispatch({ type: "jump", value: "" });
        if (n >= 1 && n <= deck.slides.length) goTo(n - 1, undefined, { instant: true });
        return true;
      },
    }),
    [deck, next, prev, goTo, zoom, adminAvailable, audience],
  );
  useLayoutEffect(() => {
    actionsRef.current = actions;
  }, [actions]);
  useDeckKeys(actions, bindings, !boot.flags.export);

  // The jump buffer clears itself after a pause, like PowerPoint's.
  useEffect(() => {
    if (!state.jump) return;
    const id = window.setTimeout(() => dispatch({ type: "jump", value: "" }), 1500);
    return () => window.clearTimeout(id);
  }, [state.jump]);

  const reportPos = useCallback((pos: SlidePos) => dispatch({ type: "pos", pos }), []);
  const registerController = useCallback((c: SlideController) => {
    controller.current = c;
    listeners.current.forEach((l) => l());
    return () => {
      if (controller.current === c) controller.current = null;
    };
  }, []);

  const value = useMemo<DeckContextValue>(
    () => ({
      deck,
      state,
      slide: deck.slides[state.index],
      flags: boot.flags,
      prototypes,
      theme,
      stepsOf,
      api,
      reportPos,
      registerController,
      adminAvailable,
    }),
    [deck, state, boot.flags, prototypes, theme, stepsOf, api, reportPos, registerController, adminAvailable],
  );

  return <DeckContext.Provider value={value}>{children}</DeckContext.Provider>;
}
