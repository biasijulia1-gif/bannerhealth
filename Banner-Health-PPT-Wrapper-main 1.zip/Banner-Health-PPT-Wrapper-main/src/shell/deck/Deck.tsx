"use client";

import { useEffect } from "react";
import { MotionTokensProvider } from "@/motion";
import type { InProcessPrototype } from "../prototype/contract";
import type { DeckTheme } from "../theme";
import { Stage } from "../stage/Stage";
import { SlideLayer } from "../transitions/SlideLayer";
import { FrameLayer } from "../transitions/FrameLayer";
import { AnnotationLayer } from "../notes/AnnotationLayer";
import { BlackLayer, Hud } from "../hud/Hud";
import { AdminDock } from "../admin/AdminDock";
import { useDeckAutomation } from "../export/automation";
import { DeckProvider, useDeck } from "./DeckProvider";
import { validateDeck, type DeckConfig } from "./schema";

const DOCK_W = 380;

// The 16:9 shell: deck state, motion runtime, stage, layers and the admin dock.
export function Deck({ deck, prototypes, theme }: { deck: DeckConfig; prototypes: Record<string, InProcessPrototype>; theme: DeckTheme }) {
  useEffect(() => {
    const problems = validateDeck(deck, (id) => prototypes[id]?.manifest.steps);
    if (problems.length) console.error(`[deck] ${deck.id} has config problems:\n- ${problems.join("\n- ")}`);
  }, [deck, prototypes]);

  return (
    <DeckProvider deck={deck} prototypes={prototypes} theme={theme}>
      <MotionTokensProvider>
        <DeckRoot />
      </MotionTokensProvider>
    </DeckProvider>
  );
}

function DeckRoot() {
  const { state, theme, api, flags, adminAvailable } = useDeck();
  useDeckAutomation(api, flags);
  const open = adminAvailable && state.admin;

  return (
    <div
      className="fixed inset-0 grid overflow-hidden"
      style={{
        background: theme.letterbox,
        gridTemplateColumns: `minmax(0, 1fr) ${open ? DOCK_W : 0}px`,
        transition: "grid-template-columns 450ms cubic-bezier(0.22, 1, 0.36, 1)",
      }}
    >
      {/* A click on the slide takes focus back from the admin panel, so the arrows drive the deck. */}
      <div className="relative min-w-0" onPointerDownCapture={() => (document.activeElement as HTMLElement | null)?.blur?.()}>
        <Stage letterbox={theme.letterbox}>
          <SlideLayer />
          <FrameLayer />
          <AnnotationLayer />
          <BlackLayer />
        </Stage>
      </div>
      <div className="relative min-w-0 overflow-hidden">{adminAvailable && <AdminDock open={open} width={DOCK_W} />}</div>
      <Hud />
    </div>
  );
}
