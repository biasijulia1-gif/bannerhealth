import type { Look, Presentation, Tone } from "./schema";

// The deck's navigation state as a pure reducer. Slides own their inner position (builds,
// journey steps) and report it back here, so the URL, presenter view and remounts always know
// exactly where the deck is.

export type SlidePos = { step?: string; build?: number };

export type DeckState = {
  index: number;
  /** Live position inside the active slide. A (re)mounting slide lands here. */
  pos: SlidePos;
  /** How the active slide was reached: drives its transition and whether it lands settled. */
  nav: { dir: 1 | -1; instant: boolean };
  /** Bumped to remount the active slide (Replay slide). */
  epoch: number;
  black: false | "black" | "white";
  notes: boolean;
  admin: boolean;
  /** Digits typed for "number + Enter" jumps. */
  jump: string;
  /** Tone (T) and site framing (Z). They hold while the deck moves. */
  look: Look;
  /** The framing Z zooms back out to. */
  unzoomed: Exclude<Presentation, "fullbleed">;
};

export type DeckAction =
  | { type: "go"; index: number; pos: SlidePos; dir: 1 | -1; instant: boolean }
  | { type: "pos"; pos: SlidePos }
  | { type: "replay"; pos: SlidePos }
  | { type: "black"; value: DeckState["black"] }
  | { type: "notes"; value?: boolean }
  | { type: "admin"; value?: boolean }
  | { type: "jump"; value: string }
  /** No value flips dark/light. */
  | { type: "tone"; value?: Tone }
  /** No value zooms to fill the slide, or back out. */
  | { type: "site"; value?: Presentation };

export const initialDeckState = (index: number, pos: SlidePos, look: Look = { tone: "dark", site: "framed" }): DeckState => ({
  index,
  pos,
  nav: { dir: 1, instant: true },
  epoch: 0,
  black: false,
  notes: false,
  admin: false,
  jump: "",
  look,
  unzoomed: look.site === "fullbleed" ? "framed" : look.site,
});

export function deckReducer(state: DeckState, action: DeckAction): DeckState {
  switch (action.type) {
    case "go":
      return {
        ...state,
        index: action.index,
        pos: action.pos,
        nav: { dir: action.dir, instant: action.instant },
        // Slides read their landing position when they mount, so going to the slide already on
        // screen remounts it there (a jump to the current slide, the presenter's step list).
        epoch: action.index === state.index ? state.epoch + 1 : state.epoch,
        black: false,
        jump: "",
      };
    case "pos":
      return { ...state, pos: { ...state.pos, ...action.pos } };
    case "replay":
      return { ...state, pos: action.pos, nav: { dir: 1, instant: false }, epoch: state.epoch + 1 };
    case "black":
      return { ...state, black: action.value };
    case "notes":
      return { ...state, notes: action.value ?? !state.notes };
    case "admin":
      return { ...state, admin: action.value ?? !state.admin };
    case "jump":
      return { ...state, jump: action.value };
    case "tone":
      return { ...state, look: { ...state.look, tone: action.value ?? (state.look.tone === "dark" ? "light" : "dark") } };
    case "site": {
      const site = action.value ?? (state.look.site === "fullbleed" ? state.unzoomed : "fullbleed");
      return { ...state, look: { ...state.look, site }, unzoomed: site === "fullbleed" ? state.unzoomed : site };
    }
  }
}
