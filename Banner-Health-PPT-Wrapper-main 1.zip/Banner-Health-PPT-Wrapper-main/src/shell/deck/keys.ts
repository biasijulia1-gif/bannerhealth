"use client";

import { useEffect, useRef } from "react";

// One keyboard handler for the whole deck, installed in the capture phase so it runs before
// anything inside a prototype. Deck keys are handled and stopped here, which is why a presenter
// key like A can never type into the prototype's search bar.

export type DeckKeyActions = {
  next(): void;
  prev(): void;
  black(value: "black" | "white"): void;
  notes(): void;
  presenter(): void;
  admin(): void;
  fullscreen(): void;
  /** Dark / light version. */
  tone(): void;
  /** The prototype fills the slide, or goes back to its framing. */
  zoom(): void;
  escape(): boolean;
  jumpDigit(d: string): void;
  jumpCommit(): boolean;
};

/** Extra bindings (the admin panel's shortcuts) run through the same handler. */
export type KeyBinding = { key: string; shift?: boolean; mod?: boolean; run(): void };

const isEditable = (t: EventTarget | null) =>
  t instanceof HTMLElement && (t.isContentEditable || t.tagName === "INPUT" || t.tagName === "TEXTAREA" || t.tagName === "SELECT");

export function useDeckKeys(actions: DeckKeyActions, bindings: React.RefObject<KeyBinding[]>, enabled = true) {
  const ref = useRef(actions);
  useEffect(() => {
    ref.current = actions;
  });

  useEffect(() => {
    if (!enabled) return;
    const onKey = (e: KeyboardEvent) => {
      const a = ref.current;
      const mod = e.ctrlKey || e.metaKey;
      // Admin shortcuts first (Ctrl+S, Shift+R…), so they work even while a field has focus.
      for (const b of bindings.current ?? []) {
        if (e.key.toLowerCase() === b.key.toLowerCase() && !!b.mod === mod && (b.shift === undefined || b.shift === e.shiftKey)) {
          e.preventDefault();
          e.stopImmediatePropagation();
          b.run();
          return;
        }
      }
      if (mod || e.altKey) return;
      if (isEditable(e.target) && e.key !== "Escape") return;

      let handled = true;
      switch (e.key) {
        case "ArrowRight":
        case "PageDown":
        case " ":
          if (!e.repeat) a.next();
          break;
        case "ArrowLeft":
        case "PageUp":
          if (!e.repeat) a.prev();
          break;
        case "Enter":
          if (!a.jumpCommit() && !e.repeat) a.next();
          break;
        case "b":
        case "B":
        case ".":
          a.black("black");
          break;
        case "w":
        case "W":
        case ",":
          a.black("white");
          break;
        case "n":
        case "N":
          a.notes();
          break;
        case "p":
        case "P":
          a.presenter();
          break;
        case "a":
        case "A":
          a.admin();
          break;
        case "f":
        case "F":
          a.fullscreen();
          break;
        case "t":
        case "T":
          a.tone();
          break;
        case "z":
        case "Z":
          if (!e.repeat) a.zoom();
          break;
        case "Escape":
          handled = a.escape();
          break;
        case "F5":
          break;
        default:
          if (/^[0-9]$/.test(e.key)) a.jumpDigit(e.key);
          else handled = false;
      }
      if (handled) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    };
    // Space and Enter also fire click on the focused button at keyup, so swallow those too.
    const onKeyUp = (e: KeyboardEvent) => {
      if ((e.key === " " || e.key === "Enter") && !isEditable(e.target)) {
        e.preventDefault();
        e.stopImmediatePropagation();
      }
    };
    window.addEventListener("keydown", onKey, { capture: true });
    window.addEventListener("keyup", onKeyUp, { capture: true });
    return () => {
      window.removeEventListener("keydown", onKey, { capture: true });
      window.removeEventListener("keyup", onKeyUp, { capture: true });
    };
  }, [enabled, bindings]);
}
