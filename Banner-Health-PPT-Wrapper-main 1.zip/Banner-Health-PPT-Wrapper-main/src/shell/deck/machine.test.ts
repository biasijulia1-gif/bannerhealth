import { describe, expect, it } from "vitest";
import { deckReducer, initialDeckState } from "./machine";
import { defineDeck, validateDeck } from "./schema";

describe("deckReducer", () => {
  it("moves between slides and clears black and the jump buffer", () => {
    let s = initialDeckState(0, { build: 0 });
    s = deckReducer(s, { type: "black", value: "black" });
    s = deckReducer(s, { type: "jump", value: "4" });
    s = deckReducer(s, { type: "go", index: 3, pos: { step: "home" }, dir: 1, instant: false });
    expect(s).toMatchObject({ index: 3, pos: { step: "home" }, black: false, jump: "", nav: { dir: 1, instant: false } });
  });

  it("remounts the slide on screen when going to it again, and only then", () => {
    let s = initialDeckState(2, { step: "home" });
    s = deckReducer(s, { type: "go", index: 2, pos: { step: "triage.warning" }, dir: 1, instant: true });
    expect(s).toMatchObject({ index: 2, pos: { step: "triage.warning" }, epoch: 1 });
    s = deckReducer(s, { type: "go", index: 3, pos: { build: 0 }, dir: 1, instant: false });
    expect(s.epoch).toBe(1);
  });

  it("merges reported positions and bumps the epoch on replay", () => {
    let s = initialDeckState(2, { step: "home" });
    s = deckReducer(s, { type: "pos", pos: { step: "triage.compose" } });
    expect(s.pos.step).toBe("triage.compose");
    s = deckReducer(s, { type: "replay", pos: { step: "home" } });
    expect(s).toMatchObject({ epoch: 1, pos: { step: "home" }, nav: { instant: false } });
  });

  it("flips dark/light and keeps the look while the deck moves", () => {
    let s = initialDeckState(0, { build: 0 }, { tone: "dark", site: "framed" });
    s = deckReducer(s, { type: "tone" });
    expect(s.look.tone).toBe("light");
    s = deckReducer(s, { type: "site" });
    s = deckReducer(s, { type: "go", index: 2, pos: { step: "home" }, dir: 1, instant: false });
    s = deckReducer(s, { type: "replay", pos: { step: "home" } });
    expect(s.look).toEqual({ tone: "light", site: "fullbleed" });
  });

  it("zooms back out to whichever framing was set", () => {
    let s = initialDeckState(0, { build: 0 }, { tone: "dark", site: "browser" });
    s = deckReducer(s, { type: "site" });
    expect(s.look.site).toBe("fullbleed");
    s = deckReducer(s, { type: "site" });
    expect(s.look.site).toBe("browser");
    s = deckReducer(s, { type: "site", value: "framed" });
    s = deckReducer(s, { type: "site" });
    s = deckReducer(s, { type: "site" });
    expect(s.look.site).toBe("framed");
    // A deck that opens filling the slide zooms out to framed.
    s = deckReducer(initialDeckState(0, { build: 0 }, { tone: "dark", site: "fullbleed" }), { type: "site" });
    expect(s.look.site).toBe("framed");
  });
});

describe("validateDeck", () => {
  const Slide = () => null;
  const steps = ["home", "a", "b", "c"];
  it("catches duplicate ids, unknown steps and reversed ranges", () => {
    const deck = defineDeck({
      id: "t",
      title: "T",
      label: "T",
      slides: [
        { id: "x", type: "brand", title: "x", Component: Slide },
        { id: "x", type: "prototype", title: "p", prototype: "demo", from: "c", to: "a" },
        { id: "y", type: "prototype", title: "q", prototype: "demo", from: "home", to: "zzz" },
        { id: "z", type: "prototype", title: "r", prototype: "nope", from: "home", to: "a" },
      ],
    });
    const problems = validateDeck(deck, (id) => (id === "demo" ? steps : undefined)).join("\n");
    expect(problems).toMatch(/Duplicate slide id "x"/);
    expect(problems).toMatch(/"a" comes before "c"/);
    expect(problems).toMatch(/unknown step "zzz"/);
    expect(problems).toMatch(/unknown prototype "nope"/);
  });
});
