import { defaultLook, PRESENTATIONS, TONES, type DeckConfig, type Look, type SlideConfig } from "./schema";
import type { SlidePos } from "./machine";

// Deep links for rehearsal: /deck?slide=7, /deck?slide=find-doctor&step=doctors.profile,
// /deck?step=doctors.profile (first slide that contains the step), /deck?slide=2&build=1.
// The look rides along when it differs from the config: &tone=light, &site=fullbleed.

export type DeckFlags = { live: boolean; admin: boolean; export: boolean; debug: boolean; noauto: boolean };

export function startPos(slide: SlideConfig): SlidePos {
  return slide.type === "prototype" ? { step: slide.from } : { build: 0 };
}

export function endPos(slide: SlideConfig): SlidePos {
  return slide.type === "prototype" ? { step: slide.to } : { build: slide.builds ?? 0 };
}

function inRange(slide: SlideConfig, step: string, stepsOf: (id: string) => readonly string[]) {
  if (slide.type !== "prototype") return false;
  const steps = stepsOf(slide.prototype);
  const i = steps.indexOf(step);
  return i >= steps.indexOf(slide.from) && i <= steps.indexOf(slide.to);
}

/** A position that exists on the slide: an unknown or out-of-range step lands on its start, builds clamp. */
export function validPos(slide: SlideConfig, pos: SlidePos | undefined, stepsOf: (id: string) => readonly string[]): SlidePos {
  if (!pos) return startPos(slide);
  if (slide.type === "brand") return { build: Math.max(0, Math.min(pos.build ?? 0, slide.builds ?? 0)) };
  return pos.step && inRange(slide, pos.step, stepsOf) ? { step: pos.step } : startPos(slide);
}

/** Every position → walks through, in order (the smoke test, exports and the presenter's tests). */
export function deckSequence(deck: DeckConfig, stepsOf: (id: string) => readonly string[]): Array<{ index: number; slideId: string } & SlidePos> {
  const out: Array<{ index: number; slideId: string } & SlidePos> = [];
  deck.slides.forEach((s, index) => {
    if (s.type === "brand") for (let build = 0; build <= (s.builds ?? 0); build++) out.push({ index, slideId: s.id, build });
    else {
      const steps = stepsOf(s.prototype);
      for (let i = steps.indexOf(s.from); i <= steps.indexOf(s.to); i++) out.push({ index, slideId: s.id, step: steps[i] });
    }
  });
  return out;
}

export function readDeckUrl(
  deck: DeckConfig,
  stepsOf: (id: string) => readonly string[],
): { index: number; pos: SlidePos; flags: DeckFlags; look: Look } {
  const p = new URLSearchParams(window.location.search);
  const flags: DeckFlags = { live: p.has("live"), admin: p.has("admin"), export: p.has("export"), debug: p.has("debug"), noauto: p.has("noauto") || p.has("export") };
  const rawSlide = p.get("slide");
  const step = p.get("step");
  const build = p.get("build");

  let index = -1;
  if (rawSlide) {
    const n = Number(rawSlide);
    index = Number.isInteger(n) ? n - 1 : deck.slides.findIndex((s) => s.id === rawSlide);
  } else if (step) {
    index = deck.slides.findIndex((s) => inRange(s, step, stepsOf));
  }
  if (index < 0 || index >= deck.slides.length) index = 0;

  const slide = deck.slides[index];
  let pos = startPos(slide);
  if (slide.type === "prototype" && step && inRange(slide, step, stepsOf)) pos = { step };
  if (slide.type === "brand" && build) pos = { build: Math.max(0, Math.min(Number(build) || 0, slide.builds ?? 0)) };

  const base = defaultLook(deck);
  const tone = TONES.find((t) => t === p.get("tone")) ?? base.tone;
  const site = PRESENTATIONS.find((s) => s === p.get("site")) ?? base.site;
  return { index, pos, flags, look: { tone, site } };
}

let pending = 0;

/** Keeps the address bar on the current position and look (debounced), so any moment can be shared. */
export function writeDeckUrl(deck: DeckConfig, index: number, pos: SlidePos, look: Look) {
  window.clearTimeout(pending);
  pending = window.setTimeout(() => {
    const url = new URL(window.location.href);
    url.searchParams.set("slide", String(index + 1));
    url.searchParams.delete("step");
    url.searchParams.delete("build");
    const slide = deck.slides[index];
    if (slide?.type === "prototype" && pos.step && pos.step !== slide.from) url.searchParams.set("step", pos.step);
    if (slide?.type === "brand" && pos.build) url.searchParams.set("build", String(pos.build));
    const base = defaultLook(deck);
    url.searchParams.delete("tone");
    url.searchParams.delete("site");
    if (look.tone !== base.tone) url.searchParams.set("tone", look.tone);
    if (look.site !== base.site) url.searchParams.set("site", look.site);
    window.history.replaceState(null, "", url);
  }, 150);
}
