import type { ComponentType } from "react";

// A deck is an ordered list of slides in a config file. Content is data: a new pitch is mostly a
// new config, a new prototype folder and a motion preset.

export type TransitionKind = "crossfade" | "fade-through" | "push" | "cut";

/** The deck's two versions: dark (black ground, white type) and light (bone ground, black type). */
export const TONES = ["dark", "light"] as const;
export type Tone = (typeof TONES)[number];

/** framed: 1:1 inside the frame · browser: in a browser window · fullbleed: fills the slide. */
export const PRESENTATIONS = ["framed", "browser", "fullbleed"] as const;
export type Presentation = (typeof PRESENTATIONS)[number];

/** The deck's live look. T flips the tone; Z zooms prototype slides to fill the slide and back. */
export type Look = { tone: Tone; site: Presentation };

export type FrameConfig = {
  /** Show the slide number top-right. */
  number?: boolean;
  /** Show the spectrum band (hero moments only, per the Valtech brand). */
  band?: boolean;
};

type BaseSlide = {
  id: string;
  title: string;
  /** Private speaker notes: presenter view and PowerPoint speaker notes. */
  notes?: string;
  /** Audience-visible note on the canvas, toggled with N. */
  annotation?: string;
  /** How this slide enters going forward. Going back is always instant. */
  transition?: TransitionKind;
  /** Left out, the slide follows the deck's tone. "invert" is always the opposite, so a contrast
   *  slide stays contrasting in both versions; "dark" or "light" pins it. */
  tone?: Tone | "invert";
  /** false hides the Valtech frame on this slide. */
  frame?: false | FrameConfig;
  /** Leave out of the deck without deleting it. */
  hidden?: boolean;
  /** Rough minutes for the presenter timer. */
  durationHint?: number;
};

export type BrandSlideProps = { build: number };

export type BrandSlideConfig = BaseSlide & {
  type: "brand";
  Component: ComponentType<BrandSlideProps>;
  /** Number of → presses that reveal more of the slide (Keynote-style builds). */
  builds?: number;
};

export type PrototypeSlideConfig = BaseSlide & {
  type: "prototype";
  prototype: string;
  /** First and last journey step on this slide. → past `to` moves to the next slide. */
  from: string;
  to: string;
  /** Pins this slide's framing. Left out, it follows the deck's, which Z switches. */
  presentation?: Presentation;
  /** play: the site's own opening plays on entry · settled: lands already settled (mid-journey). */
  entry?: "play" | "settled";
  /** Steps that move on by themselves (e.g. "searching" → results). Default true. */
  autoAdvance?: boolean;
  /** Extra notes per step, appended to the slide notes. */
  stepNotes?: Record<string, string>;
};

export type SlideConfig = BrandSlideConfig | PrototypeSlideConfig;

export type DeckConfig = {
  id: string;
  title: string;
  /** Deck label shown top-left in the frame. */
  label: string;
  /** The version the deck opens in. Default dark. */
  tone?: Tone;
  /** How prototype slides show the site when the deck opens. Default framed. */
  presentation?: Presentation;
  slides: SlideConfig[];
};

export const defineDeck = (deck: DeckConfig): DeckConfig => ({ ...deck, slides: deck.slides.filter((s) => !s.hidden) });

/** The committed look: what the deck opens in without URL overrides. */
export const defaultLook = (deck: DeckConfig): Look => ({ tone: deck.tone ?? "dark", site: deck.presentation ?? "framed" });

/** A slide's tone in the deck's current version. */
export function toneOf(slide: SlideConfig, tone: Tone): Tone {
  if (slide.tone === "invert") return tone === "dark" ? "light" : "dark";
  return slide.tone ?? tone;
}

/** How a prototype slide shows the site: its own pin, else the deck's live framing. */
export const presentationOf = (slide: PrototypeSlideConfig, look: Look): Presentation => slide.presentation ?? look.site;

/** How many positions a slide has (builds or journey steps), for numbering and validation. */
export function subCount(slide: SlideConfig, steps?: readonly string[]): number {
  if (slide.type === "brand") return (slide.builds ?? 0) + 1;
  if (!steps) return 1;
  return steps.indexOf(slide.to) - steps.indexOf(slide.from) + 1;
}

/** Problems with a deck config (unique ids, steps exist and run forward). */
export function validateDeck(deck: DeckConfig, stepsOf: (prototype: string) => readonly string[] | undefined): string[] {
  const problems: string[] = [];
  const ids = new Set<string>();
  for (const s of deck.slides) {
    if (ids.has(s.id)) problems.push(`Duplicate slide id "${s.id}"`);
    ids.add(s.id);
    if (s.type === "prototype") {
      const steps = stepsOf(s.prototype);
      if (!steps) {
        problems.push(`Slide "${s.id}": unknown prototype "${s.prototype}"`);
        continue;
      }
      const a = steps.indexOf(s.from);
      const b = steps.indexOf(s.to);
      if (a < 0) problems.push(`Slide "${s.id}": unknown step "${s.from}"`);
      if (b < 0) problems.push(`Slide "${s.id}": unknown step "${s.to}"`);
      if (a >= 0 && b >= 0 && b < a) problems.push(`Slide "${s.id}": "${s.to}" comes before "${s.from}"`);
    }
  }
  return problems;
}
