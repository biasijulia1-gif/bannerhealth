import { describe, expect, it } from "vitest";
import { defaultLook, presentationOf, toneOf, type BrandSlideConfig, type PrototypeSlideConfig } from "./schema";

const brand = (tone?: BrandSlideConfig["tone"]): BrandSlideConfig => ({ id: "b", type: "brand", title: "b", Component: () => null, tone });
const proto = (presentation?: PrototypeSlideConfig["presentation"]): PrototypeSlideConfig => ({
  id: "p",
  type: "prototype",
  title: "p",
  prototype: "demo",
  from: "home",
  to: "done",
  presentation,
});

describe("toneOf", () => {
  it("follows the deck, mirrors it on contrast slides, and keeps a pinned tone", () => {
    expect(toneOf(brand(), "dark")).toBe("dark");
    expect(toneOf(brand(), "light")).toBe("light");
    expect(toneOf(brand("invert"), "dark")).toBe("light");
    expect(toneOf(brand("invert"), "light")).toBe("dark");
    expect(toneOf(brand("dark"), "light")).toBe("dark");
  });
});

describe("presentationOf", () => {
  it("uses the deck's live framing unless the slide pins its own", () => {
    const look = { tone: "dark", site: "fullbleed" } as const;
    expect(presentationOf(proto(), look)).toBe("fullbleed");
    expect(presentationOf(proto("browser"), look)).toBe("browser");
  });
});

describe("defaultLook", () => {
  it("opens dark and framed unless the deck says otherwise", () => {
    const deck = { id: "t", title: "T", label: "T", slides: [] };
    expect(defaultLook(deck)).toEqual({ tone: "dark", site: "framed" });
    expect(defaultLook({ ...deck, tone: "light", presentation: "fullbleed" })).toEqual({ tone: "light", site: "fullbleed" });
  });
});
