import type { InProcessPrototype } from "@/shell/prototype/contract";
import { banner } from "./banner";

// Every prototype the deck can load, by id. A new pitch adds its site folder here.
export const prototypes: Record<string, InProcessPrototype> = {
  banner: banner as unknown as InProcessPrototype,
};

export function getPrototype(id: string): InProcessPrototype {
  const p = prototypes[id];
  if (!p) throw new Error(`Unknown prototype "${id}". Registered: ${Object.keys(prototypes).join(", ")}`);
  return p;
}
