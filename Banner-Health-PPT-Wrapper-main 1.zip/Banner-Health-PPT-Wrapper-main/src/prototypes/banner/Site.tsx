"use client";

import { AnimatePresence, motion } from "motion/react";
import { Fragment, useEffect, useRef, useState } from "react";
import { useReplayKey, useTokens } from "@/motion";
import { useInstance, useJourney, useStepDef } from "./hooks";
import type { Page } from "./journey/steps";
import { page as pageTokens } from "./motion/tokens";
import { Nav } from "./components/nav/Nav";
import { Island } from "./components/assistant/Island";
import { Hero, Intro, QuickLinks, type HomeVariant } from "./components/home/Hero";
import { Featured, Footer, Quote, Stats } from "./components/home/Sections";
import { DoctorsPage } from "./components/doctors/DoctorsPage";
import { Outro } from "./components/Outro";

// The whole Banner website: nav, AI island, pages and the end card. It scrolls inside its own
// container, which is also the only @container, so its breakpoints follow the frame it's
// rendered in (1440 desktop, 372 phone), not the browser window.
export function Site() {
  const { scroller } = useInstance();
  const { jumpId } = useJourney();
  const p = useTokens(pageTokens);
  const def = useStepDef();
  const target: Page = def.page === "outro" ? "return" : def.page;
  const [shown, setShown] = useState<Page>(target);
  const [curtain, setCurtain] = useState(0);
  const lastJump = useRef(jumpId);
  // The page swaps while the curtain fully covers it (38% → 55% of the wipe).
  const swapMs = p.curtain.duration ? p.curtain.duration * 416 : 520;

  // "Afterwards" (results → return visit) passes behind a curtain to mark time passing.
  useEffect(() => {
    if (target === shown) return;
    const jumped = lastJump.current !== jumpId;
    lastJump.current = jumpId;
    if (!jumped && shown === "doctors" && target === "return") {
      setCurtain((c) => c + 1);
      const id = window.setTimeout(() => setShown(target), swapMs);
      return () => window.clearTimeout(id);
    }
    setShown(target);
  }, [target, shown, jumpId, swapMs]);

  useEffect(() => {
    scroller.current?.scrollTo({ top: 0 });
  }, [shown, scroller]);

  const assistantOpen = def.phase !== "idle";

  return (
    <div ref={scroller} data-scroller className="no-scrollbar @container relative h-full overflow-x-hidden overflow-y-auto overscroll-none bg-white">
      <div className="relative min-h-full">
        <Nav />
        <Island />
        <AnimatePresence>
          {assistantOpen && (
            <motion.div
              key="scrim"
              className="absolute inset-0 z-[25] bg-navy/10"
              style={{ backdropFilter: `blur(${p.scrimBlur}px)`, WebkitBackdropFilter: `blur(${p.scrimBlur}px)` }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={p.scrim}
            />
          )}
        </AnimatePresence>
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.main
            key={shown}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, transition: p.crossfadeOut }}
            transition={p.crossfadeIn}
          >
            {shown === "doctors" ? <DoctorsResults /> : <HomePage variant={shown === "return" ? "return" : "new"} />}
          </motion.main>
        </AnimatePresence>
      </div>
      <Curtain play={curtain} />
      <AnimatePresence>{def.page === "outro" && <Outro key="outro" />}</AnimatePresence>
    </div>
  );
}

function HomePage({ variant }: { variant: HomeVariant }) {
  // Replaying the hero opening remounts the top of the page (the admin's Replay).
  const replay = useReplayKey("hero.open");
  return (
    <>
      <Fragment key={replay}>
        <Hero variant={variant} />
        <Intro variant={variant} />
        <QuickLinks variant={variant} />
      </Fragment>
      <Featured />
      <Quote />
      <Stats />
      <Footer />
    </>
  );
}

function DoctorsResults() {
  return <DoctorsPage key={useReplayKey("doctors.enter")} />;
}

function Curtain({ play }: { play: number }) {
  const p = useTokens(pageTokens);
  return (
    <AnimatePresence>
      {play > 0 && (
        <motion.div
          key={play}
          className="pointer-events-none fixed inset-0 z-[55] bg-navy-deep"
          initial={{ clipPath: "inset(100% 0% 0% 0%)" }}
          animate={{ clipPath: ["inset(100% 0% 0% 0%)", "inset(0% 0% 0% 0%)", "inset(0% 0% 0% 0%)", "inset(0% 0% 100% 0%)"] }}
          transition={{ ...p.curtain, times: [0, 0.38, 0.55, 1] }}
        >
          <motion.img
            src="/p/banner/images/icons/logo-footer.svg"
            alt=""
            className="absolute top-1/2 left-1/2 w-[260px] -translate-x-1/2 -translate-y-1/2"
            initial={{ opacity: 0 }}
            animate={{ opacity: [0, 1, 1, 0] }}
            transition={{ duration: p.curtain.duration, times: [0, 0.35, 0.6, 0.9] }}
          />
        </motion.div>
      )}
    </AnimatePresence>
  );
}
