import type { PrototypeManifest } from "@/shell/prototype/contract";
import { STEPS, STEP_DEFS, type StepId } from "./journey/steps";

// Plain data about the Banner prototype: no React, so the presenter view and tools can import it.

const labels = Object.fromEntries(STEPS.map((s) => [s, STEP_DEFS[s].label])) as Record<StepId, string>;

export const bannerManifest: PrototypeManifest<StepId> = {
  id: "banner",
  title: "Banner Health · AI journeys",
  steps: STEPS,
  labels,
  viewports: { desktop: { w: 1440, h: 810 }, mobile: { w: 372, h: 732 } },
  // What → does at each step: the same clicks the VO walkthrough's director made.
  advance: {
    home: [{ click: "island" }],
    // Sending finishes the typing first, so one press completes the query and submits it.
    "triage.compose": [{ click: "send" }],
    "triage.howLong": [{ click: "howlong-0" }],
    "triage.warning": [{ click: "warning-5", unless: '[aria-checked="true"]' }, { wait: 0.35 }, { click: "continue" }],
    "triage.result": [{ click: "close" }],
    followup: [{ click: "island" }],
    "finddr.compose": [{ click: "send" }],
    "finddr.insurance": [{ click: "insurance-2" }],
    "finddr.location": [{ click: "reply-0" }],
    "finddr.searching": [{ go: "doctors" }],
    doctors: [{ click: "expand-ruiz" }],
    "doctors.profile": [{ click: "schedule" }],
    "doctors.booking": [{ click: "confirm" }],
    "doctors.booked": [{ click: "done" }],
    return: [{ click: "lang-es" }],
    "return.es": [{ go: "outro" }],
  },
  auto: { "finddr.searching": { to: "doctors", afterMs: 1100 } },
  anchors: {
    home: ["hero", "intro", "quicklinks", "featured", "quote", "stats", "footer"],
    return: ["hero", "intro", "quicklinks", "featured", "quote", "stats", "footer"],
    doctors: ["results", "grid"],
  },
  moments: {
    "hero.open": { label: "Hero opening", at: "home", replay: "remount" },
    "island.open": { label: "AI prompt · open", at: "triage.compose", from: "home", replay: "advance" },
    "island.card": { label: "AI prompt · symptom card", at: "triage.howLong", from: "triage.compose", replay: "advance" },
    "island.chat": { label: "AI prompt · chat", at: "finddr.insurance", from: "finddr.compose", replay: "advance" },
    "doctors.enter": { label: "Doctor results", at: "doctors", replay: "remount" },
    "doctors.profile": { label: "Doctor profile", at: "doctors.profile", from: "doctors", replay: "advance" },
    "booking.sheet": { label: "Booking sheet", at: "doctors.booking", from: "doctors.profile", replay: "advance" },
    "booking.confirm": { label: "Booking confirmed", at: "doctors.booked", from: "doctors.booking", replay: "advance" },
    "page.curtain": { label: "“Time passes” curtain", at: "return", from: "doctors.booked", replay: "advance" },
    outro: { label: "End card", at: "outro", from: "return.es", replay: "advance" },
  },
  capabilities: { multiView: true, cursor: true, scroll: true },
};
