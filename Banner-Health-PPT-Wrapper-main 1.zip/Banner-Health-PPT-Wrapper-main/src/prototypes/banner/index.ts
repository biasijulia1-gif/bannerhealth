import { definePrototype } from "@/shell/prototype/contract";
import { bannerManifest } from "./manifest";
import { createBannerSession } from "./session";
import { BannerView } from "./View";
import "./motion/tokens";
import "./motion/pt";

export const banner = definePrototype({
  manifest: bannerManifest,
  createSession: createBannerSession,
  View: BannerView,
});

export type { BannerSession } from "./session";
