// Fictional doctors at real Banner facilities in Mesa. Portraits come from the Figma cards.

export type Doctor = {
  id: string;
  name: string;
  short: string;
  credential: string;
  photo: string;
  /** Matches how Figma frames each portrait inside the 453×342 slot. */
  crop: "slot" | "wide" | "cover" | "bottom";
  facility: string;
  address: string;
  phone: string;
  rating: number;
  reviews: number;
  next: { en: string; es: string };
  about: { en: string; es: string };
  focus: { en: string; es: string };
  languages: { en: string; es: string };
};

export const doctors: Doctor[] = [
  {
    id: "ruiz",
    name: "Martín Ruiz",
    short: "Dr. Ruiz",
    credential: "MD",
    photo: "/p/banner/images/doctors/d1.webp",
    crop: "slot",
    facility: "Banner Desert Medical Center",
    address: "1400 S Dobson Rd, Mesa, AZ 85202",
    phone: "480-555-0142",
    rating: 4.9,
    reviews: 58,
    next: { en: "Fri, Nov 20 · 11 AM", es: "vie, 20 nov · 11 AM" },
    about: {
      en: "Dr. Ruiz focuses on finding the cause of ongoing belly pain and explaining the next steps in plain language. His patients say he takes the time to answer every question, in English or Spanish.",
      es: "El Dr. Ruiz se enfoca en encontrar la causa del dolor abdominal persistente y en explicar los siguientes pasos con palabras sencillas. Sus pacientes dicen que se toma el tiempo de responder cada pregunta, en inglés o en español.",
    },
    focus: {
      en: "Abdominal pain, gallbladder and pancreas, colonoscopy",
      es: "Dolor abdominal, vesícula y páncreas, colonoscopía",
    },
    languages: { en: "Spanish (native), English", es: "Español (nativo), inglés" },
  },
  {
    id: "mendoza",
    name: "Rafael Mendoza",
    short: "Dr. Mendoza",
    credential: "MD",
    photo: "/p/banner/images/doctors/d2.webp",
    crop: "wide",
    facility: "Banner Gateway Medical Center",
    address: "1900 N Higley Rd, Mesa, AZ 85205",
    phone: "480-555-0187",
    rating: 4.8,
    reviews: 112,
    next: { en: "Fri, Nov 20 · 2:30 PM", es: "vie, 20 nov · 2:30 PM" },
    about: {
      en: "Dr. Mendoza treats reflux, ulcers and IBS, and builds care plans around how his patients actually live.",
      es: "El Dr. Mendoza trata reflujo, úlceras y colon irritable, y diseña planes de atención según la vida de cada paciente.",
    },
    focus: { en: "Reflux, ulcers, IBS", es: "Reflujo, úlceras, colon irritable" },
    languages: { en: "Spanish, English", es: "Español, inglés" },
  },
  {
    id: "herrera",
    name: "Daniel Herrera",
    short: "Dr. Herrera",
    credential: "DO",
    photo: "/p/banner/images/doctors/d3.webp",
    crop: "slot",
    facility: "Banner Baywood Medical Center",
    address: "6644 E Baywood Ave, Mesa, AZ 85206",
    phone: "480-555-0119",
    rating: 4.9,
    reviews: 74,
    next: { en: "Mon, Nov 23 · 9 AM", es: "lun, 23 nov · 9 AM" },
    about: {
      en: "Dr. Herrera specializes in endoscopy and liver health, with a calm, step-by-step approach.",
      es: "El Dr. Herrera se especializa en endoscopía y salud del hígado, con un enfoque tranquilo y paso a paso.",
    },
    focus: { en: "Endoscopy, liver health", es: "Endoscopía, salud del hígado" },
    languages: { en: "Spanish, English", es: "Español, inglés" },
  },
  {
    id: "kim",
    name: "David Kim",
    short: "Dr. Kim",
    credential: "MD",
    photo: "/p/banner/images/doctors/d4.webp",
    crop: "cover",
    facility: "Banner Desert Medical Center",
    address: "1400 S Dobson Rd, Mesa, AZ 85202",
    phone: "480-555-0163",
    rating: 4.7,
    reviews: 41,
    next: { en: "Mon, Nov 23 · 1 PM", es: "lun, 23 nov · 1 PM" },
    about: {
      en: "Dr. Kim focuses on inflammatory bowel disease and long-term digestive health.",
      es: "El Dr. Kim se enfoca en la enfermedad inflamatoria intestinal y la salud digestiva a largo plazo.",
    },
    focus: { en: "Crohn’s, colitis, nutrition", es: "Crohn, colitis, nutrición" },
    languages: { en: "English, Spanish, Korean", es: "Inglés, español, coreano" },
  },
  {
    id: "morales",
    name: "Sofía Morales",
    short: "Dr. Morales",
    credential: "MD",
    photo: "/p/banner/images/doctors/d5.webp",
    crop: "cover",
    facility: "Banner Gateway Medical Center",
    address: "1900 N Higley Rd, Mesa, AZ 85205",
    phone: "480-555-0128",
    rating: 5.0,
    reviews: 36,
    next: { en: "Tue, Nov 24 · 10 AM", es: "mar, 24 nov · 10 AM" },
    about: {
      en: "Dr. Morales cares for women’s digestive health and makes every visit feel unhurried.",
      es: "La Dra. Morales atiende la salud digestiva de la mujer y hace que cada consulta se sienta sin prisas.",
    },
    focus: { en: "Women’s digestive health, colonoscopy", es: "Salud digestiva de la mujer, colonoscopía" },
    languages: { en: "Spanish (native), English", es: "Español (nativo), inglés" },
  },
  {
    id: "vargas",
    name: "Eduardo Vargas",
    short: "Dr. Vargas",
    credential: "MD",
    photo: "/p/banner/images/doctors/d6.webp",
    crop: "bottom",
    facility: "Banner Baywood Medical Center",
    address: "6644 E Baywood Ave, Mesa, AZ 85206",
    phone: "480-555-0171",
    rating: 4.9,
    reviews: 93,
    next: { en: "Tue, Nov 24 · 3:15 PM", es: "mar, 24 nov · 3:15 PM" },
    about: {
      en: "Dr. Vargas has led Banner’s advanced endoscopy program in Mesa for over a decade.",
      es: "El Dr. Vargas dirige desde hace más de una década el programa de endoscopía avanzada de Banner en Mesa.",
    },
    focus: { en: "Advanced endoscopy, pancreas", es: "Endoscopía avanzada, páncreas" },
    languages: { en: "Spanish, English", es: "Español, inglés" },
  },
];
