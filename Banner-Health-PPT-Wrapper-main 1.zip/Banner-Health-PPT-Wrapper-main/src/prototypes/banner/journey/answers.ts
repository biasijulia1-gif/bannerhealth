// Symptom-checker and chat answers. The values live in the session (so two views of one session
// always agree); these are the rules around them.

export const NONE_OF_THESE = 5;

/** Insurance picked in the find-a-doctor chat by default: BCBS of Arizona, as scripted. */
export const BCBS = 2;

/** Any red-flag symptom routes to emergency care instead of urgent care. */
export function isEmergency(warnings: readonly number[]) {
  return warnings.some((w) => w !== NONE_OF_THESE);
}

export function toggleWarning(warnings: readonly number[], i: number): number[] {
  if (i === NONE_OF_THESE) return warnings.includes(i) ? [] : [i];
  const base = warnings.filter((w) => w !== NONE_OF_THESE);
  return base.includes(i) ? base.filter((w) => w !== i) : [...base, i];
}
