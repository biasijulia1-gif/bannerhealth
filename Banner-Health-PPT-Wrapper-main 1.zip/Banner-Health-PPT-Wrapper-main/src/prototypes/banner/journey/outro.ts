// End-card word reveals (seconds from the end card's start), lifted from the VO walkthrough so
// the tagline keeps its spoken rhythm: "Making health care easier, so life can be better."
export const OUTRO_WORD_DELAYS = [0.91, 1.67, 1.95, 2.17, 2.57, 3.05, 3.27, 3.47, 3.57];
export const OUTRO_KICKER_DELAY = 4.63;
