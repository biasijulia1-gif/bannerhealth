import type { Lang } from "@banner/content/copy";

// Every screen state in the prototype. The whole UI is a pure function of (step, lang, data),
// so deep links, arrow-key stepping and exports all land on identical frames.
export const STEPS = [
  "home",
  "triage.compose",
  "triage.howLong",
  "triage.warning",
  "triage.result",
  "followup",
  "finddr.compose",
  "finddr.insurance",
  "finddr.location",
  "finddr.searching",
  "doctors",
  "doctors.profile",
  "doctors.booking",
  "doctors.booked",
  "return",
  "return.es",
  "outro",
] as const;

export type StepId = (typeof STEPS)[number];

export type Page = "home" | "doctors" | "return" | "outro";
export type Flow = "triage" | "findDr";
export type AssistantPhase =
  | "idle"
  | "compose"
  | "howLong"
  | "warning"
  | "result"
  | "insurance"
  | "location"
  | "searching";

type StepDef = {
  label: string;
  page: Page;
  lang: Lang;
  flow?: Flow;
  phase: AssistantPhase;
  /** Doctor profile expanded / booking sheet state on the results page. */
  profile?: boolean;
  booking?: "pick" | "booked";
};

export const STEP_DEFS: Record<StepId, StepDef> = {
  home: { label: "Home", page: "home", lang: "en", phase: "idle" },
  "triage.compose": { label: "Triage · Ask", page: "home", lang: "en", flow: "triage", phase: "compose" },
  "triage.howLong": { label: "Triage · How long", page: "home", lang: "en", flow: "triage", phase: "howLong" },
  "triage.warning": { label: "Triage · Warning signs", page: "home", lang: "en", flow: "triage", phase: "warning" },
  "triage.result": { label: "Triage · Urgent Care", page: "home", lang: "en", flow: "triage", phase: "result" },
  followup: { label: "Home · Follow-up", page: "home", lang: "en", phase: "idle" },
  "finddr.compose": { label: "Find doctor · Ask", page: "home", lang: "en", flow: "findDr", phase: "compose" },
  "finddr.insurance": { label: "Find doctor · Insurance", page: "home", lang: "en", flow: "findDr", phase: "insurance" },
  "finddr.location": { label: "Find doctor · Location", page: "home", lang: "en", flow: "findDr", phase: "location" },
  "finddr.searching": { label: "Find doctor · Searching", page: "home", lang: "en", flow: "findDr", phase: "searching" },
  doctors: { label: "Doctors · Results", page: "doctors", lang: "en", phase: "idle" },
  "doctors.profile": { label: "Doctors · Profile", page: "doctors", lang: "en", phase: "idle", profile: true },
  "doctors.booking": { label: "Doctors · Booking", page: "doctors", lang: "en", phase: "idle", profile: true, booking: "pick" },
  "doctors.booked": { label: "Doctors · Booked", page: "doctors", lang: "en", phase: "idle", profile: true, booking: "booked" },
  return: { label: "Return user", page: "return", lang: "en", phase: "idle" },
  "return.es": { label: "Return user · Español", page: "return", lang: "es", phase: "idle" },
  // Keeps the Spanish page underneath so nothing flips while the end card reveals.
  outro: { label: "End card", page: "outro", lang: "es", phase: "idle" },
};

export function isStep(value: string | null | undefined): value is StepId {
  return !!value && (STEPS as readonly string[]).includes(value);
}

export function stepIndex(step: StepId) {
  return STEPS.indexOf(step);
}
