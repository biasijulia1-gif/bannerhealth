"use client";

import { createContext, useCallback, useContext, useMemo, useSyncExternalStore, type RefObject } from "react";
import type { ViewInput } from "@/shell/prototype/contract";
import { copy, type Lang } from "./content/copy";
import { STEP_DEFS, type StepId } from "./journey/steps";
import type { BannerData, BannerSession, BannerState, FxState } from "./session";

// React access to the Banner session. useJourney() keeps v1's shape so components barely changed.

export const SessionContext = createContext<BannerSession | null>(null);

/** One rendered copy of the site (the deck can show a desktop and a phone copy of one session). */
export type Instance = {
  id: string;
  role: "primary" | "mirror";
  layout: "desktop" | "mobile";
  input: ViewInput;
  root: RefObject<HTMLDivElement | null>;
  scroller: RefObject<HTMLDivElement | null>;
};

export const InstanceContext = createContext<Instance | null>(null);

export function useSession(): BannerSession {
  const session = useContext(SessionContext);
  if (!session) throw new Error("Banner components must render inside <BannerView>");
  return session;
}

export function useBannerState(): BannerState {
  const session = useSession();
  return useSyncExternalStore(session.subscribe, session.getState, session.getState);
}

/** Selects one value from the session data. Selectors must return stable values. */
export function useData<T>(selector: (d: BannerData) => T): T {
  const session = useSession();
  const get = () => selector(session.getState().data);
  return useSyncExternalStore(session.subscribe, get, get);
}

export function useFx<T>(selector: (fx: FxState) => T): T {
  return useData((d) => selector(d.fx));
}

export function useJourney() {
  const session = useSession();
  const { step, prevStep, lang, jumpId } = useBannerState();
  const go = useCallback((target: StepId, opts?: { instant?: boolean }) => session.goTo(target, { source: "ui", ...opts }), [session]);
  return useMemo(
    () => ({
      step,
      prevStep,
      lang,
      t: copy[lang],
      jumpId,
      go,
      next: session.next,
      prev: session.prev,
      setLang: (l: Lang) => session.setLang(l),
    }),
    [step, prevStep, lang, jumpId, go, session],
  );
}

export function useStepDef() {
  return STEP_DEFS[useBannerState().step];
}

export function useTriageAnswers() {
  return { warnings: useData((d) => d.warnings) };
}

export function useInsurance() {
  return useData((d) => d.insurance);
}

export function useInstance(): Instance {
  const instance = useContext(InstanceContext);
  if (!instance) throw new Error("Banner components must render inside <BannerView>");
  return instance;
}

/** The site scrolls inside its own container (so the shell can stage and scale it). */
export function useScroller() {
  return useInstance().scroller;
}
