import { describe, expect, it, vi } from "vitest";
import type { ShellEnv } from "@/shell/prototype/contract";
import { createBannerSession } from "./session";

const env = (): ShellEnv => ({ settle: vi.fn(async () => {}), justSettled: () => false, timeScale: () => 1, track: () => {} });

describe("createBannerSession", () => {
  it("starts clean at the landing step with that step's language", () => {
    const s = createBannerSession({ initialStep: "return.es", env: env(), autoAdvance: false });
    expect(s.getState()).toMatchObject({ step: "return.es", lang: "es", data: { warnings: [], insurance: 2, slot: 0 } });
  });

  it("settles instant jumps and counts them", () => {
    const e = env();
    const s = createBannerSession({ initialStep: "home", env: e, autoAdvance: false });
    s.goTo("doctors", { instant: true });
    expect(e.settle).toHaveBeenCalled();
    expect(s.getState()).toMatchObject({ step: "doctors", prevStep: "home", jumpId: 1 });
  });

  it("moves on from searching after a real arrival, but not after stepping back onto it", () => {
    vi.useFakeTimers();
    const s = createBannerSession({ initialStep: "finddr.location", env: env(), autoAdvance: true });
    s.goTo("finddr.searching");
    vi.advanceTimersByTime(1200);
    expect(s.getState().step).toBe("doctors");
    s.goTo("finddr.searching", { instant: true });
    vi.advanceTimersByTime(3000);
    expect(s.getState().step).toBe("finddr.searching");
    vi.useRealTimers();
  });

  it("keeps choices in the session so every view of it agrees", () => {
    const s = createBannerSession({ initialStep: "doctors", env: env(), autoAdvance: false });
    s.patch({ doctor: "mendoza", slot: 2 });
    s.setFx({ highlight: ["filter-2"] });
    expect(s.getState().data).toMatchObject({ doctor: "mendoza", slot: 2, fx: { highlight: ["filter-2"], pulse: null } });
  });
});
