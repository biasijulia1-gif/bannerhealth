import type { PrototypeSession, SessionEvent, SessionSource, SessionState, ShellEnv } from "@/shell/prototype/contract";
import { getTokens } from "@/motion";
import type { Lang } from "./content/copy";
import { STEPS, STEP_DEFS, stepIndex, type StepId } from "./journey/steps";
import { BCBS } from "./journey/answers";
import { bannerManifest } from "./manifest";
import { page } from "./motion/tokens";

// The Banner journey as an external store (replaces v1's URL-bound JourneyProvider). It never
// reads or writes the URL or the document: the deck or the standalone route owns those. Choices
// that lived in component state (answers, picks, the booking slot) live here, so two views of
// one session always show the same thing, and a new session always starts clean.

/** Presentation effects on top of step state: pulses, highlights, the rolling placeholder. */
export type FxState = {
  placeholder: number | null;
  pulse: string | null;
  highlight: string[];
  a11yFocus: string | null;
  /** A target held in its hover state (the scripted cursor or the admin's Hold). */
  hover: string | null;
};

export const IDLE_FX: FxState = { placeholder: null, pulse: null, highlight: [], a11yFocus: null, hover: null };

export type BannerData = {
  warnings: number[];
  /** Insurance used on the results page. */
  insurance: number;
  /** The chip picked in the chat, null until someone picks. */
  insurancePicked: number | null;
  howLong: number | null;
  /** Profile picked by hand; null opens the default (Dr. Ruiz). */
  doctor: string | null;
  slot: number;
  fx: FxState;
  brand: boolean;
};

export type BannerState = SessionState<StepId> & { lang: Lang; data: BannerData };

export interface BannerSession extends PrototypeSession<StepId, BannerState> {
  patch(data: Partial<BannerData>): void;
  setFx(patch: Partial<FxState>): void;
  setLang(lang: Lang): void;
  next(): void;
  prev(): void;
}

const initialData = (): BannerData => ({
  warnings: [],
  insurance: BCBS,
  insurancePicked: null,
  howLong: null,
  doctor: null,
  slot: 0,
  fx: IDLE_FX,
  brand: false,
});

export function createBannerSession({
  initialStep,
  env,
  autoAdvance,
}: {
  initialStep: StepId;
  env: ShellEnv;
  autoAdvance: boolean;
}): BannerSession {
  let state: BannerState = { step: initialStep, prevStep: null, lang: STEP_DEFS[initialStep].lang, jumpId: 0, data: initialData() };
  let auto = autoAdvance;
  let autoTimer = 0;
  const listeners = new Set<(e?: SessionEvent<StepId>) => void>();
  const emit = (e?: SessionEvent<StepId>) => listeners.forEach((l) => l(e));

  const scheduleAuto = (step: StepId) => {
    window.clearTimeout(autoTimer);
    const rule = bannerManifest.auto?.[step];
    if (!rule || !auto) return;
    const ms = step === "finddr.searching" ? getTokens(page).searchHold * 1000 : rule.afterMs * env.timeScale();
    autoTimer = window.setTimeout(() => {
      if (state.step === step) goTo(rule.to, { source: "auto" });
    }, ms);
  };

  function goTo(step: StepId, opts: { instant?: boolean; source?: SessionSource } = {}) {
    window.clearTimeout(autoTimer);
    if (opts.instant) void env.settle();
    const from = state.step;
    state = {
      ...state,
      prevStep: from,
      step,
      lang: STEP_DEFS[step].lang,
      jumpId: opts.instant ? state.jumpId + 1 : state.jumpId,
    };
    emit({ type: "step", step, from, instant: !!opts.instant, source: opts.source ?? "ui" });
    // Only a real arrival moves on by itself; stepping back onto "searching" must stay put.
    if (!opts.instant) scheduleAuto(step);
  }

  const patch = (data: Partial<BannerData>) => {
    state = { ...state, data: { ...state.data, ...data } };
    emit({ type: "change" });
  };

  return {
    getState: () => state,
    subscribe(listener) {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
    goTo,
    reset(step = initialStep) {
      window.clearTimeout(autoTimer);
      state = { ...state, data: initialData() };
      goTo(step, { instant: true, source: "shell" });
    },
    setAutoAdvance(on) {
      auto = on;
      if (!on) window.clearTimeout(autoTimer);
    },
    // Timers only: subscribers unsubscribe themselves (and React may re-run effects in dev).
    dispose() {
      window.clearTimeout(autoTimer);
    },
    patch,
    setFx: (fx) => patch({ fx: { ...state.data.fx, ...fx } }),
    setLang(lang) {
      state = { ...state, lang };
      emit({ type: "change" });
    },
    next() {
      const i = stepIndex(state.step);
      if (i < STEPS.length - 1) goTo(STEPS[i + 1]);
    },
    prev() {
      const i = stepIndex(state.step);
      if (i > 0) goTo(STEPS[i - 1], { instant: true });
    },
  };
}
