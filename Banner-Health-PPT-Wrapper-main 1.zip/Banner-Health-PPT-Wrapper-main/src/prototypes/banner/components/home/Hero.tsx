"use client";

import { motion } from "motion/react";
import { useTokens } from "@/motion";
import { useFx, useJourney } from "@banner/hooks";
import { hero } from "@banner/motion/tokens";
import { SplitWords } from "@banner/components/motion/SplitWords";
import { FadeText } from "@banner/components/motion/RollText";

export type HomeVariant = "new" | "return";

export function Hero({ variant }: { variant: HomeVariant }) {
  const h = useTokens(hero);
  const isReturn = variant === "return";
  return (
    <div data-anchor="hero" className="px-2 pt-[84px] @desk:px-4 @desk:pt-[100px]">
      <motion.div
        className="relative h-[560px] overflow-hidden rounded-[10px] bg-mist @tab:h-auto @tab:aspect-[1408/590]"
        initial={{ clipPath: `inset(${h.insetY}% ${h.insetX}% ${h.insetY}% ${h.insetX}% round 10px)`, opacity: 0 }}
        animate={{ clipPath: "inset(0% 0% 0% 0% round 10px)", opacity: 1 }}
        transition={{ ...h.frame, delay: h.frameDelay }}
      >
        <motion.div
          className="absolute inset-0"
          initial={{ scale: h.imageScale }}
          animate={{ scale: 1 }}
          transition={{ ...h.image, delay: h.frameDelay }}
        >
          {isReturn ? (
            <img
              src="/p/banner/images/home/return-hero.webp"
              alt="A mother hugging her two sons"
              className="absolute inset-0 size-full object-cover object-[50%_40%]"
              draggable={false}
            />
          ) : (
            <>
              {/* Figma crops the wide source tight on her face at desktop; mobile uses a cover crop. */}
              <img
                src="/p/banner/images/home/hero.webp"
                alt="A smiling woman relaxing at home on a blue sofa"
                className="absolute top-[-20.43%] left-[-193.78%] hidden h-[203.37%] w-[397.55%] max-w-none @tab:block"
                draggable={false}
              />
              <img
                src="/p/banner/images/home/hero.webp"
                alt=""
                aria-hidden
                className="absolute inset-0 size-full object-cover object-[55%_30%] @tab:hidden"
                draggable={false}
              />
            </>
          )}
        </motion.div>
      </motion.div>
    </div>
  );
}

export function Intro({ variant }: { variant: HomeVariant }) {
  const { t, lang } = useJourney();
  const h = useTokens(hero);
  const isReturn = variant === "return";
  const title = isReturn ? t.returning.title : t.home.title;
  const sub = isReturn ? t.returning.sub : t.home.sub;

  return (
    <section data-anchor="intro" className="flex flex-col gap-6 px-4 py-8 @desk:flex-row @desk:gap-0 @desk:px-6 @desk:py-10">
      <div className="flex flex-1 flex-col gap-4 @desk:gap-6">
        <SplitWords
          key={`${variant}-${lang}`}
          as="h1"
          text={title}
          delay={h.headlineDelay}
          className="serif-display max-w-[570px] text-[clamp(48px,5.556cqw,80px)] leading-[1.1] tracking-[-0.01em] text-blue"
        />
        <motion.p
          className="max-w-[663px] text-[22px] leading-[1.2] font-medium text-navy @desk:text-[30px]"
          initial={{ opacity: 0, y: h.textRise }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ ...h.text, delay: h.subDelay }}
        >
          <FadeText text={sub} />
        </motion.p>
      </div>
      <motion.div
        className="flex flex-1 flex-col @desk:pt-4"
        initial={{ opacity: 0, y: h.textRise }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ ...h.text, delay: h.bodyDelay }}
      >
        <p className="max-w-[663px] text-[16px] leading-[1.2] font-medium text-navy @desk:text-[20px]">
          <FadeText text={t.home.body} />
        </p>
      </motion.div>
    </section>
  );
}

type Card = { title: string; body: string; icon: string; iconSize?: [number, number]; framed?: boolean };

const SERVICE_ICONS: Omit<Card, "title" | "body">[] = [
  { icon: "/p/banner/images/icons/svc-urgent.svg" },
  { icon: "/p/banner/images/icons/svc-telehealth.svg", iconSize: [30, 30], framed: true },
  { icon: "/p/banner/images/icons/svc-doctor.svg", iconSize: [23.38, 26.47], framed: true },
  { icon: "/p/banner/images/icons/svc-schedule.svg" },
];

const TASK_ICONS: Omit<Card, "title" | "body">[] = [
  { icon: "/p/banner/images/icons/task-labs.svg" },
  { icon: "/p/banner/images/icons/task-bill.svg", iconSize: [24, 24], framed: true },
  { icon: "/p/banner/images/icons/task-schedule.svg" },
  { icon: "/p/banner/images/icons/task-records.svg", iconSize: [21, 27.76], framed: true },
];

export function QuickLinks({ variant }: { variant: HomeVariant }) {
  const { t } = useJourney();
  const isReturn = variant === "return";
  const items = (isReturn ? t.returning.tasks : t.home.services).map((c, i) => ({
    ...c,
    ...(isReturn ? TASK_ICONS : SERVICE_ICONS)[i],
  }));

  return (
    <section data-anchor="quicklinks" className="bg-white px-4 pb-12 @desk:px-6 @desk:pb-[60px]">
      <div className="grid grid-cols-1 gap-3 @tab:grid-cols-2 @desk:grid-cols-4 @desk:gap-4">
        {items.map((card, i) => (
          <QuickCard key={`${variant}-${i}`} card={card} index={i} id={isReturn ? `task-${i}` : `service-${i}`} />
        ))}
      </div>
    </section>
  );
}

function QuickCard({ card, index, id }: { card: Card; index: number; id: string }) {
  const h = useTokens(hero);
  const lit = useFx((s) => s.highlight.includes(id) || s.a11yFocus === id);
  return (
    <motion.div
      initial={{ opacity: 0, y: h.cardsRise }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ ...h.cards, delay: h.cardsDelay + index * h.cardsStagger }}
    >
      <motion.a
        href="#"
        onClick={(e) => e.preventDefault()}
        data-target={id}
        className="ts-edge group relative flex h-full flex-col justify-between gap-10 overflow-hidden rounded-[10px] border border-white px-6 py-5 ring-1 ring-navy/[0.06] @desk:h-[300px] @desk:py-3.5"
        style={{ backgroundImage: "linear-gradient(153.5deg, rgba(255,255,255,0.6) 13.5%, rgba(255,255,255,0) 102.7%)" }}
        initial={false}
        animate={{
          y: lit ? -h.cardLift : 0,
          boxShadow: lit ? "0 24px 48px -24px rgba(0,79,171,0.45)" : "0 0px 0px 0px rgba(0,79,171,0)",
          backgroundColor: lit ? "rgba(237,247,255,1)" : "rgba(237,247,255,0)",
        }}
        transition={h.cardLit}
        whileHover={{ y: -h.cardHover }}
      >
        <motion.span
          className="relative grid size-[60px] place-items-center"
          animate={lit ? { rotate: [0, -8, 6, 0], scale: [1, 1.12, 1] } : { rotate: 0, scale: 1 }}
          transition={h.iconWiggle}
        >
          {card.framed ? (
            <span className="grid size-[60px] place-items-center rounded-full border border-white/90 bg-[rgba(237,247,255,0.7)] p-1">
              <img src={card.icon} alt="" width={card.iconSize?.[0]} height={card.iconSize?.[1]} style={{ width: card.iconSize?.[0], height: card.iconSize?.[1] }} />
            </span>
          ) : (
            <img src={card.icon} alt="" width={60} height={60} className="size-[60px]" />
          )}
        </motion.span>
        <span className="flex flex-col gap-2">
          <span className="text-[20px] leading-none font-semibold tracking-[-0.01em] text-navy">{card.title}</span>
          <span className="max-w-[266px] text-[16px] leading-[1.2] font-medium tracking-[-0.01em] text-blue">{card.body}</span>
        </span>
        <motion.span
          aria-hidden
          className="pointer-events-none absolute inset-0 rounded-[10px] border-2 border-mint"
          initial={false}
          animate={{ opacity: lit ? 1 : 0 }}
          transition={h.mint}
        />
      </motion.a>
    </motion.div>
  );
}
