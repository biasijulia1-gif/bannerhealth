"use client";

import { motion, useScroll, useTransform } from "motion/react";
import { useRef } from "react";
import { useTokens } from "@/motion";
import { useJourney, useScroller } from "@banner/hooks";
import { text } from "@banner/motion/tokens";
import { SplitWords } from "@banner/components/motion/SplitWords";
import { Reveal } from "@banner/components/motion/Reveal";
import { CountUp } from "@banner/components/motion/CountUp";

const CARD_GRADIENT = "linear-gradient(222.9deg, rgba(78,88,84,0) 51.4%, rgba(78,88,84,0.3) 87.4%)";

export function Featured() {
  const { t, lang } = useJourney();
  const tk = useTokens(text);
  const track = useRef<HTMLDivElement>(null);
  const cards = [
    { label: t.featured.cards[0], src: "/p/banner/images/home/womens.webp", w: "@desk:w-[664px]" },
    { label: t.featured.cards[1], src: "/p/banner/images/home/cancer.webp", w: "@desk:w-[345px]" },
    { label: t.featured.cards[2], src: "/p/banner/images/home/pediatrics.webp", w: "@desk:w-[345px]" },
  ];

  return (
    <section data-anchor="featured" className="px-4 py-8 @desk:px-6">
      <div className="flex flex-col gap-[50px]">
        <div className="flex flex-col gap-6 @desk:flex-row @desk:gap-[60px] @desk:px-2.5">
          <div className="flex flex-col gap-6 @desk:w-[660px]">
            <div className="flex flex-col gap-3 text-[14px] text-navy">
              <p className="font-medium">{t.featured.index}</p>
              <p className="font-semibold uppercase">{t.featured.eyebrow}</p>
            </div>
            <SplitWords
              key={lang}
              inView
              as="h2"
              text={t.featured.title}
              className="serif-text text-[clamp(36px,4.167cqw,60px)] leading-[1.1] tracking-[-0.01em] text-navy"
            />
            <a
              href="#"
              onClick={(e) => e.preventDefault()}
              className="flex h-[42px] w-fit items-center justify-center rounded-[22px] border border-navy px-10 transition-colors hover:bg-navy hover:text-white"
            >
              <span className="trim-cap text-[12px] leading-[1.1] font-medium tracking-[-0.02em] whitespace-nowrap">{t.featured.cta}</span>
            </a>
          </div>
          <Reveal className="@desk:w-[662px] @desk:pt-[84px]">
            <p className="max-w-[619px] text-[16px] leading-[1.2] font-medium text-navy @desk:text-[20px]">{t.featured.body}</p>
          </Reveal>
        </div>

        <div className="flex flex-col gap-6 pb-[30px]">
          <div ref={track} className="-mr-4 overflow-hidden @desk:-mr-6 @desk:pl-8">
            <motion.div drag="x" dragConstraints={track} dragElastic={0.08} className="flex w-max cursor-grab gap-4 active:cursor-grabbing">
              {cards.map((card, i) => (
                <Reveal key={card.label} delay={i * tk.featuredStagger} y={tk.featuredRise}>
                  <div className={`group relative h-[420px] w-[300px] overflow-hidden rounded-[10px] bg-[#3d3e38] @desk:h-[600px] ${card.w}`}>
                    <motion.img
                      src={card.src}
                      alt=""
                      draggable={false}
                      className="absolute inset-0 size-full object-cover transition-transform duration-[1.2s] ease-out group-hover:scale-105"
                    />
                    <div className="absolute inset-0 mix-blend-multiply" style={{ backgroundImage: CARD_GRADIENT }} />
                    <p className="absolute bottom-[41px] left-[34px] w-[200px] text-[20px] leading-[1.1] font-extrabold tracking-[-0.01em] text-white uppercase">
                      {card.label}
                    </p>
                  </div>
                </Reveal>
              ))}
            </motion.div>
          </div>
          <div className="flex w-[108px] flex-col gap-4">
            <div className="flex items-center gap-3">
              {[0, 1].map((i) => (
                <button
                  key={i}
                  type="button"
                  aria-label={i === 0 ? "Previous" : "Next"}
                  className="grid size-12 place-items-center rounded-full border-[1.2px] border-slate transition-colors hover:bg-slate/10"
                >
                  <img src="/p/banner/images/icons/chevron-left.svg" alt="" width={24} height={24} className={`size-6 ${i === 1 ? "rotate-180" : ""}`} />
                </button>
              ))}
            </div>
            <a href="#" onClick={(e) => e.preventDefault()} className="group flex items-center gap-2">
              <span className="text-[14px] font-semibold whitespace-nowrap text-slate uppercase">{t.featured.seeAll}</span>
              <img src="/p/banner/images/icons/arrow-dark.svg" alt="" width={48} height={8} className="h-2 w-12 transition-transform group-hover:translate-x-1" />
            </a>
          </div>
        </div>

        <div className="pb-20 @desk:px-2.5 @desk:pb-[120px]">
          <SplitWords
            key={lang}
            inView
            as="h2"
            text={t.world}
            className="serif-text text-center text-[clamp(30px,3.472cqw,50px)] leading-[1.1] tracking-[-0.01em] text-navy"
          />
        </div>
      </div>
    </section>
  );
}

export function Quote() {
  const { t } = useJourney();
  const scroller = useScroller();
  const box = useRef<HTMLDivElement>(null);
  const { scrollYProgress } = useScroll({ container: scroller, target: box, offset: ["start end", "end start"] });
  const y = useTransform(scrollYProgress, [0, 1], ["-6%", "0%"]);

  return (
    <section data-anchor="quote" className="px-4 @desk:px-12">
      <div ref={box} className="relative flex h-[520px] flex-col items-center justify-center gap-6 overflow-hidden rounded-[10px] px-6 py-[100px] @desk:h-[607px]">
        <motion.img
          src="/p/banner/images/home/quote.webp"
          alt=""
          style={{ y }}
          className="absolute top-0 left-[-26.8%] h-[204.59%] w-[153.62%] max-w-none object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent from-[18%] via-black/20 via-[56%] to-transparent to-[92%]" />
        <Reveal className="relative flex flex-col items-center gap-6 text-center text-white">
          <p className="text-[14px] font-semibold uppercase">{t.quote.eyebrow}</p>
          <p className="serif-text max-w-[708px] text-[clamp(26px,2.778cqw,40px)] leading-[1.1] tracking-[-0.01em]">{t.quote.text}</p>
          <p className="text-[14px] uppercase">
            <span className="font-semibold">{t.quote.name}</span>
            <br />
            <span className="font-medium">{t.quote.role}</span>
          </p>
          <img src="/p/banner/images/icons/arrow-light.svg" alt="" width={48} height={8} className="h-2 w-12" />
        </Reveal>
      </div>
    </section>
  );
}

export function Stats() {
  const { t } = useJourney();
  const tk = useTokens(text);
  const tones = ["bg-mist", "bg-mist", "bg-sand", "bg-sand"];
  return (
    <section data-anchor="stats" className="flex flex-col py-10 @desk:flex-row @desk:items-center">
      <Reveal className="relative h-[320px] w-full overflow-hidden @desk:h-[712px] @desk:w-[50.6%] @desk:shrink-0">
        <img src="/p/banner/images/home/stats.webp" alt="A doctor talking with a patient and family member" className="absolute inset-0 size-full object-cover object-bottom" />
      </Reveal>
      <div className="grid flex-1 grid-cols-1 @tab:grid-cols-2">
        {t.stats.map((s, i) => (
          <Reveal key={s.label} delay={i * tk.statsStagger} className={`border-[6px] border-white ${tones[i]}`}>
            <div className="flex h-[280px] flex-col justify-between p-[35px] @desk:h-[356px]">
              <div className="flex flex-col gap-6">
                <p className="trim-cap text-[14px] leading-[1.1] font-semibold tracking-[0.1em] text-navy-ink uppercase">{s.label}</p>
                <CountUp
                  value={s.value}
                  suffix={s.suffix}
                  className="trim-cap text-[64px] leading-[1.1] font-semibold tracking-[-0.02em] text-navy @desk:text-[84.5px]"
                />
              </div>
              <p className="max-w-[260px] text-[14px] leading-[1.2] font-semibold tracking-[0.01em] text-navy-ink">{s.body}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

export function Footer() {
  const { t } = useJourney();
  const social = [
    { src: "/p/banner/images/icons/social-1.svg", w: 24.16, h: 24.16 },
    { src: "/p/banner/images/icons/social-2.svg", w: 30.49, h: 21.37 },
    { src: "/p/banner/images/icons/social-3.svg", w: 26.54, h: 26.54 },
    { src: "/p/banner/images/icons/social-4.svg", w: 24.17, h: 24.17 },
    { src: "/p/banner/images/icons/social-5.svg", w: 22.55, h: 21.47 },
  ];
  return (
    <footer data-anchor="footer" className="relative flex flex-col gap-10 overflow-hidden bg-navy-deep px-6 py-10 text-white @desk:h-[611px] @desk:px-10">
      <div className="flex items-start justify-between">
        <img src="/p/banner/images/icons/logo-footer.svg" alt="Banner Health" width={462} height={48} className="h-auto w-[260px] @desk:h-12 @desk:w-[461.7px]" />
      </div>
      <div className="flex flex-col gap-10 @desk:absolute @desk:inset-x-10 @desk:bottom-5 @desk:flex-row @desk:items-end @desk:justify-between">
        <div className="flex flex-col gap-10 @desk:w-[602px]">
          <p className="serif-text text-[44px] leading-[0.95] tracking-[-0.02em] @desk:text-[64px]">
            {t.footer.tagline.map((line) => (
              <span key={line} className="block">
                {line}
              </span>
            ))}
          </p>
          <p className="text-[9px] whitespace-pre-wrap">{t.footer.legal}</p>
        </div>
        <div className="flex flex-col gap-10 @desk:mb-[115px] @desk:items-end">
          <div className="flex items-center gap-7">
            {social.map((s) => (
              <img key={s.src} src={s.src} alt="" width={s.w} height={s.h} style={{ width: s.w, height: s.h }} />
            ))}
          </div>
          <div className="grid grid-cols-1 gap-8 @tab:grid-cols-3 @desk:gap-2">
            {t.footer.columns.map((col) => (
              <div key={col.title} className="flex flex-col gap-5 @desk:w-[217px] @desk:pl-10">
                <p className="trim-cap text-[16px] leading-[1.1] font-semibold tracking-[-0.02em] whitespace-nowrap text-sky">{col.title}</p>
                {col.links.map((l) => (
                  <a key={l} href="#" onClick={(e) => e.preventDefault()} className="trim-cap text-[14px] leading-[1.1] tracking-[-0.02em] hover:underline">
                    {l}
                  </a>
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
}
