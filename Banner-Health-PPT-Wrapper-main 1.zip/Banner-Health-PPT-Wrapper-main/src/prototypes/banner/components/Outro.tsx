"use client";

import { AnimatePresence, motion } from "motion/react";
import { useState } from "react";
import { useTime, useTokens } from "@/motion";
import { copy } from "@banner/content/copy";
import { OUTRO_KICKER_DELAY, OUTRO_WORD_DELAYS } from "@banner/journey/outro";
import { page } from "@banner/motion/tokens";

// End card. Always English: its word reveals keep the VO tagline's rhythm ("Making health care easier…").
export function Outro() {
  const t = copy.en;
  const words = t.outro.tagline.split(" ");
  const [clicks, setClicks] = useState(0);
  const p = useTokens(page);
  const s = useTime();

  return (
    <motion.div
      className="fixed inset-0 z-[60] flex flex-col items-center justify-center gap-10 overflow-hidden bg-navy-deep px-8 text-center text-white"
      initial={{ clipPath: "circle(0% at 50% 55%)" }}
      animate={{ clipPath: "circle(150% at 50% 55%)" }}
      exit={{ opacity: 0 }}
      transition={p.outroWipe}
    >
      <motion.div
        aria-hidden
        className="pointer-events-none absolute -top-1/3 left-1/2 size-[1100px] -translate-x-1/2 rounded-full"
        style={{ background: "radial-gradient(circle, rgba(32,219,155,0.16), transparent 60%)" }}
        animate={{ scale: [1, 1.08, 1], opacity: [0.7, 1, 0.7] }}
        transition={{ ...p.outroGlow, repeat: Infinity }}
      />
      <motion.button
        type="button"
        data-target="outro-click"
        onClick={() => setClicks((c) => c + 1)}
        className="relative"
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ ...p.outroLogo, delay: p.outroLogoDelay }}
      >
        <img src="/p/banner/images/icons/logo-footer.svg" alt="Banner Health" width={462} height={48} className="h-auto w-[280px] @desk:w-[420px]" />
        <AnimatePresence>
          {clicks > 0 && (
            <motion.span
              key={clicks}
              className="absolute top-1/2 left-1/2 size-[200px] -translate-x-1/2 -translate-y-1/2 rounded-full border border-mint"
              initial={{ scale: 0.2, opacity: 1 }}
              animate={{ scale: 6, opacity: 0 }}
              transition={{ duration: s(1.6), ease: "easeOut" }}
            />
          )}
        </AnimatePresence>
      </motion.button>

      <h2 className="serif-display max-w-[980px] text-[clamp(40px,4.5cqw,72px)] leading-[1.08] tracking-[-0.01em]">
        {words.map((word, i) => (
          <span key={`${word}-${i}`} className="inline-block overflow-hidden pb-[0.1em] align-top">
            <motion.span
              className="inline-block"
              initial={{ y: "105%", opacity: 0, filter: `blur(${p.outroBlur}px)` }}
              animate={{ y: "0%", opacity: 1, filter: "blur(0px)" }}
              transition={{ ...p.outroWord, delay: s(OUTRO_WORD_DELAYS[i] ?? 0.9 + i * 0.25) }}
            >
              {word}
            </motion.span>
            {i < words.length - 1 ? " " : null}
          </span>
        ))}
      </h2>

      <motion.p
        className="text-[20px] font-semibold tracking-[0.02em] text-sky @desk:text-[24px]"
        initial={{ opacity: 0, y: 12, letterSpacing: "0.3em" }}
        animate={{ opacity: 1, y: 0, letterSpacing: "0.02em" }}
        transition={{ ...p.outroKicker, delay: s(OUTRO_KICKER_DELAY) }}
      >
        {t.outro.kicker}
      </motion.p>
    </motion.div>
  );
}
