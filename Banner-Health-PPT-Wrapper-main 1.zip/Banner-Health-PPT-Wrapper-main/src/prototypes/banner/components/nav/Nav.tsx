"use client";

import { AnimatePresence, motion } from "motion/react";
import { useTokens } from "@/motion";
import { useFx, useJourney, useStepDef } from "@banner/hooks";
import { nav } from "@banner/motion/tokens";
import { RollText } from "@banner/components/motion/RollText";
import { PulseRing } from "@banner/components/ui/PulseRing";

export function Nav() {
  const { t, step, go } = useJourney();
  const n = useTokens(nav);
  const def = useStepDef();
  const assistantOpen = def.phase !== "idle";
  const a11y = useFx((s) => s.a11yFocus);

  const home = () => go(step.startsWith("return") ? step : "home");

  return (
    <motion.header
      className="relative z-20 flex items-center justify-between px-6 py-6 @desk:items-start @desk:px-8 @desk:pt-8 @desk:pb-6"
      initial={{ opacity: 0, y: -n.headerRise }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ ...n.header, delay: n.headerDelay }}
    >
      <div className="flex min-w-0 flex-1 items-center">
        <button type="button" onClick={home} aria-label="Banner Health home" className="block">
          <img src="/p/banner/images/icons/logo-nav.svg" alt="Banner Health" width={257} height={33} className="hidden h-[33px] w-[257px] @desk:block" />
          <img src="/p/banner/images/icons/logo-mobile.svg" alt="Banner Health" width={179} height={23} className="block h-[23px] w-[179px] @desk:hidden" />
        </button>
      </div>

      <nav aria-label="Primary" className="hidden pt-[17px] @desk:block">
        <AnimatePresence initial={false}>
          {!assistantOpen && (
            <motion.ul
              className="flex items-center gap-8 text-[14px] leading-[1.1] font-medium tracking-[-0.28px] text-navy"
              initial={{ opacity: 0, y: -n.linksRise, filter: `blur(${n.linksBlur}px)` }}
              animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
              exit={{ opacity: 0, y: -n.linksRise, filter: `blur(${n.linksBlur}px)` }}
              transition={n.links}
            >
              {t.nav.links.map((label) => (
                <li key={label} className="trim-cap whitespace-nowrap">
                  <a href="#" onClick={(e) => e.preventDefault()} className="group relative">
                    <RollText text={label} />
                    <span className="absolute -bottom-1.5 left-0 h-px w-full origin-left scale-x-0 bg-navy transition-transform duration-300 group-hover:scale-x-100" />
                  </a>
                </li>
              ))}
            </motion.ul>
          )}
        </AnimatePresence>
      </nav>

      <div className="flex flex-1 items-center justify-end gap-4">
        <div className="relative hidden items-center gap-1 @desk:flex" data-target="mesa">
          <img src="/p/banner/images/icons/pin.svg" alt="" width={7} height={9} className="h-[9.36px] w-[7.26px] -scale-y-100 rotate-180" />
          <span className="trim-cap text-[14px] leading-[1.1] font-medium tracking-[-0.28px] text-navy underline decoration-[6%] underline-offset-2">
            {t.nav.location}
          </span>
          <PulseRing id="mesa" />
        </div>

        <a
          href="#"
          onClick={(e) => e.preventDefault()}
          data-target="portal"
          data-a11y-focus={a11y === "portal"}
          className="relative hidden h-[42px] items-center justify-center rounded-[22px] border border-navy px-[18px] transition-colors hover:bg-navy hover:text-white @desk:flex"
        >
          <span className="trim-cap text-[14px] leading-[1.1] font-medium tracking-[-0.28px] whitespace-nowrap">
            <RollText text={t.nav.portal} />
          </span>
          <PulseRing id="portal" radius={22} />
        </a>

        <LangToggle />

        <button type="button" aria-label="Menu" className="block @desk:hidden">
          <img src="/p/banner/images/icons/menu.svg" alt="" width={29} height={21} className="h-[21px] w-[29px]" />
        </button>
      </div>
    </motion.header>
  );
}

function LangToggle() {
  const { lang, step, go, setLang, t } = useJourney();
  const n = useTokens(nav);
  const a11y = useFx((s) => s.a11yFocus);

  const choose = (next: "en" | "es") => {
    if (next === lang) return;
    if (step === "return" && next === "es") go("return.es");
    else if (step === "return.es" && next === "en") go("return");
    else setLang(next);
  };

  const options = [
    { id: "en" as const, desk: t.nav.hello, mobile: "EN" },
    { id: "es" as const, desk: t.nav.hola, mobile: "ES" },
  ];

  return (
    <div
      role="group"
      aria-label="Language"
      data-a11y-focus={a11y === "lang"}
      className="relative flex h-[32px] items-stretch rounded-full bg-fog backdrop-blur-[25px] @desk:h-[42px]"
    >
      {options.map((o) => {
        const active = lang === o.id;
        return (
          <button
            key={o.id}
            type="button"
            data-target={`lang-${o.id}`}
            aria-pressed={active}
            onClick={() => choose(o.id)}
            className={`relative flex items-center justify-center px-3 text-[12px] leading-[1.2] transition-colors duration-300 @desk:px-6 @desk:text-[14px] ${
              active ? "font-semibold text-white" : "font-medium text-slate"
            }`}
          >
            {active && (
              <motion.span layoutId="lang-pill" className="absolute inset-0 rounded-full bg-blue" transition={n.langPill} />
            )}
            <span className="relative hidden @desk:inline">{o.desk}</span>
            <span className="relative @desk:hidden">{o.mobile}</span>
            <PulseRing id={`lang-${o.id}`} />
          </button>
        );
      })}
    </div>
  );
}
