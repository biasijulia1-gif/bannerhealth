"use client";

import { AnimatePresence, motion } from "motion/react";
import { useTokens } from "@/motion";
import { useData, useJourney, useSession } from "@banner/hooks";
import type { Doctor } from "@banner/content/doctors";
import { booking as bookingTokens, micro } from "@banner/motion/tokens";
import { PulseRing } from "@banner/components/ui/PulseRing";

export function BookingSheet({ doctor, booking }: { doctor: Doctor; booking?: "pick" | "booked" }) {
  const { t, go, step } = useJourney();
  const session = useSession();
  const k = useTokens(bookingTokens);
  const m = useTokens(micro);
  const slot = useData((d) => d.slot);
  const b = t.booking;

  return (
    <AnimatePresence>
      {booking && (
        <motion.div
          key="booking"
          className="fixed inset-0 z-40 flex items-end justify-center p-3 @tab:items-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { ...k.overlayOut, delay: k.overlayOutDelay } }}
          transition={k.overlay}
        >
          <motion.div
            className="absolute inset-0 bg-navy-deep/35"
            style={{ backdropFilter: `blur(${k.backdropBlur}px)`, WebkitBackdropFilter: `blur(${k.backdropBlur}px)` }}
            onClick={() => step === "doctors.booking" && go("doctors.profile")}
          />
          <motion.div
            role="dialog"
            aria-modal
            aria-label={b.title}
            className="relative w-full max-w-[520px] overflow-hidden rounded-[28px] bg-white p-6 shadow-[0_40px_120px_-40px_rgba(0,33,95,0.6)] @tab:p-8"
            initial={{ y: k.sheetRise, opacity: 0, scale: k.sheetFrom }}
            animate={{ y: 0, opacity: 1, scale: 1 }}
            exit={{ y: k.sheetRise / 2, opacity: 0, scale: 0.98, transition: k.sheetExit }}
            transition={k.sheet}
          >
            <AnimatePresence mode="popLayout" initial={false}>
              {booking === "pick" ? (
                <motion.div key="pick" exit={{ opacity: 0, x: -k.swapShift, transition: k.pickExit }} className="flex flex-col gap-6">
                  <div className="flex items-center gap-4">
                    <div className="relative size-14 shrink-0 overflow-hidden rounded-full bg-mist">
                      <img src={doctor.photo} alt="" className="absolute inset-0 size-full scale-[2.2] object-cover object-[50%_18%]" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-[12px] font-semibold tracking-[0.08em] text-blue uppercase">{b.title}</p>
                      <p className="serif-text text-[26px] leading-[1.15] text-navy-deep">
                        {doctor.name}, {doctor.credential}
                      </p>
                      <p className="text-[13px] font-medium text-navy-deep/70">
                        {doctor.facility} · {b.inPerson}
                      </p>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <p className="text-[12px] font-semibold tracking-[0.08em] text-navy-deep/60 uppercase">{b.pick}</p>
                    {b.days.map((day, i) => {
                      const on = slot === i;
                      return (
                        <motion.button
                          key={day}
                          type="button"
                          data-target={`book-slot-${i}`}
                          onClick={() => session.patch({ slot: i })}
                          className={`ts-edge relative flex items-center justify-between rounded-2xl border px-5 py-4 text-left transition-colors ${
                            on ? "border-blue" : "border-navy/15 hover:border-navy/30"
                          }`}
                          initial={{ opacity: 0, y: k.slotRise }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ ...k.slot, delay: k.slotsDelay + i * k.slotsStagger }}
                        >
                          {on && <motion.span layoutId="slot-bg" className="absolute inset-0 rounded-2xl bg-ice" transition={k.slotBg} />}
                          <span className="relative text-[15px] font-semibold text-navy-deep">{day}</span>
                          <span className="relative flex items-center gap-3">
                            <span className="text-[15px] font-semibold text-blue">{b.times[i]}</span>
                            <span className={`grid size-5 place-items-center rounded-full border-2 ${on ? "border-blue" : "border-navy/25"}`}>
                              {on && <motion.span className="size-2.5 rounded-full bg-blue" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={k.radio} />}
                            </span>
                          </span>
                        </motion.button>
                      );
                    })}
                  </div>

                  <motion.button
                    type="button"
                    data-target="confirm"
                    onClick={() => step === "doctors.booking" && go("doctors.booked")}
                    className="relative h-[52px] rounded-full bg-blue text-[15px] font-semibold text-white"
                    whileHover={{ scale: m.hoverGrowSmall }}
                    whileTap={{ scale: m.tapSoft }}
                  >
                    {b.confirm}
                    <PulseRing id="confirm" />
                  </motion.button>
                </motion.div>
              ) : (
                <motion.div
                  key="booked"
                  className="flex flex-col items-center gap-5 py-4 text-center"
                  initial={{ opacity: 0, x: k.swapShift }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={k.booked}
                >
                  <BookedCheck />
                  <div className="flex flex-col gap-2">
                    <p className="serif-display text-[40px] leading-[1.05] text-blue">{b.bookedTitle}</p>
                    <p className="text-[15px] font-semibold text-navy-deep">
                      {b.days[slot]} · {b.times[slot]} · {doctor.short}
                    </p>
                    <p className="mx-auto max-w-[340px] text-[14px] font-medium text-navy-deep/70">{b.bookedBody}</p>
                  </div>
                  <motion.button
                    type="button"
                    data-target="done"
                    onClick={() => go("return")}
                    className="relative mt-2 h-[48px] w-full rounded-full border border-navy text-[15px] font-semibold text-navy-deep transition-colors hover:bg-navy hover:text-white"
                    initial={{ opacity: 0, y: k.doneRise }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ ...k.done, delay: k.doneDelay }}
                  >
                    {b.done}
                    <PulseRing id="done" />
                  </motion.button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function BookedCheck() {
  const k = useTokens(bookingTokens);
  return (
    <motion.svg width="84" height="84" viewBox="0 0 84 84" fill="none" initial={{ scale: 0.6 }} animate={{ scale: 1 }} transition={k.check}>
      <motion.circle cx="42" cy="42" r="38" fill="var(--color-ice)" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ ...k.check, delay: 0.05 }} />
      <motion.circle
        cx="42"
        cy="42"
        r="38"
        stroke="var(--color-mint)"
        strokeWidth="4"
        strokeLinecap="round"
        initial={{ pathLength: 0, rotate: -90 }}
        animate={{ pathLength: 1 }}
        transition={{ ...k.ring, delay: k.ringDelay }}
        style={{ originX: "50%", originY: "50%" }}
      />
      <motion.path
        d="M27 43.5L37.5 54L58 32"
        stroke="var(--color-blue)"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ ...k.tick, delay: k.tickDelay }}
      />
    </motion.svg>
  );
}
