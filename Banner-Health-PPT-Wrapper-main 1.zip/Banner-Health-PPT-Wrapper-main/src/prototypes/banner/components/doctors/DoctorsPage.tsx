"use client";

import { AnimatePresence, LayoutGroup, motion } from "motion/react";
import { Fragment, useState } from "react";
import { useTokens } from "@/motion";
import { useData, useFx, useInsurance, useJourney, useSession, useStepDef } from "@banner/hooks";
import { doctors as doctorList, type Doctor } from "@banner/content/doctors";
import { doctors, micro } from "@banner/motion/tokens";
import { PulseRing } from "@banner/components/ui/PulseRing";
import { BookingSheet } from "./BookingSheet";

export function DoctorsPage() {
  const { step, go } = useJourney();
  const session = useSession();
  const live = useStepDef();
  // Hold the last results-page state while the curtain covers the hand-off to the return visit.
  const [held, setHeld] = useState(live);
  if (live.page === "doctors" && live !== held) setHeld(live);
  const def = live.page === "doctors" ? live : held;
  // The step decides whether a profile is open; the user's pick decides which (Dr. Ruiz by default).
  const picked = useData((d) => d.doctor);
  const openId = def.profile ? (picked ?? "ruiz") : null;

  const close = () => {
    session.patch({ doctor: null });
    go("doctors");
  };

  const toggle = (id: string) => {
    if (openId === id) close();
    else {
      session.patch({ doctor: id });
      if (step === "doctors") go("doctors.profile");
    }
  };

  const open = doctorList.find((d) => d.id === openId) ?? doctorList[0];

  return (
    <div className="pb-24">
      <ResultsHeader />
      <section data-anchor="grid" className="px-4 @desk:px-6">
        <LayoutGroup id="doctor-grid">
          <div className="grid grid-cols-1 gap-4 @tab:grid-cols-2 @desk:grid-cols-3">
            {doctorList.map((doc, i) => (
              <Fragment key={doc.id}>
                <DoctorCard doctor={doc} index={i} open={openId === doc.id} onToggle={() => toggle(doc.id)} />
                <AnimatePresence mode="popLayout">
                  {openId === doc.id && <DoctorProfile key={`profile-${doc.id}`} doctor={doc} onClose={close} />}
                </AnimatePresence>
              </Fragment>
            ))}
          </div>
        </LayoutGroup>
      </section>
      <BookingSheet doctor={open} booking={def.booking} />
    </div>
  );
}

function ResultsHeader() {
  const { t, lang } = useJourney();
  const d = useTokens(doctors);
  const insurance = useInsurance();
  const full = t.chat.insurances[insurance];
  const short = t.results.insuranceShort[insurance] ?? full;
  const highlight = useFx((s) => s.highlight);
  const filters = t.results.filters.map((f) => f.replace("{insFull}", full));

  return (
    <section data-anchor="results" className="flex flex-col items-center px-4 pt-[72px] pb-8 @desk:px-6 @desk:pt-[64px] @desk:pb-10">
      <div className="flex flex-col items-center gap-8 @desk:gap-10">
        <motion.h1
          key={lang}
          className="serif-text max-w-[920px] text-center text-[24px] leading-[1.2] tracking-[-0.02em] text-navy-deep @tab:text-[32px] @desk:text-[40px]"
          initial={{ opacity: 0, y: d.headlineRise, filter: `blur(${d.headlineBlur}px)` }}
          animate={{ opacity: 1, y: 0, filter: "blur(0px)" }}
          transition={{ ...d.headline, delay: d.headlineDelay }}
        >
          <span className="mr-3 inline-block size-[34px] align-[-6px] @desk:size-[42px] @desk:align-[-8px]">
            <motion.img
              layoutId="maria-avatar"
              src="/p/banner/images/assistant/maria-avatar.png"
              alt=""
              width={42}
              height={42}
              className="size-full rounded-full"
              transition={d.avatar}
            />
          </span>
          {t.results.headlineA}
          <br className="hidden @desk:block" /> {t.results.headlineB.replace("{ins}", short)}
        </motion.h1>
        <div className="flex max-w-[1000px] flex-wrap justify-center gap-1.5">
          {filters.map((label, i) => {
            const lit = highlight.includes(`filter-${i}`);
            // Entrance (staggered) and highlight (immediate) live on separate layers, so a chip
            // turning off doesn't wait for its entrance delay again.
            return (
              <motion.span
                key={`${lang}-${label}`}
                className="block"
                initial={{ opacity: 0, y: d.chipRise, scale: d.chipFrom }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ ...d.chip, delay: d.chipsDelay + i * d.chipsStagger }}
              >
                <motion.span
                  data-target={`filter-${i}`}
                  className="ts-edge relative block rounded-[103px] border border-white px-6 py-3.5 text-[14px] leading-[1.2] font-bold whitespace-nowrap"
                  initial={false}
                  animate={{
                    scale: lit ? d.chipLit : 1,
                    backgroundColor: lit ? "var(--color-blue)" : "var(--color-ice)",
                    color: lit ? "#ffffff" : "var(--color-navy-deep)",
                  }}
                  transition={d.chip}
                >
                  {label}
                  <PulseRing id={`filter-${i}`} radius={103} />
                </motion.span>
              </motion.span>
            );
          })}
        </div>
      </div>
    </section>
  );
}

function Portrait({ doctor }: { doctor: Doctor }) {
  // Every crop uses object-cover, so a portrait crops instead of stretching when its card
  // changes shape (v1's "wide" crop stretched Dr. Mendoza in the right-hand column).
  const cls =
    doctor.crop === "slot"
      ? "absolute top-[-5.85%] left-[-18.1%] h-[131%] w-[131.1%] max-w-none object-cover"
      : doctor.crop === "wide"
        ? "absolute top-[-2.34%] left-[-24.69%] h-[119.88%] w-[135.28%] max-w-none object-cover"
        : doctor.crop === "bottom"
          ? "absolute inset-0 size-full object-cover object-bottom"
          : "absolute inset-0 size-full object-cover";
  return <img src={doctor.photo} alt={`${doctor.name}, ${doctor.credential}`} className={cls} draggable={false} />;
}

function DoctorCard({ doctor, index, open, onToggle }: { doctor: Doctor; index: number; open: boolean; onToggle: () => void }) {
  const { t, lang } = useJourney();
  const d = useTokens(doctors);
  const m = useTokens(micro);
  return (
    <motion.article
      layout="position"
      transition={{ ...d.card, delay: d.cardsDelay + index * d.cardsStagger, layout: d.reflow }}
      className="ts-edge relative flex flex-col gap-5 overflow-hidden rounded-[28px] bg-mist @desk:h-[680px]"
      data-target={`card-${doctor.id}`}
      initial={{ opacity: 0, y: d.cardRise, scale: d.cardFrom }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
    >
      <div className="relative h-[300px] overflow-hidden @desk:h-[342px]">
        <motion.div
          className="absolute inset-0"
          initial={{ scale: d.portraitScale }}
          animate={{ scale: 1 }}
          transition={{ ...d.portrait, delay: d.portraitDelay + index * d.portraitStagger }}
        >
          <Portrait doctor={doctor} />
        </motion.div>
        <motion.button
          type="button"
          data-target={`expand-${doctor.id}`}
          aria-expanded={open}
          aria-label={open ? t.results.collapse : t.results.expand}
          onClick={onToggle}
          className="absolute top-[18px] right-[17px] size-[50px]"
          animate={{ rotate: open ? 45 : 0 }}
          whileHover={{ scale: m.hoverGrowIcon }}
          whileTap={{ scale: m.tapIcon }}
          transition={d.expand}
        >
          <img src="/p/banner/images/icons/card-plus.svg" alt="" width={50} height={50} className="size-[50px]" />
          <PulseRing id={`expand-${doctor.id}`} />
        </motion.button>
      </div>
      <div className="flex flex-1 flex-col justify-between gap-6 px-6 pb-6 text-navy-deep @desk:h-[289px] @desk:flex-none @desk:pb-0">
        <div className="flex flex-col gap-[30px]">
          <div className="flex items-center gap-2.5">
            <img src="/p/banner/images/icons/star.svg" alt="" width={14} height={14} className="h-[13.7px] w-[14.4px]" />
            <p className="text-[12px] leading-[1.4] font-medium whitespace-nowrap">
              {doctor.rating.toFixed(1)} ({doctor.reviews} {t.results.ratings})
            </p>
          </div>
          <div className="text-[16px] leading-[1.4] font-medium @desk:text-[18px]">
            <p className="font-bold">
              {doctor.name}, {doctor.credential}
            </p>
            <p>{t.results.filters[0]}</p>
            <p>{doctor.facility}</p>
            <p>{doctor.address}</p>
            <p>{doctor.phone}</p>
          </div>
        </div>
        <p className="text-[12px] leading-[1.3] font-medium whitespace-nowrap">
          <span className="font-bold">{t.results.nextOpening} </span>
          {doctor.next[lang]}
        </p>
      </div>
    </motion.article>
  );
}

function DoctorProfile({ doctor, onClose }: { doctor: Doctor; onClose: () => void }) {
  const { t, lang, go, step } = useJourney();
  const d = useTokens(doctors);
  const m = useTokens(micro);
  const insurance = useInsurance();
  const full = t.chat.insurances[insurance];
  const meta: [string, string][] = [
    [t.results.languages, doctor.languages[lang]],
    [t.results.insurance, t.results.inNetwork.replace("{insFull}", full)],
    [t.results.education, lang === "en" ? "MD; fellowship in gastroenterology" : "MD; especialidad en gastroenterología"],
    [t.results.video, t.results.available],
  ];
  const item = (i: number) => ({
    initial: { opacity: 0, y: d.itemRise },
    animate: { opacity: 1, y: 0 },
    transition: { ...d.items, delay: d.itemsDelay + i * d.itemsStagger },
  });

  return (
    <motion.aside
      layout="position"
      className="relative flex min-h-[560px] flex-col overflow-hidden rounded-[28px] bg-mist px-6 pt-[62px] pb-6 text-navy-deep @desk:h-[680px]"
      initial={{ opacity: 0, clipPath: "inset(0% 100% 0% 0% round 28px)" }}
      animate={{ opacity: 1, clipPath: "inset(0% 0% 0% 0% round 28px)" }}
      exit={{ opacity: 0, clipPath: "inset(0% 100% 0% 0% round 28px)", transition: d.profileClose }}
      transition={{ ...d.profileOpen, layout: d.reflow }}
    >
      <button
        type="button"
        aria-label={t.results.collapse}
        onClick={onClose}
        className="absolute top-[18px] right-[17px] size-[50px] rotate-[135deg] transition-transform hover:rotate-[225deg]"
      >
        <img src="/p/banner/images/icons/card-close.svg" alt="" width={50} height={50} className="size-[50px]" />
      </button>

      <div className="flex flex-col gap-8 text-[16px] leading-[1.4] font-medium">
        <motion.div {...item(0)}>
          <p className="font-bold">{t.results.about}</p>
          <p>{doctor.about[lang]}</p>
        </motion.div>
        <motion.div {...item(1)} className="max-w-[245px]">
          <p className="font-bold">{t.results.focus}</p>
          <p>{doctor.focus[lang]}</p>
        </motion.div>
        <motion.dl {...item(2)} className="flex max-w-[190px] flex-col gap-[14px] text-[12px] leading-[1.2] font-semibold tracking-[-0.01em] text-navy-deep/70">
          {meta.map(([k, v]) => (
            <div key={k}>
              <dt>{k}</dt>
              <dd>{v}</dd>
            </div>
          ))}
        </motion.dl>
      </div>

      <div className="mt-auto flex justify-end pt-6">
        <motion.button
          type="button"
          data-target="schedule"
          onClick={() => step === "doctors.profile" && go("doctors.booking")}
          className="relative h-[42px] rounded-[103px] border border-white bg-white px-[23px] text-[12px] leading-[1.2] font-bold whitespace-nowrap text-navy-deep shadow-[0_8px_24px_-12px_rgba(0,33,95,0.4)]"
          {...item(3)}
          whileHover={{ scale: m.hoverGrow }}
          whileTap={{ scale: m.tapButton }}
        >
          {t.results.schedule}
          <PulseRing id="schedule" radius={103} />
        </motion.button>
      </div>
    </motion.aside>
  );
}
