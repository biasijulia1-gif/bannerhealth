"use client";

import { animate, useInView, useMotionValue, useTransform, motion } from "motion/react";
import { useEffect, useRef } from "react";
import { useTokens } from "@/motion";
import { text } from "@banner/motion/tokens";

export function CountUp({ value, suffix = "", className }: { value: number; suffix?: string; className?: string }) {
  const t = useTokens(text);
  const ref = useRef<HTMLSpanElement>(null);
  const seen = useInView(ref, { once: true, margin: "0px 0px -15% 0px" });
  const mv = useMotionValue(0);
  const display = useTransform(mv, (v) => `${Math.round(v)}${suffix}`);
  const transition = t.countUp;

  useEffect(() => {
    if (!seen) return;
    const controls = animate(mv, value, transition);
    return () => controls.stop();
  }, [seen, mv, value, transition]);

  return (
    <motion.span ref={ref} className={className}>
      {display}
    </motion.span>
  );
}
