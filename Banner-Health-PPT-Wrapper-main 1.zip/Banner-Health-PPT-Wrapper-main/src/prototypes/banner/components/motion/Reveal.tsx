"use client";

import { motion, type HTMLMotionProps } from "motion/react";
import { useTokens } from "@/motion";
import { text } from "@banner/motion/tokens";

type Props = HTMLMotionProps<"div"> & { delay?: number; y?: number };

// Fade-up when scrolled into view (once). `y` overrides the token's rise for one use.
export function Reveal({ delay = 0, y, children, ...rest }: Props) {
  const t = useTokens(text);
  return (
    <motion.div
      initial={{ opacity: 0, y: y ?? t.revealRise, filter: `blur(${t.revealBlur}px)` }}
      whileInView={{ opacity: 1, y: 0, filter: "blur(0px)" }}
      viewport={{ once: true, margin: "0px 0px -12% 0px" }}
      transition={{ ...t.reveal, delay }}
      {...rest}
    >
      {children}
    </motion.div>
  );
}
