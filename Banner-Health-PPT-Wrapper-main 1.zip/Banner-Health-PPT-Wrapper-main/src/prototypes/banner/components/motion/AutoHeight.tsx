"use client";

import { motion, type Transition } from "motion/react";
import { useLayoutEffect, useRef, useState } from "react";
import { curves, useTokens } from "@/motion";

// Springs its height to the measured content height. Avoids the child distortion
// that a scale-based `layout` animation causes on rounded, blurred panels.
export function AutoHeight({
  children,
  className,
  transition,
  style,
}: {
  children: React.ReactNode;
  className?: string;
  transition?: Transition;
  style?: React.CSSProperties;
}) {
  const c = useTokens(curves);
  const inner = useRef<HTMLDivElement>(null);
  const [height, setHeight] = useState<number | "auto">("auto");

  useLayoutEffect(() => {
    const el = inner.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setHeight(el.offsetHeight));
    ro.observe(el);
    setHeight(el.offsetHeight);
    return () => ro.disconnect();
  }, []);

  return (
    <motion.div className={className} style={{ overflow: "hidden", ...style }} initial={false} animate={{ height }} transition={transition ?? c.panel}>
      <div ref={inner}>{children}</div>
    </motion.div>
  );
}
