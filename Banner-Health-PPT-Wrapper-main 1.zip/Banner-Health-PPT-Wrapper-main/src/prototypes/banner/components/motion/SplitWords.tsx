"use client";

import { motion, useInView } from "motion/react";
import { useRef } from "react";
import { useTokens } from "@/motion";
import { text as textTokens } from "@banner/motion/tokens";

type Props = {
  text: string;
  className?: string;
  delay?: number;
  stagger?: number;
  /** Animate when scrolled into view instead of on mount. */
  inView?: boolean;
  as?: "p" | "h1" | "h2" | "h3" | "span";
};

// Masked word-by-word rise with a blur-in, used for every serif headline.
export function SplitWords({ text, className, delay = 0, stagger, inView = false, as = "p" }: Props) {
  const t = useTokens(textTokens);
  const ref = useRef<HTMLElement>(null);
  const seen = useInView(ref, { once: true, margin: "0px 0px -10% 0px" });
  const play = inView ? seen : true;
  const Tag = motion[as];
  const words = text.split(" ");
  const step = stagger ?? t.wordStagger;

  return (
    <Tag ref={ref as never} className={className} aria-label={text}>
      {words.map((word, i) => (
        <span key={`${word}-${i}`} aria-hidden className="inline-block overflow-hidden pb-[0.12em] -mb-[0.12em] align-top">
          <motion.span
            className="inline-block"
            initial={{ y: "105%", opacity: 0, filter: `blur(${t.wordBlur}px)` }}
            animate={play ? { y: "0%", opacity: 1, filter: "blur(0px)" } : undefined}
            transition={{ ...t.word, delay: delay + i * step }}
          >
            {word}
          </motion.span>
          {i < words.length - 1 ? " " : null}
        </span>
      ))}
    </Tag>
  );
}
