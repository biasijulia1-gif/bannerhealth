"use client";

import { AnimatePresence, motion } from "motion/react";
import { useTokens } from "@/motion";
import { text as textTokens } from "@banner/motion/tokens";

// Swaps text with a vertical roll (short labels) when the value changes, e.g. EN → ES.
export function RollText({ text, className, delay = 0 }: { text: string; className?: string; delay?: number }) {
  const t = useTokens(textTokens);
  return (
    <span className={`relative inline-grid overflow-hidden align-bottom ${className ?? ""}`}>
      <AnimatePresence initial={false} mode="popLayout">
        <motion.span
          key={text}
          className="col-start-1 row-start-1 block"
          initial={{ y: "110%", opacity: 0 }}
          animate={{ y: "0%", opacity: 1 }}
          exit={{ y: "-110%", opacity: 0 }}
          transition={{ ...t.roll, delay }}
        >
          {text}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}

// Cross-fades longer copy with a soft blur when it changes.
export function FadeText({ text, className, delay = 0 }: { text: string; className?: string; delay?: number }) {
  const t = useTokens(textTokens);
  return (
    <span className={`grid ${className ?? ""}`}>
      <AnimatePresence initial={false} mode="popLayout">
        <motion.span
          key={text}
          className="col-start-1 row-start-1 block"
          initial={{ opacity: 0, filter: `blur(${t.fadeBlur}px)`, y: t.fadeShift }}
          animate={{ opacity: 1, filter: "blur(0px)", y: 0 }}
          exit={{ opacity: 0, filter: `blur(${t.fadeBlur}px)`, y: -t.fadeShift }}
          transition={{ ...t.fade, delay }}
        >
          {text}
        </motion.span>
      </AnimatePresence>
    </span>
  );
}
