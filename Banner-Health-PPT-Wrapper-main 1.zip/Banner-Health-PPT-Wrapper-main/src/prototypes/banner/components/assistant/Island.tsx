"use client";

import { AnimatePresence, animate, motion, useMotionTemplate, useMotionValue } from "motion/react";
import { useCallback, useEffect, useRef } from "react";
import { useTime, useTokens } from "@/motion";
import { useFx, useInstance, useJourney, useSession, useStepDef } from "@banner/hooks";
import type { StepId } from "@banner/journey/steps";
import { island, micro, page } from "@banner/motion/tokens";
import { FadeText, RollText } from "@banner/components/motion/RollText";
import { AutoHeight } from "@banner/components/motion/AutoHeight";
import { PulseRing } from "@banner/components/ui/PulseRing";
import { useTypewriter } from "./useTypewriter";
import { SymptomChecker } from "./SymptomChecker";
import { TriageResult } from "./TriageResult";
import { Chat } from "./Chat";

const CHAT_HEIGHT = 575;

export function Island() {
  const { t, step, go } = useJourney();
  const session = useSession();
  const i = useTokens(island);
  const p = useTokens(page);
  const def = useStepDef();
  const { phase, flow } = def;
  const active = phase !== "idle";
  const chatOpen = flow === "findDr" && phase !== "compose";
  const cardOpen = phase === "howLong" || phase === "warning" || phase === "result";
  const stepRef = useRef(step);

  useEffect(() => {
    stepRef.current = step;
  }, [step]);

  // The glass blur rides a motion value so it eases in and out with the tint, instead of
  // popping on and off as a style toggle.
  const blur = useMotionValue(0);
  const backdrop = useMotionTemplate`blur(${blur}px)`;
  useEffect(() => {
    const controls = animate(blur, active ? i.glassBlur : 0, i.tray);
    return () => controls.stop();
  }, [active, blur, i.glassBlur, i.tray]);

  const message =
    phase === "howLong" || phase === "warning"
      ? t.island.sorry
      : phase === "result"
        ? t.island.goUrgent
        : phase === "searching"
          ? t.island.searching
          : t.island.greeting;

  const open = () => {
    if (step === "home") {
      session.patch({ warnings: [] });
      go("triage.compose");
    } else if (step === "followup") go("finddr.compose");
  };

  const close = () => {
    if (flow === "triage" && phase !== "result") go("home");
    else go("followup");
  };

  const advanceMs = p.clickAdvance * 1000;
  const submit = useCallback(() => {
    const from = stepRef.current;
    const target: StepId = flow === "triage" ? "triage.howLong" : "finddr.insurance";
    window.setTimeout(() => {
      if (stepRef.current === from) go(target);
    }, advanceMs);
  }, [flow, go, advanceMs]);

  const depth = i.shadowDepth;
  const shadow = (alpha: number) => `0 ${30 * depth}px ${80 * depth}px -30px rgba(0,32,91,${alpha})`;

  return (
    <div className="pointer-events-none absolute inset-x-0 top-0 z-30 flex justify-center px-2 pt-2 @desk:px-0 @desk:pt-4">
      <motion.div
        className="relative flex w-full flex-col gap-2 rounded-[28px] p-2 @desk:w-[522px]"
        style={{ backdropFilter: backdrop, WebkitBackdropFilter: backdrop }}
        initial={false}
        animate={{
          backgroundColor: `rgba(225,225,225,${active ? i.tint : 0})`,
          boxShadow: shadow(active ? 0.45 : 0),
        }}
        transition={i.tray}
      >
        <Header visible={active} message={message} onClose={close} closeLabel={t.island.close} />

        <BluePanel chat={chatOpen} phase={phase} onOpen={open} onSubmit={submit} />

        <AnimatePresence>
          {cardOpen && (
            <motion.div
              key="triage-card"
              className="pointer-events-auto"
              initial={{ opacity: 0, y: -i.cardRise, scale: i.cardScale }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -i.cardRise * 0.625, scale: i.cardScale, transition: i.cardExit }}
              transition={i.card}
            >
              <AutoHeight className="rounded-[20px]" transition={i.panel}>
                <AnimatePresence mode="popLayout" initial={false}>
                  {phase === "result" ? (
                    <motion.div
                      key="result"
                      initial={{ opacity: 0, filter: `blur(${i.resultBlur}px)` }}
                      animate={{ opacity: 1, filter: "blur(0px)" }}
                      exit={{ opacity: 0 }}
                      transition={i.result}
                    >
                      <TriageResult />
                    </motion.div>
                  ) : (
                    <motion.div key="checker" exit={{ opacity: 0, filter: `blur(${i.resultBlur}px)`, transition: i.cardExit }}>
                      <SymptomChecker phase={phase as "howLong" | "warning"} />
                    </motion.div>
                  )}
                </AnimatePresence>
              </AutoHeight>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </div>
  );
}

function Header({
  visible,
  message,
  onClose,
  closeLabel,
}: {
  visible: boolean;
  message: string;
  onClose: () => void;
  closeLabel: string;
}) {
  const i = useTokens(island);
  return (
    <motion.div
      className="flex min-h-[58px] items-center justify-between gap-3 p-2"
      style={{ pointerEvents: visible ? "auto" : "none" }}
      initial={false}
      animate={{ opacity: visible ? 1 : 0, y: visible ? 0 : -i.headerRise }}
      transition={{ ...i.header, delay: visible ? i.headerDelay : 0 }}
      aria-hidden={!visible}
    >
      <div className="flex min-w-0 items-center gap-2">
        <div className="size-[42px] shrink-0">
          {visible && (
            <motion.img
              layoutId="maria-avatar"
              src="/p/banner/images/assistant/maria-avatar.png"
              alt="Maria"
              width={42}
              height={42}
              className="size-[42px] rounded-full"
              transition={i.avatar}
            />
          )}
        </div>
        <FadeText text={message} className="text-[14px] leading-[1.2] font-semibold text-assist @desk:whitespace-nowrap" />
      </div>
      <button
        type="button"
        data-target="close"
        aria-label={closeLabel}
        onClick={onClose}
        className="relative grid size-[42px] shrink-0 place-items-center rounded-full border border-assist/15 transition-colors hover:bg-white/60"
      >
        <img src="/p/banner/images/icons/close.svg" alt="" width={20} height={20} className="size-5" />
      </button>
    </motion.div>
  );
}

function BluePanel({
  chat,
  phase,
  onOpen,
  onSubmit,
}: {
  chat: boolean;
  phase: ReturnType<typeof useStepDef>["phase"];
  onOpen: () => void;
  onSubmit: () => void;
}) {
  const i = useTokens(island);
  const bordered = phase === "idle" || phase === "compose";
  return (
    <motion.div
      className="pointer-events-auto relative overflow-hidden bg-blue"
      initial={false}
      animate={{
        height: chat ? CHAT_HEIGHT : "auto",
        borderRadius: chat ? 28 : 103,
        borderColor: bordered ? "rgba(32,219,155,1)" : "rgba(32,219,155,0)",
      }}
      style={{ borderWidth: 1, borderStyle: "solid" }}
      transition={i.panel}
    >
      <AnimatePresence mode="popLayout" initial={false}>
        {chat ? (
          <motion.div
            key="chat"
            className="h-full"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, transition: i.chatOut }}
            transition={{ ...i.chat, delay: i.chatDelay }}
          >
            <Chat />
          </motion.div>
        ) : (
          <motion.div key="bar" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0, transition: i.barOut }} transition={i.bar}>
            <SearchBar phase={phase} onOpen={onOpen} onSubmit={onSubmit} />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function SearchBar({
  phase,
  onOpen,
  onSubmit,
}: {
  phase: ReturnType<typeof useStepDef>["phase"];
  onOpen: () => void;
  onSubmit: () => void;
}) {
  const { t, step } = useJourney();
  const i = useTokens(island);
  const s = useTime();
  const { input } = useInstance();
  const def = useStepDef();
  const placeholderIdx = useFx((f) => f.placeholder);
  const a11y = useFx((f) => f.a11yFocus);
  const query = def.flow === "findDr" ? t.queries.findDr : t.queries.triage;
  const composing = phase === "compose";
  const typer = useTypewriter(query, {
    // Characters per second, sped up or slowed down with the global speed.
    cps: (def.flow === "findDr" ? i.typeCpsFindDr : i.typeCpsTriage) / s(1),
    delay: i.typeDelay,
    active: composing,
  });

  const send = useCallback(() => {
    typer.finish();
    onSubmit();
  }, [typer, onSubmit]);

  // Real keystrokes advance the scripted query; Enter sends. Off inside the deck, which owns the
  // keyboard (so presenter keys like A never type into the search bar).
  useEffect(() => {
    if (!composing || !input.keyboard) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey || e.altKey) return;
      if (e.key === "Enter") send();
      else if (e.key.length === 1) typer.bump();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [composing, input.keyboard, send, typer]);

  const idle = phase === "idle";
  const placeholder = step.startsWith("return") ? t.island.returnPlaceholder : t.island.placeholder;
  const idleText = placeholderIdx === null ? placeholder : t.island.prompts[placeholderIdx];

  const text = idle ? idleText : composing ? typer.shown : query;
  const textColor = idle ? "text-white/80" : composing ? "text-paper" : "text-paper/70";

  const Inner = (
    <div className="flex h-[40px] items-center gap-2 @desk:h-[42px]">
      <div className="flex min-w-0 flex-1 items-center gap-[9px] pl-4">
        {idle && <Caret />}
        <span className={`truncate text-[14px] leading-[23px] font-semibold ${textColor}`}>
          {idle ? <RollText text={text} /> : text}
          {composing && <Caret inline />}
        </span>
      </div>
      <ActionButton phase={phase} onSend={send} sendLabel={t.island.send} />
    </div>
  );

  if (idle) {
    return (
      <button
        type="button"
        data-target="island"
        data-a11y-focus={a11y === "island"}
        onClick={onOpen}
        className="group relative block w-full rounded-[103px] p-1 text-left @desk:p-2"
      >
        {Inner}
        <span className="pointer-events-none absolute inset-0 rounded-[103px] bg-white/0 transition-colors group-hover:bg-white/5" />
        <PulseRing id="island" />
      </button>
    );
  }
  return <div className="p-1 @desk:p-2">{Inner}</div>;
}

function ActionButton({ phase, onSend, sendLabel }: { phase: string; onSend: () => void; sendLabel: string }) {
  const i = useTokens(island);
  const m = useTokens(micro);
  const composing = phase === "compose";
  const submitted = phase !== "idle" && !composing;
  const content = (
    <AnimatePresence mode="popLayout" initial={false}>
      {composing ? (
        <motion.img
          key="arrow"
          src="/p/banner/images/icons/send-arrow.svg"
          alt=""
          width={11}
          height={9}
          className="h-[8.55px] w-[11.03px]"
          initial={{ x: -i.arrowShift, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          exit={{ x: i.arrowShift, opacity: 0 }}
          transition={i.arrow}
        />
      ) : (
        <motion.img
          key="spark"
          src="/p/banner/images/icons/ai-chat.svg"
          alt=""
          width={17}
          height={17}
          className="h-[16.7px] w-[17.5px]"
          initial={{ scale: 0.6, opacity: 0, rotate: -30 }}
          animate={{ scale: 1, opacity: 1, rotate: 0 }}
          exit={{ scale: 0.6, opacity: 0 }}
          transition={i.spark}
        />
      )}
    </AnimatePresence>
  );

  const circle = `relative grid size-[40px] shrink-0 place-items-center rounded-full transition-colors duration-300 @desk:size-[42px] ${
    submitted ? "bg-transparent" : "bg-navy-deep"
  }`;

  if (composing) {
    // The breathing loop lives on the inner circle so the press keeps its own quick response
    // (in v1 the press inherited the slow, repeating breathe transition).
    return (
      <motion.button
        type="button"
        data-target="send"
        aria-label={sendLabel}
        onClick={onSend}
        className="relative grid shrink-0 place-items-center rounded-full"
        whileTap={{ scale: m.tapFirm, transition: m.press }}
      >
        <motion.span
          className={circle}
          animate={{ scale: [1, i.breatheScale, 1] }}
          transition={{ ...i.breathe, repeat: Infinity, repeatDelay: i.breatheRest }}
        >
          {content}
        </motion.span>
        <PulseRing id="send" />
      </motion.button>
    );
  }
  return (
    <span className={circle} aria-hidden>
      {content}
    </span>
  );
}

function Caret({ inline = false }: { inline?: boolean }) {
  return (
    <motion.span
      aria-hidden
      className={inline ? "ml-[2px] inline-block h-[17px] w-px translate-y-[3px] bg-white" : "block h-[26px] w-px bg-white"}
      animate={{ opacity: [1, 1, 0, 0] }}
      transition={{ duration: 1, repeat: Infinity, times: [0, 0.5, 0.5, 1], ease: "linear" }}
    />
  );
}
