"use client";

import { useEffect, useRef, useState } from "react";
import { justSettled } from "@/motion";

// Types `text` at `cps` after `delay` seconds whenever `active` turns on (or the text changes).
// `bump()` advances one character (real keystrokes), `finish()` completes instantly.
// Activating during an instant jump (← in the deck, deep links) starts fully typed.
export function useTypewriter(text: string, { cps, delay, active }: { cps: number; delay: number; active: boolean }) {
  const startCount = () => (active && !justSettled() ? 0 : text.length);
  const [session, setSession] = useState({ active, text });
  const [count, setCount] = useState(startCount);

  // Reset when the composer reopens or the query changes (derived-state pattern).
  if (session.active !== active || session.text !== text) {
    setSession({ active, text });
    setCount(startCount());
  }

  const countRef = useRef(count);
  useEffect(() => {
    countRef.current = count;
  }, [count]);

  useEffect(() => {
    if (!active || countRef.current >= text.length) return;
    let raf = 0;
    const from = countRef.current;
    const start = performance.now() + delay * 1000;
    const tick = (now: number) => {
      const typed = from + Math.floor((Math.max(0, now - start) / 1000) * cps);
      const next = Math.min(text.length, Math.max(countRef.current, typed));
      if (next !== countRef.current) {
        countRef.current = next;
        setCount(next);
      }
      if (next < text.length) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [active, text, cps, delay]);

  return {
    shown: text.slice(0, active ? count : text.length),
    done: count >= text.length,
    bump: () => setCount((c) => Math.min(text.length, c + 1)),
    finish: () => setCount(text.length),
  };
}
