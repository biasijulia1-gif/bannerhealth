"use client";

import { AnimatePresence, motion } from "motion/react";
import { useEffect, useRef } from "react";
import { useTokens } from "@/motion";
import { useData, useJourney, useSession, useTriageAnswers } from "@banner/hooks";
import { toggleWarning } from "@banner/journey/answers";
import type { StepId } from "@banner/journey/steps";
import { micro, page, triage } from "@banner/motion/tokens";
import { PulseRing } from "@banner/components/ui/PulseRing";

type Phase = "howLong" | "warning";

export function SymptomChecker({ phase }: { phase: Phase }) {
  const { t, go } = useJourney();
  const session = useSession();
  const tr = useTokens(triage);
  const index = phase === "howLong" ? 0 : 1;

  return (
    <div className="rounded-[20px] bg-paper px-2 pt-4 pb-6">
      <div className="flex items-center gap-2 pr-2 pl-4">
        <p className="flex-1 text-[14px] leading-[23px] font-semibold text-blue">{t.symptom.title}</p>
        <button
          type="button"
          aria-label={t.symptom.restart}
          onClick={() => {
            session.patch({ warnings: [], howLong: null });
            go("triage.howLong");
          }}
          className="grid size-[42px] place-items-center rounded-full text-blue transition-colors hover:bg-blue/5"
        >
          <RestartIcon />
        </button>
      </div>

      <div className="mt-2 flex flex-col gap-4 px-4">
        <Progress index={index} labels={t.symptom.steps} />
        <AnimatePresence mode="popLayout" initial={false}>
          <motion.div
            key={phase}
            initial={{ opacity: 0, x: tr.questionShift, filter: `blur(${tr.questionBlur}px)` }}
            animate={{ opacity: 1, x: 0, filter: "blur(0px)" }}
            exit={{ opacity: 0, x: -tr.questionShift, filter: `blur(${tr.questionBlur}px)`, transition: tr.questionExit }}
            transition={tr.question}
          >
            {phase === "howLong" ? <HowLong /> : <Warnings />}
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}

function Progress({ index, labels }: { index: number; labels: string[] }) {
  const tr = useTokens(triage);
  return (
    <div className="flex w-full gap-2 @desk:w-[414.677px]">
      {labels.map((label, i) => {
        const done = i < index;
        const current = i === index;
        return (
          <div key={label} className="flex min-w-0 flex-1 flex-col gap-2">
            <div className="relative h-1 overflow-hidden rounded-full bg-blue/20">
              <motion.div
                className="absolute inset-0 origin-left rounded-full bg-blue"
                initial={false}
                animate={{ scaleX: current ? 1 : 0 }}
                transition={{ ...tr.progress, delay: current ? tr.progressDelay : 0 }}
              />
            </div>
            <div className="flex h-3 items-center gap-1">
              <AnimatePresence mode="popLayout" initial={false}>
                {current && (
                  <motion.p
                    key="label"
                    className="text-[10px] leading-[1.2] font-semibold whitespace-nowrap text-blue uppercase"
                    initial={{ opacity: 0, y: tr.labelShift }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -tr.labelShift }}
                    transition={{ ...tr.label, delay: tr.labelDelay }}
                  >
                    {label}
                  </motion.p>
                )}
                {done && (
                  <motion.svg key="check" width="12" height="12" viewBox="0 0 12 12" fill="none" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
                    <motion.path
                      d="M2 6.33333L4.46154 9L10 3"
                      stroke="#004FAB"
                      strokeOpacity="0.4"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      initial={{ pathLength: 0 }}
                      animate={{ pathLength: 1 }}
                      transition={tr.check}
                    />
                  </motion.svg>
                )}
              </AnimatePresence>
            </div>
          </div>
        );
      })}
    </div>
  );
}

/** Advances to `target` after the pressed state has had a moment to read. */
function useAdvance() {
  const { go, step } = useJourney();
  const p = useTokens(page);
  const stepRef = useRef(step);
  useEffect(() => {
    stepRef.current = step;
  }, [step]);
  return (target: StepId) => {
    const from = stepRef.current;
    window.setTimeout(() => {
      if (stepRef.current === from) go(target);
    }, p.clickAdvance * 1000);
  };
}

function HowLong() {
  const { t } = useJourney();
  const session = useSession();
  const tr = useTokens(triage);
  const m = useTokens(micro);
  const picked = useData((d) => d.howLong);
  const advance = useAdvance();

  return (
    <div className="flex flex-col gap-4">
      <h3 className="serif-text max-w-[290px] pr-10 text-[26px] leading-[1.2] text-blue @desk:text-[30px]">{t.symptom.howLong}</h3>
      <div className="flex flex-wrap gap-2">
        {t.symptom.howLongOptions.map((label, i) => {
          const on = picked === i;
          return (
            <motion.button
              key={label}
              type="button"
              data-target={`howlong-${i}`}
              onClick={() => {
                session.patch({ howLong: i });
                advance("triage.warning");
              }}
              className={`relative rounded-full border border-blue/20 px-6 py-4 transition-colors duration-200 ${on ? "text-white" : "text-blue hover:bg-blue/5"}`}
              initial={{ opacity: 0, y: tr.optionRise }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ ...tr.option, delay: tr.optionsDelay + i * tr.optionsStagger }}
              whileTap={{ scale: m.tap, transition: m.press }}
            >
              {on && <motion.span layoutId="howlong-pill" className="absolute -inset-px rounded-full bg-blue" transition={tr.pill} />}
              <span className="trim-cap relative block text-[14px] leading-none font-semibold whitespace-nowrap">{label}</span>
              <PulseRing id={`howlong-${i}`} />
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}

function Warnings() {
  const { t } = useJourney();
  const session = useSession();
  const tr = useTokens(triage);
  const m = useTokens(micro);
  const { warnings } = useTriageAnswers();
  const advance = useAdvance();

  return (
    <div className="flex flex-col gap-4">
      <div className="flex flex-col gap-2 pr-10 text-blue">
        <h3 className="serif-text max-w-[337px] text-[26px] leading-[1.2] @desk:text-[30px]">{t.symptom.warning}</h3>
        <p className="text-[14px] leading-[1.2]">{t.symptom.warningHint}</p>
      </div>
      <div className="flex flex-col gap-2">
        {t.symptom.warnings.map((label, i) => {
          const on = warnings.includes(i);
          return (
            <motion.button
              key={label}
              type="button"
              role="checkbox"
              aria-checked={on}
              data-target={`warning-${i}`}
              onClick={() => session.patch({ warnings: toggleWarning(warnings, i) })}
              className={`relative flex min-h-[50px] w-full items-center gap-3 rounded-full border border-navy/20 px-6 py-3 text-left transition-colors duration-200 ${
                on ? "bg-blue text-white" : "text-blue hover:bg-blue/5"
              }`}
              initial={{ opacity: 0, x: tr.warningShift }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ ...tr.option, delay: tr.warningsDelay + i * tr.warningsStagger }}
              whileTap={{ scale: m.tapRow, transition: m.press }}
            >
              <span className={`relative grid size-4 shrink-0 place-items-center rounded-[2px] border border-blue/60 ${on ? "bg-white" : ""}`}>
                <svg width="9" height="7" viewBox="0 0 9 7" fill="none" className="overflow-visible">
                  <motion.path
                    d="M0.5 3.83333L2.96154 6.5L8.5 0.5"
                    stroke="#004FAB"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    initial={false}
                    animate={{ pathLength: on ? 1 : 0, opacity: on ? 1 : 0 }}
                    transition={tr.tick}
                  />
                </svg>
              </span>
              <span className="trim-cap text-[15px] leading-tight font-semibold @desk:text-[16px] @desk:leading-none">{label}</span>
              <PulseRing id={`warning-${i}`} />
            </motion.button>
          );
        })}
        <div className="flex justify-end pt-2.5">
          <motion.button
            type="button"
            data-target="continue"
            onClick={() => advance("triage.result")}
            disabled={warnings.length === 0}
            className="relative flex h-[42px] items-center gap-2 rounded-[6px] bg-teal p-4 text-white transition-opacity disabled:opacity-40"
            whileTap={{ scale: m.tapButton, transition: m.press }}
          >
            <span className="trim-cap text-[14px] leading-none font-semibold whitespace-nowrap">{t.symptom.continue}</span>
            <PulseRing id="continue" radius={8} />
          </motion.button>
        </div>
      </div>
    </div>
  );
}

// Lucide-style rotate-ccw; the Figma export of this icon has broken path coordinates.
function RestartIcon() {
  return (
    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8" />
      <path d="M3 3v5h5" />
    </svg>
  );
}
