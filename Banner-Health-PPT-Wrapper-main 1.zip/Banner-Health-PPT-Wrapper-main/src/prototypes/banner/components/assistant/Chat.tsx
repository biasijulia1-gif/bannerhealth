"use client";

import { AnimatePresence, motion } from "motion/react";
import { useEffect, useRef, useState } from "react";
import { justSettled, useTokens } from "@/motion";
import { useData, useJourney, useSession, useStepDef } from "@banner/hooks";
import type { StepId } from "@banner/journey/steps";
import { chat, micro, page } from "@banner/motion/tokens";
import { PulseRing } from "@banner/components/ui/PulseRing";

const OR_TYPE = 6;

export function Chat() {
  const { t, go, step } = useJourney();
  const session = useSession();
  const c = useTokens(chat);
  const p = useTokens(page);
  const { phase } = useStepDef();
  const insurance = useData((d) => d.insurance);
  const picked = useData((d) => d.insurancePicked);
  const stepRef = useRef(step);

  useEffect(() => {
    stepRef.current = step;
  }, [step]);

  const atLeast = (target: "insurance" | "location" | "searching") => {
    const order = ["insurance", "location", "searching"];
    return order.indexOf(phase) >= order.indexOf(target);
  };

  const advance = (target: StepId) => {
    const from = stepRef.current;
    window.setTimeout(() => {
      if (stepRef.current === from) go(target);
    }, p.clickAdvance * 1000);
  };

  const selected = phase === "insurance" ? picked : insurance;

  return (
    <div className="relative flex h-full flex-col gap-2 px-2 pt-6 pb-2">
      {/* Bottom-anchored: new turns push the whole column up as one unit, and older
          messages slide under the top fade instead of scrolling. */}
      <div className="flex min-h-0 flex-1 flex-col justify-end overflow-hidden px-2">
        <motion.div layout="position" transition={c.column} className="flex flex-col py-1.5">
          <UserBubble text={t.queries.findDr} delay={c.userDelay} />

          <div className="mt-10 flex flex-col items-start gap-2.5">
            <MariaBubble text={t.chat.askInsurance} delay={c.askDelay} />
            <div className="flex flex-wrap gap-2">
              {t.chat.insurances.map((label, i) => (
                <Chip
                  key={label}
                  target={`insurance-${i}`}
                  label={label}
                  on={selected === i}
                  muted={selected !== null && selected !== i}
                  delay={c.chipsDelay + i * c.chipsStagger}
                  disabled={phase !== "insurance" || i === OR_TYPE}
                  onClick={() => {
                    session.patch({ insurancePicked: i, insurance: i });
                    advance("finddr.location");
                  }}
                />
              ))}
            </div>
          </div>

          {atLeast("location") && (
            <div className="mt-10 flex flex-col items-start gap-2.5">
              <MariaBubble text={t.chat.askLocation} delay={c.locationDelay} />
              <div className="flex flex-wrap gap-2">
                {t.chat.replies.map((label, i) => {
                  const chosen = atLeast("searching");
                  return (
                    <Chip
                      key={label}
                      target={`reply-${i}`}
                      label={label}
                      on={chosen && i === 0}
                      muted={chosen && i !== 0}
                      delay={c.chipsDelay + i * c.replyStagger}
                      disabled={phase !== "location" || i !== 0}
                      onClick={() => advance("finddr.searching")}
                    />
                  );
                })}
              </div>
            </div>
          )}

          {atLeast("searching") && (
            <div className="mt-8">
              <motion.div
                className="inline-flex rounded-tl-[20px] rounded-tr-[20px] rounded-br-[20px] bg-white/[0.06] px-8 py-3"
                initial={{ opacity: 0, y: c.typingRise }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ ...c.bubble, delay: c.typingDelay }}
              >
                <TypingDots />
              </motion.div>
            </div>
          )}
        </motion.div>
      </div>

      <div className="rounded-full border border-[rgba(203,230,248,0.7)]">
        <div className="flex items-center gap-[9px] rounded-full bg-blue p-1.5">
          <p className="flex-1 truncate pl-6 text-[14px] leading-[23px] font-semibold text-white/80">
            {phase === "insurance" ? t.chat.typeInsurance : t.chat.inputPlaceholder}
          </p>
          <span className="grid size-[42px] place-items-center rounded-full bg-navy-deep opacity-50">
            <img src="/p/banner/images/icons/send-arrow.svg" alt="" width={11} height={9} className="h-[8.55px] w-[11.03px]" />
          </span>
        </div>
      </div>

      <div
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-20 rounded-t-[28px]"
        style={{ backgroundImage: "linear-gradient(180deg, var(--color-blue) 13%, color-mix(in srgb, var(--color-blue) 0%, transparent) 81%)" }}
      />
    </div>
  );
}

function UserBubble({ text, delay }: { text: string; delay: number }) {
  const c = useTokens(chat);
  return (
    <motion.div
      className="flex justify-end"
      initial={{ opacity: 0, x: c.userShift, scale: c.userFrom }}
      animate={{ opacity: 1, x: 0, scale: 1 }}
      transition={{ ...c.bubble, delay }}
      style={{ transformOrigin: "100% 100%" }}
    >
      <p className="max-w-[248px] rounded-tl-[30px] rounded-tr-[30px] rounded-br-[4px] rounded-bl-[30px] bg-navy-deep px-8 py-4 text-[16px] leading-[23px] font-semibold text-chat-ink">
        {text}
      </p>
    </motion.div>
  );
}

// The bubble takes its final size immediately (text laid out but invisible), so swapping the
// typing dots for the message never shifts the conversation. The reply then streams in by word.
function MariaBubble({ text, delay }: { text: string; delay: number }) {
  const c = useTokens(chat);
  const [typing, setTyping] = useState(() => !justSettled());
  const words = text.split(" ");
  const typingMs = (delay + c.typingFor) * 1000;

  useEffect(() => {
    if (!typing) return;
    const id = window.setTimeout(() => setTyping(false), typingMs);
    return () => window.clearTimeout(id);
  }, [typing, typingMs]);

  return (
    <motion.div
      className="relative max-w-[338px] rounded-tl-[20px] rounded-tr-[20px] rounded-br-[20px] bg-white/[0.06] px-8 py-3"
      initial={{ opacity: 0, y: c.mariaRise }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ ...c.bubble, delay }}
      style={{ transformOrigin: "0% 100%" }}
    >
      <p className="text-[16px] leading-[23px] font-semibold text-chat-ink" aria-label={text}>
        {words.map((word, i) => (
          <motion.span
            key={`${word}-${i}`}
            aria-hidden
            initial={false}
            animate={typing ? { opacity: 0, filter: `blur(${c.wordBlur}px)` } : { opacity: 1, filter: "blur(0px)" }}
            transition={{ ...c.word, delay: typing ? 0 : i * c.wordStagger }}
          >
            {word}
            {i < words.length - 1 ? " " : null}
          </motion.span>
        ))}
      </p>
      <AnimatePresence>
        {typing && (
          <motion.div key="dots" className="absolute top-3 left-8" exit={{ opacity: 0, transition: { duration: 0.15 } }}>
            <TypingDots />
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function TypingDots() {
  const c = useTokens(chat);
  return (
    <span className="flex h-[23px] items-center gap-1.5" aria-label="Maria is typing">
      {[0, 1, 2].map((i) => (
        <motion.span
          key={i}
          className="size-[6px] rounded-full bg-chat-ink"
          animate={{ y: [0, -4, 0], opacity: [0.5, 1, 0.5] }}
          transition={{ ...c.dots, repeat: Infinity, delay: i * 0.15 }}
        />
      ))}
    </span>
  );
}

function Chip({
  target,
  label,
  on,
  muted = false,
  delay,
  disabled,
  onClick,
}: {
  target: string;
  label: string;
  on: boolean;
  muted?: boolean;
  delay: number;
  disabled?: boolean;
  onClick: () => void;
}) {
  const c = useTokens(chat);
  const m = useTokens(micro);
  // Entrance (staggered) and selection state (immediate) live on separate layers so a chip
  // dimming after a pick doesn't inherit its entrance delay.
  return (
    <motion.div initial={{ opacity: 0, y: c.chipRise, scale: c.chipFrom }} animate={{ opacity: 1, y: 0, scale: 1 }} transition={{ ...c.chip, delay }}>
      <motion.button
        type="button"
        data-target={target}
        onClick={disabled ? undefined : onClick}
        aria-pressed={on}
        className={`relative rounded-full border px-6 py-4 transition-[background-color,border-color,color,opacity] duration-300 ${
          on ? "border-white bg-white text-blue" : "border-white/20 text-white"
        } ${muted ? "opacity-55" : "opacity-100"} ${disabled ? "cursor-default" : "hover:border-white/50"}`}
        whileTap={disabled ? undefined : { scale: m.tap, transition: m.press }}
      >
        <span className="trim-cap block text-[14px] leading-none font-semibold whitespace-nowrap">{label}</span>
        <PulseRing id={target} />
      </motion.button>
    </motion.div>
  );
}
