"use client";

import { motion } from "motion/react";
import { useTokens } from "@/motion";
import { useJourney, useSession, useTriageAnswers } from "@banner/hooks";
import { isEmergency } from "@banner/journey/answers";
import { micro, triage } from "@banner/motion/tokens";
import { PulseRing } from "@banner/components/ui/PulseRing";

/** Result rows rise in order: `order` counts steps of the result stagger. */
function useRise() {
  const tr = useTokens(triage);
  return (order: number) => ({
    initial: { opacity: 0, y: tr.resultDistance },
    animate: { opacity: 1, y: 0 },
    transition: { ...tr.resultRise, delay: tr.resultDelay + order * tr.resultStep },
  });
}

export function TriageResult() {
  const { warnings } = useTriageAnswers();
  return isEmergency(warnings) ? <EmergencyResult /> : <UrgentCareResult />;
}

function StartAgain() {
  const { t, go } = useJourney();
  const session = useSession();
  return (
    <button
      type="button"
      onClick={() => {
        session.patch({ warnings: [], howLong: null });
        go("triage.howLong");
      }}
      className="text-right text-[10px] leading-[1.2] font-semibold text-blue uppercase hover:underline"
    >
      {t.result.startAgain}
    </button>
  );
}

function Badge({ label }: { label: string }) {
  const tr = useTokens(triage);
  return (
    <motion.span
      className="rounded-full bg-alert px-3 py-1.5 text-[12px] leading-[1.2] font-semibold whitespace-nowrap text-white uppercase"
      initial={{ scale: tr.badgeFrom, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ ...tr.badge, delay: tr.badgeDelay }}
    >
      {label}
    </motion.span>
  );
}

function UrgentCareResult() {
  const { t } = useJourney();
  const tr = useTokens(triage);
  const m = useTokens(micro);
  const rise = useRise();
  const r = t.result;

  return (
    <div className="rounded-[20px] bg-paper-2 pt-4 pb-6">
      <div className="flex flex-col gap-[3px] px-4 pb-4">
        <div className="flex h-10 items-center justify-between pr-2">
          <Badge label={r.badge} />
          <StartAgain />
        </div>
        <motion.div className="flex flex-col gap-1 text-blue" {...rise(0)}>
          <h3 className="text-[24px] leading-[1.2] font-semibold @desk:text-[28px]">{r.title}</h3>
          <p className="max-w-[316px] text-[14px] leading-[1.2] font-medium">{r.body}</p>
        </motion.div>
      </div>

      <div className="flex flex-col items-center px-2">
        <motion.div className="w-full border-t border-fog px-3 pt-4 pb-2.5" {...rise(1)}>
          <div className="flex flex-col gap-2">
            <div className="flex flex-col gap-3">
              <div className="flex items-center gap-[5px]">
                <img src="/p/banner/images/icons/pin-b.svg" alt="" width={7} height={9} className="h-[9.36px] w-[7.26px]" />
                <span className="text-[10px] leading-[1.2] font-semibold text-assist uppercase">{r.nearest}</span>
              </div>
              <p className="text-[18px] leading-[1.2] font-semibold text-assist">{r.name}</p>
            </div>
            <div className="flex flex-col gap-[2px] text-[12px] leading-[1.2] font-medium text-assist/70">
              <p>{r.meta}</p>
              <p className="flex items-center gap-1.5">
                <span className="relative flex size-1.5">
                  <motion.span
                    className="absolute inset-0 rounded-full bg-go"
                    animate={{ scale: [1, 2.4], opacity: [0.6, 0] }}
                    transition={{ ...tr.ping, repeat: Infinity }}
                  />
                  <span className="relative size-1.5 rounded-full bg-go" />
                </span>
                <span>
                  <span className="font-semibold text-go">{r.open}</span>
                  {r.closes}
                </span>
              </p>
              <p>{r.spanish}</p>
            </div>
          </div>
        </motion.div>

        <motion.div className="w-full px-3 pb-3" {...rise(2)}>
          <p className="mb-2 text-[10px] leading-[1.2] font-semibold text-assist uppercase">{r.soonest}</p>
          <div className="flex gap-2">
            {r.slots.map((slot, i) => (
              <motion.span
                key={slot}
                data-target={`slot-${i}`}
                className={`relative rounded-full border px-4 py-2.5 text-[13px] leading-none font-semibold ${
                  i === 0 ? "border-blue bg-blue text-white" : "border-blue/20 text-blue"
                }`}
                initial={{ opacity: 0, y: tr.slotRise, scale: tr.slotFrom }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ ...tr.slot, delay: tr.slotsDelay + i * tr.slotsStagger }}
              >
                {slot}
                <PulseRing id={`slot-${i}`} />
              </motion.span>
            ))}
          </div>
        </motion.div>

        <motion.div
          className="relative h-[150px] w-full overflow-hidden rounded-[20px] bg-fog @desk:h-[170px] @desk:w-[466px]"
          initial={{ opacity: 0, clipPath: `inset(${tr.imageInsetY}% ${tr.imageInsetX}% ${tr.imageInsetY}% ${tr.imageInsetX}% round 20px)` }}
          animate={{ opacity: 1, clipPath: "inset(0% 0% 0% 0% round 20px)" }}
          transition={{ ...tr.image, delay: tr.imageDelay }}
        >
          <motion.img
            src="/p/banner/images/assistant/urgent-care.webp"
            alt="Banner Urgent Care building on Higley Rd"
            className="absolute inset-0 size-full object-cover"
            initial={{ scale: tr.imageScale }}
            animate={{ scale: tr.imageRest }}
            transition={tr.imageZoom}
          />
        </motion.div>

        <div className="flex w-full justify-end px-4 pt-[18px]">
          <motion.button
            type="button"
            data-target="directions"
            className="relative flex h-[42px] items-center gap-2 rounded-[6px] bg-teal p-4 text-white"
            whileTap={{ scale: m.tapButton, transition: m.press }}
            {...rise(4)}
          >
            <img src="/p/banner/images/icons/phone.svg" alt="" width={10} height={16} className="h-4 w-[10.29px]" />
            <span className="trim-cap text-[14px] leading-none font-semibold whitespace-nowrap">{r.directions}</span>
            <PulseRing id="directions" radius={8} />
          </motion.button>
        </div>
      </div>
    </div>
  );
}

function EmergencyResult() {
  const { t } = useJourney();
  const rise = useRise();
  const e = t.emergency;
  return (
    <div className="rounded-[20px] bg-paper-2 px-4 pt-4 pb-6">
      <div className="flex h-10 items-center justify-between pr-2">
        <Badge label={e.badge} />
        <StartAgain />
      </div>
      <motion.div className="mt-1 flex flex-col gap-2 text-blue" {...rise(0)}>
        <h3 className="text-[24px] leading-[1.2] font-semibold @desk:text-[28px]">{e.title}</h3>
        <p className="max-w-[360px] text-[14px] leading-[1.3] font-medium">{e.body}</p>
        <p className="text-[12px] leading-[1.2] font-medium text-assist/70">{e.nearest}</p>
      </motion.div>
      <motion.a
        href="tel:911"
        className="mt-5 flex h-[46px] items-center justify-center rounded-[6px] bg-alert text-[15px] font-semibold text-white"
        {...rise(1.5)}
      >
        {e.call}
      </motion.a>
    </div>
  );
}
