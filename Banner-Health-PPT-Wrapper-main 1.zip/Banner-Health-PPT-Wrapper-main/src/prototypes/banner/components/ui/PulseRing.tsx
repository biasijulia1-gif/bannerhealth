"use client";

import { AnimatePresence, motion } from "motion/react";
import { useTokens } from "@/motion";
import { useFx } from "@banner/hooks";
import { micro } from "@banner/motion/tokens";

// Expanding mint ring drawn over an element when its target id is pulsed or highlighted.
export function PulseRing({ id, radius = 999 }: { id: string; radius?: number }) {
  const m = useTokens(micro);
  const active = useFx((s) => s.pulse === id || s.highlight.includes(id));
  return (
    <AnimatePresence>
      {active && (
        <motion.span
          key={id}
          aria-hidden
          className="pointer-events-none absolute -inset-1.5 border-2 border-mint"
          style={{ borderRadius: radius }}
          initial={{ opacity: 0, scale: 0.92 }}
          animate={{ opacity: [0, 1, 1, 0.9], scale: [0.92, 1.04, 1, 1] }}
          exit={{ opacity: 0, scale: 1.08 }}
          transition={m.pulse}
        />
      )}
    </AnimatePresence>
  );
}
