import { describe, expect, it } from "vitest";
import { cursor, curves, deck, defineTranslation, global, groupText, momentText, tokenText, type Token, type TokenGroup } from "@/motion";
import { bannerManifest } from "../manifest";
import { BANNER_GROUPS } from "./tokens";
import "./pt";

// Julia works in Portuguese, so everything the admin panel shows needs it: section names and
// tooltips, every token, its help and its options, and the moments she replays.

const GROUPS: TokenGroup[] = [global, curves, deck, cursor, ...BANNER_GROUPS];

describe("admin translations", () => {
  it("explain every section, in English and in Portuguese", () => {
    for (const g of GROUPS) {
      expect(g.help, `${g.id} needs a section tooltip`).toBeTruthy();
      const pt = groupText(g, "pt");
      expect(pt.help, `${g.id} needs its tooltip in Portuguese`).not.toBe(g.help);
      expect(pt.label).toBeTruthy();
    }
  });

  it("translate every token's help and options", () => {
    for (const g of GROUPS) {
      for (const [key, tok] of Object.entries(g.tokens) as [string, Token][]) {
        const pt = tokenText(g, key, "pt");
        expect(pt.label, `${g.id}.${key}`).toBeTruthy();
        if (tok.help) expect(pt.help, `${g.id}.${key} help`).not.toBe(tok.help);
        if (tok.kind === "enum") {
          expect(pt.options, `${g.id}.${key} options`).not.toBe(tok.optionLabels);
          for (const option of tok.options) expect(pt.options?.[option]?.label, `${g.id}.${key} option ${option}`).toBeTruthy();
        }
      }
    }
  });

  it("name every moment in Portuguese", () => {
    for (const [id, m] of Object.entries(bannerManifest.moments ?? {})) expect(momentText(id, "pt", m.label), id).not.toBe(m.label);
  });

  it("falls back to English", () => {
    expect(tokenText(global, "speed", "en")).toMatchObject({ label: "Speed" });
    expect(tokenText(global, "speed", "pt")).toMatchObject({ label: "Velocidade" });
    expect(momentText("not-a-moment", "pt", "Fallback")).toBe("Fallback");
  });

  it("needs an entry for every token (a typecheck failure otherwise)", () => {
    // @ts-expect-error `travel`, `press` and `arc` are missing
    const partial = defineTranslation(cursor, { label: "Cursor", help: "…", tokens: { lead: "Tempo" } });
    expect(partial.group).toBe("cursor");
  });
});
