"use client";

import { LayoutGroup } from "motion/react";
import { useLayoutEffect, useMemo, useRef, useSyncExternalStore } from "react";
import type { ViewProps } from "@/shell/prototype/contract";
import { createDomHandle } from "@/shell/prototype/domHandle";
import { InstanceContext, SessionContext, type Instance } from "./hooks";
import type { BannerSession } from "./session";
import { Site } from "./Site";

// One rendered copy of the Banner site against a session. Everything that used to be page-wide
// in v1 is scoped to this root: language, the brand-morph palette, target lookups, scrolling and
// shared-element ids (each copy gets its own LayoutGroup, so the desktop and phone copies on a
// device-pair slide never morph into each other).
export function BannerView({ session, instanceId, layout, role, input, onHandle }: ViewProps<BannerSession>) {
  const root = useRef<HTMLDivElement>(null);
  const scroller = useRef<HTMLDivElement>(null);
  const state = useSyncExternalStore(session.subscribe, session.getState, session.getState);

  useLayoutEffect(() => {
    if (!onHandle || !root.current) return;
    onHandle(createDomHandle(root.current, () => scroller.current));
    return () => onHandle(null);
  }, [onHandle]);

  const instance = useMemo<Instance>(() => ({ id: instanceId, role, layout, input, root, scroller }), [instanceId, role, layout, input]);

  return (
    <SessionContext.Provider value={session}>
      <InstanceContext.Provider value={instance}>
        <LayoutGroup id={instanceId} inherit={false}>
          <div
            ref={root}
            data-proto-root="banner"
            data-instance={instanceId}
            lang={state.lang}
            data-brand={state.data.brand ? "next" : undefined}
            className="banner-root relative size-full"
          >
            <Site />
          </div>
        </LayoutGroup>
      </InstanceContext.Provider>
    </SessionContext.Provider>
  );
}
