import type { PrototypeManifest } from "@/shell/prototype/contract";
import { bannerManifest } from "./banner/manifest";

// Every prototype's plain-data manifest (steps, labels, what → does), without its site: for the
// presenter view and tooling, which must not load the prototypes themselves.
export const manifests: Record<string, PrototypeManifest> = {
  banner: bannerManifest as unknown as PrototypeManifest,
};
