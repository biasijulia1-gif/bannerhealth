# Banner Health V2: 16:9 Presentation Shell

A 16:9 presentation that holds the Valtech brand slides and the live Banner Health prototype, driven with the arrow keys like Figma, with an admin panel (A) for tuning motion. It replaces the handoff's "`/deck` route in v1" plan: v1 (`../prototype`) stays frozen for the VO video, `?mode=play|record` and the After Effects capture.

Background and the full brief: `../prototype/.ref/HANDOFF.md`. Approved plan: `~/.claude/plans/okay-i-met-with-jazzy-lemur.md`.

## Run it

```bash
npm install
npm run dev -- -p 3200     # http://localhost:3200 (opens the deck)
```

| URL | What it is |
|---|---|
| `/deck` | The presentation |
| `/deck?admin` | The presentation with the motion panel available (press A). Remembered for the browser tab |
| `/deck?slide=5&step=doctors.profile` | Deep link to any slide and journey step (`&build=2` for a brand slide's builds) |
| `/deck?noauto` | Turns off steps that move on by themselves ("Finding doctors…" → results), for rehearsals and tests |
| `/deck?tone=light&site=fullbleed` | Opens in the light version with the site filling the slide. T, Z and the admin write the look into the address bar like this, so a copied link keeps it |
| `/deck/presenter` | The presenter view, normally opened with P. It follows whichever deck window is open in the same browser |
| `/proto/banner` | The Banner site on its own at window size. `?step=` deep links, `&device=mobile` shows the phone. Shift+←/→ steps |

## Presenting keys

| Key | Does |
|---|---|
| → · PageDown · Space | Next step or slide (clickers send PageDown) |
| ← · PageUp | Previous, instantly |
| number, then Enter | Jump to a slide |
| B or . / W or , | Black / white screen |
| N | On-canvas notes |
| P | Presenter view in its own window (P again brings it forward) |
| F | Full screen |
| Z | On a prototype slide: the site zooms to fill the slide, or back into the frame. It stays that way on every prototype slide until you press Z again |
| T | Dark / light version of the deck |
| A | Motion panel (with `?admin`) |
| Esc | Close whatever is open |

On a prototype slide, → plays the same click a person would (the island, Send, an answer chip), so the site's own motion runs. A second → while a move is still playing completes it rather than skipping ahead. You can also click around the live site by hand; the deck follows.

The light version mirrors the dark one slide for slide: a contrast slide such as Meet Luisa (light in the dark version) turns dark in the light version, so the rhythm holds. The site fills the slide by scaling, not by relaying out, so it looks exactly like the framed version, only bigger.

## The presenter view (P)

A private window for the presenter's laptop: the slide on screen and what → does next (as cards on each slide's own ground), the speaker notes plus the note for the current journey step, the step list or builds, and the clocks (time since the talk started, time on this slide, the wall clock). It follows the deck window over a BroadcastChannel, so it only works in the same browser on the same machine.

- Its keys drive the deck: → ← PageDown PageUp Space, B / W, N, T, Z and number + Enter all work with focus in either window, so the clicker does too. `-` and `=` resize the notes; F puts the presenter window itself in full screen. A and P do nothing there.
- The elapsed clock starts on the first move (or straight away when P is pressed mid-talk). Pause and Reset are in the header; the clocks survive a reload of the presenter window.
- Chips warn when the deck window is hidden or covered, when the motion panel is open on the deck screen, or when two deck windows are open (it follows the last one where P was pressed).
- Give a slide `durationHint` (minutes) in the config to see its time turn red when it runs over.
- Slide images will replace the text cards once the stills export exists.

## The motion panel (A)

Docked on the right; the slide shrinks beside it so it stays fully visible.

- **EN | PT**, next to the frame rate in the header, switches every word in the panel between English and Brazilian Portuguese (for Julia). It starts in the browser's language and remembers the choice.
- **Tooltips**: every section, tab and setting has a **?** (or a hover tooltip) that says what it moves. Plain settings like "Headline delay" keep just their name.
- **This moment**: the motion values for what's on screen (hero opening, AI prompt, doctor cards…), with Replay buttons. Shift+R replays.
- **Global**: speed, elasticity, the bounce ceiling (the "not too cuckoo for healthcare" limit), stagger, distance and blur multipliers, and the shared curves every moment links to.
- **Deck**: the look (Background: dark or light; Prototype: framed, browser or fill slide; the same switches as T and Z), slide transitions (crossfade, fade through, push, cut), brand-slide builds and the zoom curve. The look isn't a motion setting, so it stays out of the copied JSON; the deck's starting look lives in `deck.config.ts`.
- **Display**: force full motion (on by default, so a laptop with Reduce Motion on still shows everything), Teams-safe, slow motion, frame-rate meter, copy/export/import settings.

Edits save in the browser automatically. "Copy settings" puts JSON on the clipboard to send to Trey, who commits it as the default.

## Explainer videos

Two instructional videos are rendered from the live deck, one exact frame at a time, so they can be re-rendered whenever the deck changes (Sebastian's slides, Julia's preset, new keys):

| File in `exports/video/` | For | About |
|---|---|---|
| `Using the Pitch Deck.mp4`, `Using the Pitch Deck (PT).mp4` | Everyone who presents or tunes the deck: the keys, dark/light and zoom, the presenter view, the motion panel | 2 min |
| `Handing Off Brand Slides.mp4` | Sebastian: frames, build numbers in layer names, notes, sending a slide (the PDF's steps) | 1 min |

```bash
npm run video -- deck              # needs the dev server on :3200 and ffmpeg on PATH; about 9 minutes
npm run video -- deck --lang pt
npm run video -- figma
npm run video -- deck --fps 30 --scene panel --frames exports/frames   # a quick draft of one scene
```

- `scripts/video/render.mjs` drives Chrome with a virtual clock (`lib/clock.js`) that steps timers, animation frames and CSS transitions one frame at a time; Motion runs on it because the clock removes `Element.prototype.animate`. An overlay (`lib/overlay.js`, `lib/cards.js`) draws the captions, key badges, cursor and Valtech cards, and each frame goes to ffmpeg (1920×1080, 60 fps, H.264, BT.709).
- The storyboards (`scripts/video/storyboards/*.mjs`) are data: scenes, captions in English and Portuguese, and timed key presses, clicks and close-ups. Change a caption or a beat and re-render.
- `exports/` is gitignored, so the videos stay out of the repo and Julia's zip; share them through Teams or OneDrive.

## How it's built

```
src/
  app/            routes: /deck, /proto/[id]
  shell/          the engine: deck state, keys, stage, slides, transitions, builds, admin, export hook
  motion/         motion tokens (registry, resolver, store), instant jumps, provider
  prototypes/     prototype registry; banner/ is the Banner site (session, view, components, tokens)
  decks/banner/   the slide list (deck.config.ts) and the brand slides
  themes/valtech/ the Valtech frame, fonts and slide kit
scripts/smoke.mjs end-to-end test in Chrome
scripts/video/    the explainer videos (render.mjs, storyboards/, lib/)
```

- **Deck config** (`src/decks/banner/deck.config.ts`): an ordered list of slides, plus the look the deck opens in (`tone: "dark" | "light"`, `presentation: "framed" | "browser" | "fullbleed"`). A `brand` slide is a React component with `builds`; a `prototype` slide shows the Banner site from one journey step to another. Slides follow the deck's tone unless they set `tone: "invert"` (always the opposite, for contrast slides) or pin `"dark"`/`"light"`. A prototype slide follows the deck's framing (which Z switches) unless it pins its own `presentation`. Notes go in `notes` (private) and `annotation` (on canvas).
- **Brand slides** are built from Sebastian's Figma frames with the kit in `src/themes/valtech/kit.tsx` (`Place` for pixel-exact positions, `Kicker`, `Title`, `Body`) and `<Build at={n}>` for Keynote-style builds. Use the tone colors (`text-tone-fg`, `text-tone-dim`, `text-tone-faint`, and `bg-tone-accent`, which is lime on dark and signal red on light) rather than white or black, so a slide works in both versions. The current ones are placeholders. Sebastian's handoff guide (Figma setup, build numbers in layer names) is `docs/Handing Off Brand Slides.pdf`, printed from `docs/slide-handoff-guide.html` with `node scripts/guide-pdf.mjs`.
- **Presenter** (`src/shell/presenter/`): the protocol and link between the windows (`link.ts`, React-free), the pure model of what it shows (`model.ts`) and its timers. The route (`src/app/deck/presenter`) loads the deck config and the prototypes' plain manifests (`src/prototypes/manifests.ts`), never the sites. The deck runs the presenter's commands through the same actions as its keys.
- **Prototype contract** (`src/shell/prototype/contract.ts`): a prototype is a manifest (steps, the click that advances each step, moments), a session store and a view. The deck only reaches into it through a view handle, so a URL/iframe adapter can implement the same contract later.
- **Motion tokens**: every duration, curve, distance and variant is a named token (`src/motion/tokens/*`, `src/prototypes/banner/motion/tokens.ts`) at v1's exact values. Components read them with `useTokens(group)`. The resolver applies speed, elasticity, the bounce ceiling and Teams-safe in one place.
- **Admin languages**: a token's English label and help, and each group's section tooltip (`help`), sit in its token file. The Portuguese is in `src/motion/tokens/pt.ts` and `src/prototypes/banner/motion/pt.ts`, and the panel's own words are in `src/shell/admin/i18n.ts`. A token or panel string added without its Portuguese fails the typecheck.

## Checks

```bash
npm run typecheck
npm run lint        # includes the engine import boundaries
npm test            # unit tests (motion resolver, store, deck machine, journey controller, session, presenter)
npm run smoke       # needs the dev server on :3200; walks the whole deck with real key presses
```

## Open items

- Brand slides, notes design and the final slide list: Sebastian and Seth.
- Valtech fonts are served from `public/themes/valtech/fonts` so the planned password gate covers them; the web licence is unconfirmed. `NEXT_PUBLIC_BRAND_FONTS=fallback` switches to open fonts.
- Hosting, the gate and shared presets wait on a Valtech-owned Vercel team.
- Still to build (see the plan): presets and shared saving, curve editors, scripted cursor, the three rebuilt motion moments, device-pair and scroll-frame slides, slide images in the presenter view, PowerPoint export, tracking.
