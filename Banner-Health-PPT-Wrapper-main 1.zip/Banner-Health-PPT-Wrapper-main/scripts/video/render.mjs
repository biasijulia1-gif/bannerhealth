// Renders the explainer videos from the live deck, one exact frame at a time (the Capital Health
// film's pipeline). Playwright drives system Chrome; a virtual clock (lib/clock.js) steps every open
// page one frame at a time; the overlay (lib/overlay.js + lib/cards.js) draws captions, key badges,
// the cursor and cards; each frame goes to ffmpeg as a JPEG. Needs the dev server and ffmpeg.
//
//   node scripts/video/render.mjs deck              → exports/video/Using the Pitch Deck.mp4
//   node scripts/video/render.mjs deck --lang pt    → exports/video/Using the Pitch Deck (PT).mp4
//   node scripts/video/render.mjs figma             → exports/video/Handing Off Brand Slides.mp4
//   --fps 30          a quicker draft (default 60)
//   --scene <id>      only that scene, to exports/video/drafts/ (the scenes before it on the same
//                     page still run, unfilmed, so it starts in the right state)
//   --frames <dir>    also save a frame every half second, for review
//   --base <url>      where the deck runs (default http://localhost:3200)
//   --crf, --preset   x264 quality (default 16, slow)
//
// Storyboards (storyboards/*.mjs) are data: scenes with a URL, an optional card and timed beats.

import { spawn, spawnSync } from "node:child_process";
import { once } from "node:events";
import { mkdirSync, writeFileSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { chromium } from "playwright-core";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..", "..");
const LIB = path.join(ROOT, "scripts", "video", "lib");
const argv = process.argv.slice(2);
const opt = (name, fallback) => {
  const i = argv.indexOf(`--${name}`);
  return i >= 0 && argv[i + 1] !== undefined ? argv[i + 1] : fallback;
};
const name = argv[0];
if (!name || name.startsWith("--")) throw new Error("usage: node scripts/video/render.mjs <deck|figma> [--lang pt] [--fps 30] [--scene id]");
const fps = Number(opt("fps", 60));
const lang = opt("lang", "en");
const only = opt("scene", null);
const framesDir = opt("frames", null);
const BASE = opt("base", "http://localhost:3200");
const crf = String(opt("crf", 16));
const preset = String(opt("preset", "slow"));
const W = 1920;
const H = 1080;
const WIDE = { x: 0, y: 0, w: W, h: H };

const sb = (await import(pathToFileURL(path.join(ROOT, "scripts", "video", "storyboards", `${name}.mjs`)).href)).default;
/** A storyboard string in the render's language. */
const T = (v) => (v === undefined || v === null || typeof v === "string" ? v : (v[lang] ?? v.en));

// The scenes to run: all of them, or one plus the unfilmed scenes before it on the same page.
let first = 0;
let last = sb.scenes.length - 1;
if (only) {
  last = sb.scenes.findIndex((s) => s.id === only);
  if (last < 0) throw new Error(`no scene "${only}" in ${name}: ${sb.scenes.map((s) => s.id).join(", ")}`);
  first = last;
  while (first > 0 && !sb.scenes[first].url) first--;
}
const filmed = (i) => !only || i === last;
const total = sb.scenes.slice(first, last + 1).reduce((n, s, k) => n + (filmed(first + k) ? Math.round(s.seconds * fps) : 0), 0);

const outName = `${T(sb.output)}${only ? ` · ${only}` : ""}${fps !== 60 ? ` (${fps} fps)` : ""}.mp4`;
const out = path.join(ROOT, "exports", "video", only || fps !== 60 ? "drafts" : "", outName);
mkdirSync(path.dirname(out), { recursive: true });
if (framesDir) mkdirSync(framesDir, { recursive: true });

// ---------- browser ----------
const browser = await chromium.launch({ channel: "chrome", args: ["--hide-scrollbars", "--force-color-profile=srgb"] });
const context = await browser.newContext({ viewport: { width: W, height: H } });
await context.grantPermissions(["clipboard-read", "clipboard-write"], { origin: BASE });
for (const file of ["clock.js", "cards.js", "overlay.js"]) await context.addInitScript({ path: path.join(LIB, file) });
// The admin panel opens in the video's language.
await context.addInitScript((l) => {
  try {
    localStorage.setItem("admin:lang", l);
  } catch {
    // Storage blocked: the panel follows the browser.
  }
}, lang);

const errors = [];
const watch = (page) => {
  page.on("pageerror", (e) => errors.push(String(e)));
  page.on("console", (m) => {
    if (m.type() === "error" || (m.type() === "warning" && m.text().startsWith("[deck]"))) errors.push(m.text());
  });
};

/** Fonts loaded and, on a deck page, everything settled: the clock can start. */
async function settle(page) {
  await page.evaluate(async () => {
    await document.fonts.ready;
    await Promise.all(["300 1em 'Valtech Neue'", "400 1em Sons", "600 1em Sons"].map((f) => document.fonts.load(f)));
    if (window.__deck) await window.__deck.settled({ quietMs: 300 });
  });
}

async function openPage(url) {
  const page = await context.newPage();
  watch(page);
  await page.goto(BASE + url, { waitUntil: "networkidle", timeout: 120000 });
  await page.waitForFunction(() => !!window.__deck, null, { timeout: 60000 });
  await settle(page);
  return { page, cdp: await context.newCDPSession(page) };
}

// ---------- stills for diagrams (storyboard.prepare) ----------
async function prepare() {
  if (!sb.prepare) return {};
  const { page } = await openPage("/deck?debug&noauto");
  const at = async (slide, pos) => {
    await page.evaluate(([s, p]) => window.__deck.goTo(s, p), [slide, pos]);
    await page.waitForTimeout(100);
    await settle(page);
  };
  const helpers = {
    /** A JPEG data URL of slide `slide` (0-based) at `pos`. */
    async still(slide, pos) {
      await at(slide, pos);
      const buf = await page.screenshot({ type: "jpeg", quality: 92, clip: { x: 0, y: 0, width: W, height: H } });
      return `data:image/jpeg;base64,${buf.toString("base64")}`;
    },
    /** Canvas rects of the smallest elements whose text starts with each of `texts`. */
    async rects(slide, pos, texts) {
      await at(slide, pos);
      return page.evaluate((wanted) => {
        const canvas = document.querySelector("[data-deck-canvas]").getBoundingClientRect();
        const all = [...document.querySelectorAll("[data-deck-canvas] *")];
        return Object.fromEntries(
          Object.entries(wanted).map(([key, text]) => {
            const hits = all.filter((el) => el.textContent.trim().startsWith(text)).map((el) => el.getBoundingClientRect());
            const r = hits.sort((a, b) => a.width * a.height - b.width * b.height)[0];
            return [key, r && { x: r.x - canvas.x, y: r.y - canvas.y, w: r.width, h: r.height }];
          }),
        );
      }, texts);
    },
  };
  const prepared = await sb.prepare(helpers, T);
  await page.close();
  return prepared;
}
const prepared = await prepare();

// ---------- encoder (as the Capital Health film) ----------
const encoder = spawn(
  "ffmpeg",
  [
    "-hide_banner", "-v", "error", "-y",
    "-f", "image2pipe", "-framerate", String(fps), "-c:v", "mjpeg", "-i", "-",
    // JPEG frames are full-range BT.601; deliver limited-range BT.709. Forcing in_range or
    // in_color_matrix here double-converts (Capital Health measured ~3 levels darker), so don't.
    // ffmpeg 8 tags the file from the frames, not from -color_primaries/-color_trc, so setparams
    // stamps all four on the frames (without it, primaries and transfer come out "unknown").
    "-vf", `scale=${W}:${H}:out_range=tv:out_color_matrix=bt709:flags=accurate_rnd+full_chroma_int,format=yuv420p,setparams=color_primaries=bt709:color_trc=bt709:colorspace=bt709:range=tv`,
    "-c:v", "libx264", "-preset", preset, "-crf", crf, "-pix_fmt", "yuv420p",
    "-colorspace", "bt709", "-color_primaries", "bt709", "-color_trc", "bt709", "-color_range", "tv",
    "-r", String(fps), "-movflags", "+faststart", out,
  ],
  { stdio: ["pipe", "inherit", "inherit"] },
);
const encoderDone = once(encoder, "close");

// ---------- the timeline ----------
const GLYPHS = { ArrowRight: "→", ArrowLeft: "←", Enter: "Enter", " ": "Space", Escape: "Esc", PageDown: "PgDn", PageUp: "PgUp" };
const glyph = (key) => GLYPHS[key] ?? (key.length === 1 ? key.toUpperCase() : key);
/** An even ease for the cursor's glides. */
const ease = (x) => (x < 0.5 ? 4 * x * x * x : 1 - Math.pow(-2 * x + 2, 3) / 2);
const clamp01 = (x) => Math.max(0, Math.min(1, x));

let pages = [];
let main = null;
let camera = null;
let frame = WIDE;
let caption = null;
let chapter = null;
let badge = null;
let cursor = { x: 1500, y: 760, shown: false, since: -9, ring: null, page: null };
let motions = [];
let written = 0;
const started = Date.now();

/** Where a point of an element is, in page pixels: its center, or `anchor` as fractions of its box. */
async function pointIn(page, selector, [fx, fy] = [0.5, 0.5]) {
  const box = await page.locator(selector).first().boundingBox({ timeout: 5000 });
  if (!box) throw new Error(`not on screen: ${selector}`);
  return { x: box.x + box.width * fx, y: box.y + box.height * fy, box };
}

/** The x of a range input's thumb for `value`. */
async function thumbAt(page, selector, value) {
  const { box } = await pointIn(page, selector);
  const { min, max } = await page.locator(selector).first().evaluate((el) => ({ min: Number(el.min), max: Number(el.max) }));
  const v = value ?? Number(await page.locator(selector).first().inputValue());
  const inset = 8;
  return { x: box.x + inset + ((v - min) / (max - min)) * (box.width - 2 * inset), y: box.y + box.height / 2 };
}

const target = (beat) => (beat.on === "popup" ? pages[1] : main);

async function runBeat(beat, t) {
  if ("chapter" in beat) chapter = T(beat.chapter);
  if ("caption" in beat) {
    const text = T(beat.caption);
    if (!text) caption = caption && { ...caption, end: t };
    else caption = { text, place: beat.place, start: caption && caption.end === undefined ? caption.start : t };
  }
  if (beat.frame) frame = beat.frame === "wide" ? WIDE : { x: beat.frame[0], y: beat.frame[1], w: beat.frame[2], h: beat.frame[2] * (H / W) };
  if (beat.camera) camera = beat.camera === "popup" ? pages[1] : main;
  if (beat.cursor) {
    cursor.shown = beat.cursor === "show";
    cursor.since = t;
    if (beat.x !== undefined) Object.assign(cursor, { x: beat.x, y: beat.y });
  }
  if (beat.eval) await main.page.evaluate(beat.eval);
  if (beat.key || beat.type) {
    const key = beat.key ?? beat.type;
    const p = target(beat);
    // A badge stays on the side it appeared on, even if the next caption moves.
    badge = { glyph: beat.glyph ?? glyph(key), label: T(beat.label), start: t, place: caption?.place };
    if (beat.popup) {
      const popupEvent = p.page.waitForEvent("popup", { timeout: 10000 });
      await p.page.keyboard.press(key);
      const popup = await popupEvent;
      // The popup opens at the size window.open asks for; film it at the video's.
      await popup.setViewportSize({ width: W, height: H });
      watch(popup);
      await popup.waitForURL("**/deck/presenter", { timeout: 30000 });
      await popup.waitForSelector('[data-presenter-status="connected"]', { timeout: 30000 });
      await popup.evaluate(async () => {
        await document.fonts.ready;
        await Promise.all(["300 1em 'Valtech Neue'", "400 1em Sons", "600 1em Sons"].map((f) => document.fonts.load(f)));
        window.__videoClock.start();
      });
      pages.push({ page: popup, cdp: await context.newCDPSession(popup) });
    } else await p.page.keyboard.press(key);
  }
  const spec = beat.click ?? beat.hover ?? beat.drag;
  if (spec) {
    const p = target(beat);
    const glide = beat.glide ?? 0.6;
    if (beat.drag) {
      const from = await thumbAt(p.page, T(spec));
      const to = await thumbAt(p.page, T(spec), beat.to);
      motions.push({ kind: "drag", page: p.page, start: t, glide, seconds: beat.seconds ?? 0.9, a: { x: cursor.x, y: cursor.y }, from, to, phase: 0 });
    } else {
      // A selector, or [x, y] on the page (somewhere neutral to rest, away from tooltips).
      const to = Array.isArray(spec) ? { x: spec[0], y: spec[1] } : await pointIn(p.page, T(spec), beat.anchor);
      motions.push({ kind: beat.click ? "click" : "hover", page: p.page, start: t, glide, a: { x: cursor.x, y: cursor.y }, to });
    }
    if (!cursor.shown) Object.assign(cursor, { shown: true, since: t });
  }
}

/** Moves the cursor (and the real mouse, so hovers are genuine) along every glide in progress. */
async function stepMotions(t) {
  for (const m of motions) {
    const along = (a, b, k) => ({ x: a.x + (b.x - a.x) * k, y: a.y + (b.y - a.y) * k });
    if (m.kind === "drag") {
      if (m.phase === 0) {
        Object.assign(cursor, along(m.a, m.from, ease(clamp01((t - m.start) / m.glide))));
        await m.page.mouse.move(cursor.x, cursor.y);
        if (t >= m.start + m.glide) {
          await m.page.mouse.down();
          m.phase = 1;
        }
      } else if (m.phase === 1) {
        const k = ease(clamp01((t - m.start - m.glide) / m.seconds));
        Object.assign(cursor, along(m.from, m.to, k));
        await m.page.mouse.move(cursor.x, cursor.y);
        if (k >= 1) {
          await m.page.mouse.up();
          m.phase = 2;
          m.done = true;
        }
      }
      continue;
    }
    const k = ease(clamp01((t - m.start) / m.glide));
    Object.assign(cursor, along(m.a, m.to, k));
    await m.page.mouse.move(cursor.x, cursor.y);
    if (k >= 1) {
      if (m.kind === "click") {
        await m.page.mouse.down();
        await m.page.mouse.up();
        cursor.ring = t;
      }
      m.done = true;
    }
  }
  motions = motions.filter((m) => !m.done);
}

function overlayState(scene, t) {
  const toOut = (p) => ({ x: ((p.x - frame.x) * W) / frame.w, y: ((p.y - frame.y) * W) / frame.w });
  const state = { frame };
  if (caption) {
    const alpha = Math.min(clamp01((t - caption.start) / 0.25), caption.end === undefined ? 1 : clamp01((caption.end + 0.25 - t) / 0.25));
    if (alpha > 0) state.caption = { text: caption.text, eyebrow: chapter, alpha, place: caption.place };
  }
  if (badge) {
    const age = t - badge.start;
    const alpha = Math.min(clamp01(age / 0.08), clamp01((1.5 - age) / 0.3));
    if (alpha > 0) state.key = { glyph: badge.glyph, label: badge.label, alpha, down: age < 0.2, place: badge.place };
  }
  if (camera === main && (cursor.shown || t - cursor.since < 0.3)) {
    const alpha = cursor.shown ? clamp01((t - cursor.since) / 0.2) : 1 - clamp01((t - cursor.since) / 0.3);
    const ring = cursor.ring !== null && t - cursor.ring < 0.45 ? (t - cursor.ring) / 0.45 : null;
    state.cursor = { ...toOut(cursor), alpha, ring };
  }
  if (scene.card) state.card = { name: scene.card.name, id: scene.id, t, alpha: 1 };
  const fadeIn = scene.fadeIn ? 1 - clamp01(t / scene.fadeIn) : 0;
  const fadeOut = scene.fadeOut ? clamp01((t - (scene.seconds - scene.fadeOut)) / scene.fadeOut) : 0;
  state.fade = Math.max(fadeIn, fadeOut);
  return state;
}

for (let i = first; i <= last; i++) {
  const scene = sb.scenes[i];
  const film = filmed(i);
  if (scene.url || !main) {
    for (const p of pages) await p.page.close();
    main = await openPage(scene.url ?? "/deck?debug");
    pages = [main];
    cursor = { x: 1500, y: 760, shown: false, since: -9, ring: null };
    await main.page.evaluate(() => window.__videoClock.start());
  }
  // Beats are timed within their scene, so captions, badges and the cursor start fresh in each.
  caption = chapter = badge = null;
  motions = [];
  cursor = { ...cursor, shown: false, since: -9, ring: null };
  frame = WIDE;
  camera = main;
  if (scene.card) {
    const params = typeof scene.card.params === "function" ? scene.card.params(prepared, T) : scene.card.params;
    await main.page.evaluate(([id, p]) => window.__videoOverlay.setParams(id, p), [scene.id, params]);
  }
  const beats = [...(scene.beats ?? [])].sort((a, b) => a.at - b.at);
  let next = 0;
  const frames = Math.round(scene.seconds * fps);
  for (let f = 0; f < frames; f++) {
    const t = f / fps;
    while (next < beats.length && beats[next].at <= t + 1e-9) await runBeat(beats[next++], t);
    await stepMotions(t);
    const state = overlayState(scene, t);
    await Promise.all(
      pages.map((p) =>
        p.page.evaluate(
          async ([dt, s]) => {
            if (s) window.__videoOverlay.render(s);
            await window.__videoClock.tick(dt);
            if (s) await window.__videoOverlay.ready();
          },
          [1000 / fps, p === camera ? state : null],
        ),
      ),
    );
    if (!film) continue;
    const { data } = await camera.cdp.send("Page.captureScreenshot", {
      format: "jpeg",
      quality: 92,
      optimizeForSpeed: true,
      fromSurface: true,
      clip: { x: frame.x, y: frame.y, width: frame.w, height: frame.h, scale: W / frame.w },
    });
    const buf = Buffer.from(data, "base64");
    if (!encoder.stdin.write(buf)) await once(encoder.stdin, "drain");
    if (framesDir && f % Math.round(fps / 2) === 0) writeFileSync(path.join(framesDir, `${String(i).padStart(2, "0")}-${scene.id}-${t.toFixed(1).padStart(4, "0")}.jpg`), buf);
    written++;
    if (written % fps === 0 || written === total) {
      const secs = (Date.now() - started) / 1000;
      const rate = written / secs;
      process.stdout.write(`  ${scene.id.padEnd(10)} ${String(written).padStart(5)}/${total}  ${rate.toFixed(1)} fps  eta ${Math.round((total - written) / rate)}s\n`);
    }
  }
}

encoder.stdin.end();
const [code] = await encoderDone;
await browser.close();
if (code !== 0) throw new Error(`ffmpeg exited with ${code}`);
const probe = spawnSync("ffprobe", ["-v", "error", "-select_streams", "v:0", "-show_entries", "stream=width,height,r_frame_rate,pix_fmt,color_space,color_primaries,color_transfer:format=duration", "-of", "default=nw=1", out], { encoding: "utf8" });
console.log(`wrote ${path.relative(ROOT, out)} in ${((Date.now() - started) / 1000).toFixed(0)}s\n${probe.stdout.trim().replace(/\n/g, "  ")}`);
if (errors.length) {
  console.error(`page errors:\n  ${[...new Set(errors)].join("\n  ")}`);
  process.exit(1);
}
