// "Handing Off Brand Slides": the Figma habits that turn Sebastian's frames into live slides, in about
// a minute. It follows docs/Handing Off Brand Slides.pdf. The diagrams are drawn in the Valtech
// style from stills of the real deck (Figma's own UI isn't recorded), and one scene is the live deck.
// Beats work as in deck.mjs.

const storyboard = {
  output: "Handing Off Brand Slides",

  /** Stills of the deck's slides and where Meet Luisa's pieces sit, for the diagrams. */
  async prepare({ still, rects }) {
    const luisa = { build: 2 };
    return {
      title: await still(0, { build: 0 }),
      luisa: await still(1, luisa),
      followUp: await still(3, { build: 0 }),
      luisaRects: await rects(1, luisa, { kicker: "The journeys", title: "Meet Luisa", body1: "Luisa lives in Mesa", body2: "Three moments show" }),
    };
  },

  scenes: [
    {
      id: "title",
      url: "/deck?debug&slide=2",
      seconds: 4.5,
      fadeIn: 0.8,
      card: {
        name: "title",
        params: {
          label: "Banner Health",
          eyebrow: "Guide for Sebastian",
          title: "Handing Off Brand Slides",
          sub: "From a Figma frame to a live slide in the deck.",
          byline: "Banner Health pitch · November 2026",
        },
      },
    },
    {
      id: "frames",
      seconds: 8,
      card: {
        name: "frames",
        params: (p) => ({
          size: "1920 × 1080",
          frames: [
            { name: "01 Title", src: p.title },
            { name: "02 Meet Luisa", src: p.luisa },
            { name: "04 Follow-up", src: p.followUp },
          ],
        }),
      },
      beats: [
        { at: 0, chapter: "01 · Set up each frame" },
        { at: 0.4, caption: "Use the Valtech template: one 1920 × 1080 frame per slide, named in slide order." },
      ],
    },
    {
      id: "builds",
      seconds: 15,
      card: {
        name: "layers",
        params: (p) => ({
          still: p.luisa,
          rects: p.luisaRects,
          heading: "Layers",
          frame: "02 Meet Luisa",
          restTag: "No number",
          restAt: 8.4,
          layers: [
            { key: "kicker", name: "Kicker" },
            { key: "title", name: "Title" },
            { key: "body1", name: "Body", num: 1, typeAt: 1.8 },
            { key: "body2", name: "Body", num: 2, typeAt: 4.2 },
          ],
        }),
      },
      beats: [
        { at: 0, chapter: "02 · Builds" },
        { at: 0.3, caption: "Add [1], [2] to a layer's name to bring it in on a press of →." },
        { at: 7.8, caption: "No number: it arrives with the slide. Same number: together, top to bottom." },
      ],
    },
    {
      id: "deck",
      url: "/deck?debug&slide=2",
      seconds: 11.5,
      beats: [
        { at: 0, chapter: "02 · Builds" },
        { at: 0.3, caption: "In the deck, each press of → brings in the next number." },
        { at: 1.2, key: "ArrowRight", label: "Build 1" },
        { at: 3.0, key: "ArrowRight", label: "Build 2" },
        { at: 5.4, chapter: "03 · Light and dark" },
        { at: 5.4, caption: "Design one version. T makes the other, and the accent follows." },
        { at: 6.2, key: "t", label: "Dark / light" },
      ],
    },
    {
      id: "notes",
      seconds: 7,
      card: {
        name: "notes",
        params: (p) => ({
          still: p.luisa,
          notesLabel: "Notes",
          notes: "Introduce Luisa: Mesa, a recurring stomach issue. Three moments with the AI assistant.",
          motionLabel: "Motion idea",
          motion: "Headline masks up, photo drifts slowly.",
        }),
      },
      beats: [
        { at: 0, chapter: "04 · Notes and motion ideas" },
        { at: 0.3, caption: "Put speaker notes and motion ideas beside the frame. Julia sets the motion in the deck." },
      ],
    },
    {
      id: "send",
      seconds: 7,
      card: {
        name: "send",
        params: (p) => ({
          still: p.luisa,
          frame: "02 Meet Luisa",
          menu: ["Copy", "Paste here", "Copy link to selection", "Select layer"],
          pick: 2,
          to: "To Trey",
          message: "Here's 02 Meet Luisa. It goes after the title slide.",
          link: "figma.com/design/…/Banner-Health?node-id=…",
        }),
      },
      beats: [
        { at: 0, chapter: "05 · Sending a slide" },
        { at: 0.3, caption: "Right-click the frame, choose Copy link to selection, and send it to Trey with where it goes." },
      ],
    },
    {
      id: "checklist",
      seconds: 8,
      fadeOut: 0.8,
      card: {
        name: "checklist",
        params: {
          label: "Banner Health",
          eyebrow: "06",
          title: "Before You Send a Slide",
          items: [
            "The frame is 1920 × 1080, in the Valtech template, named in slide order",
            "Layers that build in carry their numbers, like [1] and [2]",
            "Text is live and uses the template's styles",
            "Artwork that only works on dark or light is flagged",
            "Speaker notes sit beside the frame",
            "The link came from Copy link to selection",
          ],
        },
      },
    },
  ],
};

export default storyboard;
