// "Using the Pitch Deck": the keys, the two looks, the presenter view and the motion panel, in about
// two minutes, for everyone who presents or tunes the deck. English and Portuguese (for Julia).
//
// A scene with a `url` opens a fresh page; one without continues on the last page. Beats run at `at`
// seconds into their scene:
//   key / type      a key press, with a badge (label)       on: "popup" sends it to the presenter
//   click / hover   the cursor glides to a selector first   drag: a range input to `to`
//   caption         the caption plate (null clears it)      chapter: its eyebrow; place: "right"
//   hover: [x, y]   rest the cursor on a neutral spot, away from tooltips
//   anchor          where in the target to point, as [x, y] fractions of its box (default its center)
//   frame           a hard cut to [x, y, width] of the page, or "wide"
//   camera          "popup" or "main"                        popup: true on the key that opens one

const L = (en, pt) => ({ en, pt });

// The admin panel's controls, by their label in each language.
const tab = (en, pt) => L(`aside nav button:text-is("${en}")`, `aside nav button:text-is("${pt}")`);
const button = (en, pt) => L(`aside button:text-is("${en}")`, `aside button:text-is("${pt}")`);
const chip = (en, pt) => L(`aside header button:has-text("${en}")`, `aside header button:has-text("${pt}")`);
const range = (en, pt) => {
  const x = (label) => `xpath=//aside//span[normalize-space()="${label}"]/ancestor::div[.//input[@type="range"]][1]//input[@type="range"]`;
  return L(x(en), x(pt));
};

// The panel's close-up: the whole panel and the right of the slide, at 1.9×.
const CLOSE = [900, 0, 1020];
const AI_OPEN = chip("AI prompt · open", "Prompt de IA · abrir");
/** A spot on the slide inside the close-up, with nothing that shows a tooltip. */
const REST = [1250, 420];

const storyboard = {
  output: L("Using the Pitch Deck", "Using the Pitch Deck (PT)"),
  scenes: [
    {
      id: "title",
      url: "/deck?debug&slide=1",
      seconds: 5.5,
      fadeIn: 0.8,
      card: {
        name: "title",
        params: (_, T) => ({
          label: "Banner Health",
          eyebrow: T(L("Instructional", "Tutorial")),
          title: T(L("Using the Pitch Deck", "Como usar o deck")),
          sub: T(L("Keys, looks, the presenter view and the motion panel.", "Teclas, visuais, a visão do apresentador e o painel de movimento.")),
          byline: T(L("Banner Health pitch · November 2026", "Pitch Banner Health · novembro de 2026")),
        }),
      },
    },
    {
      id: "moving",
      seconds: 22,
      beats: [
        { at: 0, chapter: L("01 · Moving through the deck", "01 · Navegando pelo deck") },
        { at: 0.3, caption: L("→, Space or the clicker moves forward.", "→, Espaço ou o passador de slides avança.") },
        { at: 1.3, key: "ArrowRight", label: L("Next", "Avançar") },
        { at: 2.7, caption: L("On a brand slide, each press brings in the next piece.", "Num slide de marca, cada toque traz a próxima parte.") },
        { at: 3.3, key: "ArrowRight", label: L("Next", "Avançar") },
        { at: 4.5, key: "ArrowRight", label: L("Next", "Avançar") },
        { at: 6.0, caption: L("On a prototype slide, → clicks the live site for you.", "Num slide de protótipo, → clica no site ao vivo por você.") },
        { at: 6.6, key: "ArrowRight", label: L("Next", "Avançar") },
        { at: 9.8, key: "ArrowRight", label: L("Next", "Avançar") },
        { at: 12.6, key: "ArrowRight", label: L("Next", "Avançar") },
        { at: 15.0, caption: L("← goes back one step, instantly.", "← volta um passo, na hora.") },
        { at: 15.7, key: "ArrowLeft", label: L("Back", "Voltar") },
        { at: 17.4, caption: L("Type a slide number, then Enter, to jump.", "Digite o número de um slide e Enter para pular até ele.") },
        { at: 18.1, type: "5", label: L("Slide 5", "Slide 5") },
        { at: 18.9, key: "Enter", label: L("Jump", "Pular") },
      ],
    },
    {
      id: "look",
      seconds: 16,
      beats: [
        { at: 0, chapter: L("02 · Look", "02 · Visual") },
        { at: 0.2, caption: L("Z zooms the site to fill the slide.", "Z amplia o site até preencher o slide.") },
        { at: 0.9, key: "z", label: L("Zoom", "Zoom") },
        { at: 3.0, caption: L("Z again puts it back. It stays that way on every prototype slide.", "Z de novo volta ao normal. Vale para todos os slides de protótipo.") },
        { at: 3.7, key: "z", label: L("Zoom", "Zoom") },
        { at: 6.4, caption: L("T switches between the dark and light versions.", "T alterna entre as versões escura e clara.") },
        { at: 7.0, key: "t", label: L("Dark / light", "Escuro / claro") },
        { at: 9.4, caption: L("Contrast slides like Meet Luisa flip too, so the rhythm holds.", "Slides de contraste, como Meet Luisa, também invertem, e o ritmo se mantém.") },
        { at: 10.0, type: "2", label: L("Slide 2", "Slide 2") },
        { at: 10.7, key: "Enter", label: L("Jump", "Pular") },
        { at: 13.0, key: "t", label: L("Dark / light", "Escuro / claro") },
      ],
    },
    {
      id: "present",
      seconds: 16,
      beats: [
        { at: 0, chapter: L("03 · While you present", "03 · Durante a apresentação") },
        // The note sits bottom-left, so the caption and badge move right for it.
        { at: 0.2, caption: L("N shows the slide's on-screen note.", "N mostra a nota do slide na tela."), place: "right" },
        { at: 0.9, key: "n", label: L("Note", "Nota") },
        { at: 2.9, key: "n", label: L("Note", "Nota") },
        { at: 3.4, caption: L("B blacks out the screen. Press it again to come back.", "B escurece a tela. Aperte de novo para voltar.") },
        { at: 4.0, key: "b", label: L("Black screen", "Tela preta") },
        { at: 5.8, key: "b", label: L("Black screen", "Tela preta") },
        { at: 7.0, caption: L("P opens the presenter view in its own window.", "P abre a visão do apresentador numa janela própria.") },
        { at: 7.6, key: "p", popup: true, label: L("Presenter view", "Visão do apresentador") },
        { at: 8.2, camera: "popup" },
        // Right, clear of the presenter's Back and Next buttons.
        { at: 8.2, caption: L("Notes, what's next and the clocks. Its keys drive the deck too.", "Notas, o que vem a seguir e os cronômetros. As teclas dela também controlam o deck."), place: "right" },
        { at: 11.6, key: "ArrowRight", on: "popup", label: L("Next", "Avançar") },
        { at: 13.4, camera: "main" },
      ],
    },
    {
      id: "panel",
      url: "/deck?admin&debug&slide=3&step=triage.compose",
      seconds: 43,
      beats: [
        { at: 0, chapter: L("04 · The motion panel", "04 · O painel de movimento") },
        { at: 0.3, caption: L("With ?admin in the address, A opens the motion panel.", "Com ?admin no endereço, A abre o painel de movimento.") },
        { at: 1.5, key: "a", label: L("Motion panel", "Painel de movimento") },
        { at: 3.3, frame: CLOSE, cursor: "show", x: 1250, y: 300 },
        { at: 3.4, caption: L("This moment shows the settings for what's on screen.", "Este momento mostra os ajustes do que está na tela.") },
        { at: 4.4, drag: range("Glass blur", "Blur do vidro"), to: 12 },
        { at: 6.9, caption: L("Change a value, then ↻ replays the moment so you can see it.", "Mude um valor e ↻ repete o momento para você ver.") },
        { at: 7.4, click: AI_OPEN },
        { at: 8.1, frame: "wide" },
        { at: 11.2, frame: CLOSE },
        { at: 11.2, caption: L("Global changes every animation at once. Here, half speed.", "Global muda todas as animações de uma vez. Aqui, metade da velocidade.") },
        { at: 11.6, click: tab("Global", "Global"), glide: 0.5 },
        // Each move starts right after a tab click, so the tab's tooltip never opens over the panel.
        { at: 12.2, drag: range("Speed", "Velocidade"), to: 0.5, glide: 0.5 },
        { at: 14.4, click: AI_OPEN },
        { at: 15.1, frame: "wide" },
        { at: 20.4, frame: CLOSE },
        { at: 20.4, caption: L("Revert all puts every setting back.", "Restaurar tudo volta todos os ajustes.") },
        { at: 20.8, click: button("Revert all", "Restaurar tudo") },
        // The panel moves up when the changes row goes, so rest off it.
        { at: 21.5, hover: REST, glide: 0.5 },
        { at: 22.4, caption: L("Deck has the look: the same switches as T and Z.", "Deck tem o visual: os mesmos botões de T e Z.") },
        { at: 22.8, click: tab("Deck", "Deck"), glide: 0.5 },
        { at: 23.4, click: button("Light", "Claro"), glide: 0.5 },
        { at: 24.0, frame: "wide" },
        { at: 25.6, frame: CLOSE },
        { at: 25.8, click: button("Fill slide", "Preencher o slide"), glide: 0.5 },
        { at: 26.4, frame: "wide" },
        { at: 28.2, frame: CLOSE },
        { at: 28.4, click: button("Dark", "Escuro"), glide: 0.5 },
        { at: 29.1, click: button("Framed", "Emoldurado"), glide: 0.5 },
        { at: 30.4, caption: L("Every setting has a ? that says what it does.", "Todo ajuste tem um ? que explica o que ele faz.") },
        { at: 30.6, hover: L("aside section button[aria-label]", "aside section button[aria-label]"), glide: 0.5 },
        { at: 33.0, caption: L("EN | PT switches the panel's language.", "EN | PT troca o idioma do painel.") },
        { at: 33.4, click: L('aside [role="group"] button:text-is("pt")', 'aside [role="group"] button:text-is("en")'), glide: 0.5 },
        { at: 34.0, hover: REST, glide: 0.5 },
        { at: 35.6, click: L('aside [role="group"] button:text-is("en")', 'aside [role="group"] button:text-is("pt")'), glide: 0.5 },
        { at: 36.6, caption: L("Changes save in this browser. Copy settings and send them to Trey.", "As mudanças ficam salvas neste navegador. Copie os ajustes e mande para o Trey.") },
        { at: 36.6, click: tab("Display", "Exibição"), glide: 0.5 },
        // Near its left edge: "Copied" is shorter, so a click in the middle leaves the cursor on Export
        // file, and its tooltip opens.
        { at: 37.2, click: button("Copy settings (JSON)", "Copiar configurações (JSON)"), glide: 0.5, anchor: [0.18, 0.5] },
        { at: 40.5, frame: "wide", cursor: "hide" },
        { at: 40.5, caption: L("A closes the panel.", "A fecha o painel.") },
        { at: 41.0, key: "a", label: L("Motion panel", "Painel de movimento") },
      ],
    },
    {
      id: "keys",
      seconds: 14,
      fadeOut: 0.8,
      card: {
        name: "keys",
        params: (_, T) => ({
          label: "Banner Health",
          eyebrow: T(L("Keys", "Teclas")),
          title: T(L("Every Key on One Card", "Todas as teclas")),
          rows: [
            [["→", "Space", "PgDn"], T(L("Next: a build, a click on the site, or the next slide", "Avançar: uma parte, um clique no site ou o próximo slide"))],
            [["←", "PgUp"], T(L("Back, instantly", "Voltar, na hora"))],
            [["1–9", "Enter"], T(L("Jump to a slide", "Pular para um slide"))],
            [["T"], T(L("Dark or light version", "Versão escura ou clara"))],
            [["Z"], T(L("The site fills the slide, or goes back", "O site preenche o slide, ou volta"))],
            [["N"], T(L("The slide's on-screen note", "A nota do slide na tela"))],
            [["B", "W"], T(L("Black or white screen", "Tela preta ou branca"))],
            [["P"], T(L("Presenter view", "Visão do apresentador"))],
            [["F"], T(L("Full screen", "Tela cheia"))],
            [["A"], T(L("Motion panel (with ?admin)", "Painel de movimento (com ?admin)"))],
            [["Esc"], T(L("Close what's open", "Fecha o que estiver aberto"))],
          ],
          foot: T(L("Questions: Trey Secord", "Dúvidas: Trey Secord")),
        }),
      },
    },
  ],
};

export default storyboard;
