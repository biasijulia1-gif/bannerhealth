// End-to-end check of the deck with real key presses, in system Chrome.
//   npm run smoke                       (against http://localhost:3200)
//   npm run smoke -- --base http://localhost:3000 --shots exports/smoke
// Walks → through every slide, build and journey step, checks each lands where the config says,
// walks ← back (each step must land instantly), checks deck keys never reach the prototype, checks
// Z (site fills the slide) and T (dark/light), checks the admin panel in Portuguese, checks the
// presenter view (P) follows and drives the deck, and fails on any console error or missed
// scripted click.

import { mkdirSync } from "node:fs";
import { chromium } from "playwright-core";

const args = process.argv.slice(2);
const opt = (name, fallback) => {
  const i = args.indexOf(`--${name}`);
  return i >= 0 ? args[i + 1] : fallback;
};
const BASE = opt("base", "http://localhost:3200");
const SHOTS = opt("shots", null);
if (SHOTS) mkdirSync(SHOTS, { recursive: true });

const failures = [];
const fail = (msg) => {
  failures.push(msg);
  console.log(`  ✗ ${msg}`);
};
const same = (a, b) => a.index === b.index && (a.pos?.step ?? a.step) === b.step && (a.pos?.build ?? a.build) === b.build;
const label = (p) => `${p.index + 1}:${p.slideId}${p.step ? `@${p.step}` : ""}${p.build !== undefined ? `#${p.build}` : ""}`;

const browser = await chromium.launch({ channel: "chrome" });
// One context, so the presenter page (section 7) shares the deck's BroadcastChannel.
const context = await browser.newContext({ viewport: { width: 1920, height: 1080 } });
const page = await context.newPage();
const errors = [];
page.on("console", (m) => {
  if (m.type() === "error" || (m.type() === "warning" && m.text().startsWith("[deck]"))) errors.push(m.text());
});
page.on("pageerror", (e) => errors.push(String(e)));

await page.goto(`${BASE}/deck?debug&noauto`, { waitUntil: "networkidle" });
await page.waitForFunction(() => !!window.__deck, null, { timeout: 30000 });
await page.evaluate(() => window.__deck.settled());

const sequence = await page.evaluate(() => window.__deck.sequence());
const position = () => page.evaluate(() => {
  const p = window.__deck.position();
  return { index: p.index, slideId: p.slideId, step: p.pos.step, build: p.pos.build };
});
const shot = async (name) => SHOTS && page.screenshot({ path: `${SHOTS}/${name}.png` });

console.log(`Deck has ${sequence.length} positions across ${new Set(sequence.map((s) => s.index)).size} slides.`);

// 1. Forward: every → lands on the next position in the config.
console.log("Forward walk (→)");
const t0 = Date.now();
let pos = await position();
if (!same({ index: pos.index, step: pos.step, build: pos.build }, sequence[0])) fail(`start at ${label(pos)}, expected ${label(sequence[0])}`);
await shot("00-start");
for (let i = 1; i < sequence.length; i++) {
  await page.keyboard.press("ArrowRight");
  await page.evaluate(() => window.__deck.settled({ quietMs: 250, timeout: 8000 }));
  pos = await position();
  const want = sequence[i];
  if (!same({ index: pos.index, step: pos.step, build: pos.build }, want)) fail(`→ #${i}: landed on ${label({ ...pos, slideId: pos.slideId })}, expected ${label(want)}`);
  if (want.step === "triage.result" || want.step === "doctors.profile" || want.step === "doctors.booked" || want.step === "outro" || i === sequence.length - 1)
    await shot(String(i).padStart(2, "0") + "-" + (want.step ?? want.slideId));
}
console.log(`  ${sequence.length - 1} presses in ${((Date.now() - t0) / 1000).toFixed(1)}s`);

// → on the last position stays put.
await page.keyboard.press("ArrowRight");
await page.evaluate(() => window.__deck.settled({ quietMs: 200 }));
pos = await position();
if (!same({ index: pos.index, step: pos.step, build: pos.build }, sequence[sequence.length - 1])) fail(`→ past the end moved to ${label(pos)}`);

// 2. Back: every ← lands on the previous position instantly (within 3 frames).
console.log("Back walk (←)");
for (let i = sequence.length - 2; i >= 0; i--) {
  await page.keyboard.press("ArrowLeft");
  pos = await page.evaluate(
    () =>
      new Promise((r) =>
        requestAnimationFrame(() =>
          requestAnimationFrame(() =>
            requestAnimationFrame(() => {
              const p = window.__deck.position();
              r({ index: p.index, slideId: p.slideId, step: p.pos.step, build: p.pos.build });
            }),
          ),
        ),
      ),
  );
  if (!same({ index: pos.index, step: pos.step, build: pos.build }, sequence[i])) fail(`← to #${i}: landed on ${label(pos)}, expected ${label(sequence[i])}`);
}

// 3. Deep links land where they say.
console.log("Deep links");
for (const want of [sequence.find((s) => s.step === "doctors.profile"), sequence.find((s) => s.build === 2)].filter(Boolean)) {
  const q = want.step ? `slide=${want.index + 1}&step=${want.step}` : `slide=${want.index + 1}&build=${want.build}`;
  await page.goto(`${BASE}/deck?debug&noauto&${q}`, { waitUntil: "networkidle" });
  await page.waitForFunction(() => !!window.__deck);
  await page.evaluate(() => window.__deck.settled());
  pos = await position();
  if (!same({ index: pos.index, step: pos.step, build: pos.build }, want)) fail(`deep link ${q} landed on ${label(pos)}`);
}

// 4. Deck keys never reach the prototype: letters while the query is typing don't type.
console.log("Key isolation");
const home = sequence.find((s) => s.step === "home");
await page.goto(`${BASE}/deck?debug&noauto&slide=${home.index + 1}`, { waitUntil: "networkidle" });
await page.waitForFunction(() => !!window.__deck);
await page.evaluate(() => window.__deck.settled());
await page.keyboard.press("ArrowRight");
await page.waitForTimeout(450);
const query = () => page.evaluate(() => document.querySelector('[data-proto-root] [data-target="send"]')?.closest("div")?.parentElement?.textContent ?? "");
const before = await query();
for (const k of ["a", "s", "d", "q", "x"]) await page.keyboard.press(k);
const after = await query();
if (after.length - before.length > 2) fail(`letter keys typed into the search bar ("${before}" → "${after}")`);
pos = await position();
if (pos.step !== "triage.compose") fail(`letter keys changed the step to ${pos.step}`);

// 5. Look: Z zooms the site to fill the slide and back, T flips dark/light. Neither moves the deck.
console.log("Look (Z, T)");
const FRAMED = { x: 240, y: 135, w: 1440, h: 810 };
const FULL = { x: 0, y: 0, w: 1920, h: 1080 };
const siteBox = () =>
  page.evaluate(() => {
    const r = document.querySelector("[data-site-box]")?.getBoundingClientRect();
    return r ? { x: Math.round(r.x), y: Math.round(r.y), w: Math.round(r.width), h: Math.round(r.height) } : null;
  });
const near = (a, b) => !!a && ["x", "y", "w", "h"].every((k) => Math.abs(a[k] - b[k]) <= 1);
const look = () =>
  page.evaluate(() => {
    const tones = document.querySelectorAll("[data-tone]");
    return {
      ...window.__deck.position().look,
      slideTone: tones[tones.length - 1]?.getAttribute("data-tone"),
      frame: document.querySelector("[data-deck-frame]")?.getAttribute("data-deck-frame"),
    };
  });
const settle = () => page.evaluate(() => window.__deck.settled({ quietMs: 200 }));

await page.goto(`${BASE}/deck?debug&noauto&slide=${home.index + 1}`, { waitUntil: "networkidle" });
await page.waitForFunction(() => !!window.__deck);
await page.evaluate(() => window.__deck.settled());
const start = await position();
let box = await siteBox();
if (!near(box, FRAMED)) fail(`framed site box is ${JSON.stringify(box)}, expected ${JSON.stringify(FRAMED)}`);
await page.keyboard.press("z");
await settle();
box = await siteBox();
if (!near(box, FULL)) fail(`Z: site box is ${JSON.stringify(box)}, expected the whole canvas`);
if ((await look()).frame !== "hidden") fail("Z: the Valtech frame still shows over the full-slide site");
await shot("look-fill");
await page.keyboard.press("z");
await settle();
box = await siteBox();
if (!near(box, FRAMED)) fail(`Z again: site box is ${JSON.stringify(box)}, expected framed`);
if ((await look()).frame !== "shown") fail("Z again: the Valtech frame didn't come back");
await page.keyboard.press("t");
await settle();
let l = await look();
if (l.tone !== "light" || l.slideTone !== "light") fail(`T: deck tone ${l.tone}, slide tone ${l.slideTone}, expected light`);
await shot("look-light");
pos = await position();
if (!same(pos, start)) fail(`Z/T moved the deck from ${label(start)} to ${label(pos)}`);

// The look rides in the URL, so a link opens in it.
await page.goto(`${BASE}/deck?debug&noauto&slide=${home.index + 1}&tone=light&site=fullbleed`, { waitUntil: "networkidle" });
await page.waitForFunction(() => !!window.__deck);
await page.evaluate(() => window.__deck.settled());
l = await look();
box = await siteBox();
if (l.tone !== "light" || l.site !== "fullbleed" || !near(box, FULL)) fail(`deep link with a look landed ${JSON.stringify(l)}, box ${JSON.stringify(box)}`);

// 6. The admin panel switches to Portuguese (and back), and its tooltips explain each section.
console.log("Admin in Portuguese");
await page.goto(`${BASE}/deck?admin&noauto&slide=${home.index + 1}`, { waitUntil: "networkidle" });
await page.waitForFunction(() => !!window.__deck);
await page.evaluate(() => window.__deck.settled());
await page.keyboard.press("a");
await page.waitForTimeout(600);
// Lower case: section titles are uppercased by CSS, which innerText reflects.
const panelText = () => page.evaluate(() => (document.querySelector("aside")?.innerText ?? "").toLowerCase());
const pickLang = (lang) => page.evaluate((l) => [...document.querySelectorAll("aside button[aria-pressed]")].find((b) => b.textContent === l)?.click(), lang);
if (!(await panelText()).includes("this moment")) fail("the admin didn't open in English");
await pickLang("pt");
await page.waitForTimeout(200);
const text = await panelText();
for (const word of ["este momento", "exibição", "a para fechar", "abertura do hero", "texto e revelações", "palavras do título"])
  if (!text.includes(word)) fail(`PT: "${word}" missing from the panel`);
for (const word of ["this moment", "display", "a to close", "hero opening", "headline words", "showing the settings"])
  if (text.includes(word)) fail(`PT: English "${word}" still in the panel`);
const firstTip = page.locator("aside section button[aria-label]").first();
await firstTip.hover();
await page.waitForTimeout(400);
const tip = await page.evaluate(() => {
  const el = document.querySelector('[role="tooltip"]');
  const dock = document.querySelector("aside")?.getBoundingClientRect();
  const r = el?.getBoundingClientRect();
  return { text: el?.textContent ?? "", inside: !!r && !!dock && r.left >= dock.left && r.right <= dock.right && r.top >= 0 && r.bottom <= window.innerHeight };
});
const tipLabel = await firstTip.getAttribute("aria-label");
if (!tip.text || tip.text !== tipLabel) fail(`section tooltip shows "${tip.text}", expected "${tipLabel}"`);
if (!tip.inside) fail("section tooltip runs outside the panel");
await page.reload({ waitUntil: "networkidle" });
await page.waitForFunction(() => !!window.__deck);
await page.keyboard.press("a");
await page.waitForTimeout(600);
if (!(await panelText()).includes("este momento")) fail("the panel forgot Portuguese after a reload");
await pickLang("en");
await page.waitForTimeout(200);
if (!(await panelText()).includes("this moment")) fail("the panel didn't switch back to English");

// 7. The presenter view (P) follows the deck window, and its keys drive the deck.
console.log("Presenter view");
const watch = (p) => {
  p.on("console", (m) => {
    if (m.type() === "error" || (m.type() === "warning" && m.text().startsWith("[deck]"))) errors.push(`presenter: ${m.text()}`);
  });
  p.on("pageerror", (e) => errors.push(`presenter: ${e}`));
};
const deckPos = () => page.evaluate(() => {
  const p = window.__deck.position();
  return { index: p.index, step: p.pos.step, build: p.pos.build, black: p.black, admin: p.admin };
});
const untilDeck = (check, what) =>
  page.waitForFunction(check, null, { timeout: 4000 }).catch(() => fail(`presenter: the deck never ${what}`));
const card = (p, which) =>
  p.evaluate((w) => {
    const el = document.querySelector(`[data-presenter-${w}]`);
    return el ? { slideId: el.getAttribute("data-slide-id"), step: el.getAttribute("data-step"), build: el.getAttribute("data-build"), kind: el.getAttribute("data-kind") } : null;
  }, which);
const untilCard = (p, which, want, what) =>
  p
    .waitForFunction(
      ({ w, want }) => {
        const el = document.querySelector(`[data-presenter-${w}]`);
        return !!el && Object.entries(want).every(([k, v]) => el.getAttribute(`data-${k}`) === String(v));
      },
      { w: which, want },
      { timeout: 4000 },
    )
    .catch(() => fail(`presenter: ${what}`));

await page.goto("about:blank");
const presenter = await context.newPage();
watch(presenter);
await presenter.goto(`${BASE}/deck/presenter`, { waitUntil: "networkidle" });
await presenter.waitForSelector('[data-presenter-status="waiting"]', { timeout: 10000 }).catch(() => fail("presenter: didn't open waiting for the deck"));
await page.goto(`${BASE}/deck?debug&noauto&slide=2`, { waitUntil: "networkidle" });
await page.waitForFunction(() => !!window.__deck);
await page.evaluate(() => window.__deck.settled());
await presenter.waitForSelector('[data-presenter-status="connected"]', { timeout: 5000 }).catch(() => fail("presenter: never connected to the deck"));
await untilCard(presenter, "current", { "slide-id": "meet-luisa", build: 0 }, "current card isn't Meet Luisa, build 0");

await presenter.keyboard.press("ArrowRight");
await untilDeck(() => window.__deck.position().pos.build === 1, "reached build 1 from the presenter's →");
await page.keyboard.press("ArrowRight");
await untilCard(presenter, "current", { build: 2 }, "didn't follow the deck to build 2");
await untilCard(presenter, "next", { "slide-id": "triage", kind: "slide" }, "next card isn't the triage slide");

await presenter.keyboard.press("b");
await untilDeck(() => window.__deck.position().black === "black", "went black from the presenter's B");
await presenter.waitForSelector('[data-presenter-black="black"]', { timeout: 4000 }).catch(() => fail("presenter: doesn't show the black screen"));
await presenter.keyboard.press("ArrowRight");
await untilDeck(() => window.__deck.position().black === false, "cleared black from the presenter's →");
if ((await deckPos()).build !== 2) fail("presenter: → on a black screen moved the deck instead of clearing it");
await presenter.keyboard.press("ArrowLeft");
await untilDeck(() => window.__deck.position().pos.build === 1, "went back from the presenter's ←");

await presenter.keyboard.press("3");
await presenter.keyboard.press("Enter");
await untilDeck(() => window.__deck.position().index === 2 && window.__deck.position().pos.step === "home", "jumped to slide 3 from the presenter");
await page.evaluate(() => window.__deck.settled({ quietMs: 200 }));
await presenter.keyboard.press("ArrowRight");
await untilDeck(() => window.__deck.position().pos.step === "triage.compose", "advanced the journey from the presenter");
await presenter
  .waitForFunction(() => document.querySelector("[data-presenter-notes]")?.textContent?.includes("The prompt is the front door"), null, { timeout: 4000 })
  .catch(() => fail("presenter: the step's note isn't showing"));
await presenter.keyboard.press("a");
await presenter.waitForTimeout(300);
if ((await deckPos()).admin) fail("presenter: A opened the motion panel on the deck screen");
await presenter.setViewportSize({ width: 1280, height: 800 });
if (SHOTS) await presenter.screenshot({ path: `${SHOTS}/presenter-1280.png` });
await presenter.setViewportSize({ width: 1920, height: 1080 });
if (SHOTS) await presenter.screenshot({ path: `${SHOTS}/presenter-1920.png` });

// P in the deck opens its own popup; P again brings it forward without reloading it.
const popupPromise = page.waitForEvent("popup", { timeout: 5000 });
await page.keyboard.press("p");
const popup = await popupPromise.catch(() => null);
if (!popup) fail("presenter: P didn't open a window");
else {
  watch(popup);
  await popup.waitForURL("**/deck/presenter", { timeout: 10000 }).catch(() => fail(`presenter: P opened ${popup.url()}`));
  await popup.waitForSelector('[data-presenter-status="connected"]', { timeout: 10000 }).catch(() => fail("presenter: the popup never connected"));
  await popup.evaluate(() => (window.__mark = 1));
  let again = false;
  page.once("popup", () => (again = true));
  await page.keyboard.press("p");
  await page.waitForTimeout(800);
  if (again) fail("presenter: P again opened a second window");
  if ((await popup.evaluate(() => window.__mark)) !== 1) fail("presenter: P again reloaded the presenter window");
  await page.keyboard.press("ArrowRight");
  await page.evaluate(() => window.__deck.settled({ quietMs: 250, timeout: 8000 }));
  await untilCard(popup, "current", { step: "triage.howLong" }, "the popup didn't follow the deck");
  await untilCard(presenter, "current", { step: "triage.howLong" }, "a second presenter didn't follow the deck");
}

// A deck reload reconnects.
await page.reload({ waitUntil: "networkidle" });
await page.waitForFunction(() => !!window.__deck);
await presenter.waitForSelector('[data-presenter-status="connected"]', { timeout: 6000 }).catch(() => fail("presenter: didn't reconnect after a deck reload"));
if (!(await card(presenter, "current"))) fail("presenter: lost its current card after a deck reload");
await popup?.close();
await presenter.close();

if (errors.length) fail(`console errors:\n    ${[...new Set(errors)].join("\n    ")}`);

await browser.close();
if (failures.length) {
  console.log(`\nSMOKE FAILED (${failures.length})`);
  process.exit(1);
}
console.log("\nSMOKE PASSED");
