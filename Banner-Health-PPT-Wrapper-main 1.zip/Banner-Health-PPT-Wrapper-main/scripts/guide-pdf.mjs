// Prints Sebastian's slide handoff guide (docs/slide-handoff-guide.html) to a PDF with system
// Chrome, which embeds the Valtech fonts. Fails if a font didn't load or a page overflows.
//   node scripts/guide-pdf.mjs                    → docs/Handing Off Brand Slides.pdf
//   node scripts/guide-pdf.mjs --shots <folder>   also saves a PNG of each page for review

import { mkdirSync } from "node:fs";
import path from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import { chromium } from "playwright-core";

const root = path.dirname(path.dirname(fileURLToPath(import.meta.url)));
const source = path.join(root, "docs", "slide-handoff-guide.html");
const output = path.join(root, "docs", "Handing Off Brand Slides.pdf");
const shotsArg = process.argv.indexOf("--shots");
const shots = shotsArg >= 0 ? process.argv[shotsArg + 1] : null;

// file:// pages may only load fonts from file:// with this flag.
const browser = await chromium.launch({ channel: "chrome", args: ["--allow-file-access-from-files"] });
const page = await browser.newPage({ viewport: { width: 816, height: 1056 } });
await page.emulateMedia({ media: "print" });
await page.goto(pathToFileURL(source).href, { waitUntil: "load" });

const check = await page.evaluate(async () => {
  await document.fonts.ready;
  const faces = [...document.fonts].map((f) => `${f.family} ${f.weight}: ${f.status}`);
  const failed = faces.filter((f) => !f.endsWith("loaded"));
  // Content must end above the footer on every page.
  const overflow = [...document.querySelectorAll(".page")].flatMap((p, i) => {
    const limit = p.getBoundingClientRect().bottom - 84;
    return [...p.querySelectorAll("main, aside")]
      .filter((el) => el.getBoundingClientRect().bottom > limit)
      .map((el) => `page ${i + 1}: <${el.tagName.toLowerCase()}> ends ${Math.round(el.getBoundingClientRect().bottom - limit)}px too low`);
  });
  return { faces, failed, overflow };
});

if (shots) {
  mkdirSync(shots, { recursive: true });
  const pages = await page.$$(".page");
  for (const [i, p] of pages.entries()) await p.screenshot({ path: path.join(shots, `page-${i + 1}.png`) });
}

if (check.failed.length || check.overflow.length) {
  console.error([...check.failed.map((f) => `font not loaded: ${f}`), ...check.overflow].join("\n"));
  await browser.close();
  process.exit(1);
}

await page.pdf({ path: output, preferCSSPageSize: true, printBackground: true });
await browser.close();
console.log(`Fonts: ${check.faces.join(", ")}`);
console.log(`Wrote ${path.relative(root, output)}`);
