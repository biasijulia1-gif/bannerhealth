import { defineConfig, globalIgnores } from "eslint/config";
import nextVitals from "eslint-config-next/core-web-vitals";
import nextTs from "eslint-config-next/typescript";

// Only src/motion/instant.ts may flip Motion's global skip flag (instant jumps, exports).
const motionGlobal = {
  name: "motion/react",
  importNames: ["MotionGlobalConfig"],
  message: "Only src/motion/instant.ts touches MotionGlobalConfig. Use settle() or freeze() from @/motion.",
};

// The engine (shell + motion) is extracted into a template after the pitch, so it never imports a
// specific prototype, deck or brand theme. Those arrive through the registries the app passes in.
const engineBoundary = {
  group: ["@/prototypes", "@/prototypes/*", "@banner/*", "@/decks/*", "@/themes/*"],
  message: "The engine (src/shell, src/motion) reaches prototypes, decks and themes only through what the app passes in.",
};

const eslintConfig = defineConfig([
  ...nextVitals,
  ...nextTs,
  {
    rules: {
      // Prototype assets are pre-optimized WebP/SVG and must never lazy-load mid-presentation.
      "@next/next/no-img-element": "off",
      "no-restricted-imports": ["error", { paths: [motionGlobal] }],
    },
  },
  {
    files: ["src/shell/**", "src/motion/**"],
    rules: {
      "no-restricted-imports": ["error", { paths: [motionGlobal], patterns: [engineBoundary] }],
    },
  },
  {
    files: ["src/motion/instant.ts"],
    rules: { "no-restricted-imports": "off" },
  },
  // Override default ignores of eslint-config-next.
  globalIgnores([
    // Default ignores of eslint-config-next:
    ".next/**",
    "out/**",
    "build/**",
    "next-env.d.ts",
  ]),
]);

export default eslintConfig;
