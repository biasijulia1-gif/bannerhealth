// Sessions and controllers schedule with window timers; in Node, window is the global object.
const g = globalThis as unknown as { window?: typeof globalThis; requestAnimationFrame?: (cb: () => void) => number };
g.window ??= globalThis;
g.requestAnimationFrame ??= (cb) => setTimeout(cb, 16) as unknown as number;
