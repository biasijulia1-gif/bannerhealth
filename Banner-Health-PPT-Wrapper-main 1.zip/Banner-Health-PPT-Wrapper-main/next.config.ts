import path from "node:path";
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  cacheComponents: true,
  partialPrefetching: true,
  // The dev badge sits on top of the deck HUD.
  devIndicators: false,
  // A self-contained server for the presenting laptop (`node .next/standalone/server.js`).
  output: "standalone",
  turbopack: {
    // A stray lockfile in the home folder otherwise makes Next guess the wrong workspace root.
    root: path.resolve("."),
    rules: {
      "*.css": {
        loaders: ["@tailwindcss/turbopack"],
        as: "*.css",
      },
    },
  },
  async redirects() {
    return [{ source: "/", destination: "/deck", permanent: false }];
  },
};

export default nextConfig;
